package com.cg.employeemanagement.dao;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.dto.Login;
import com.cg.employeemanagement.entity.EmployeeStaticDB;
import com.cg.employeemanagement.entity.LeaveResponseStaticDB;
import com.cg.employeemanagement.entity.LeavesStaticDB;
import com.cg.employeemanagement.entity.LoginDatabase;



public class EmployeeDaoImpl implements EmployeeDao {
	
	EmployeeStaticDB esdb = new EmployeeStaticDB();
	LoginDatabase loginDB = new LoginDatabase();
	LeavesStaticDB lsDB = new LeavesStaticDB();
	LeaveResponseStaticDB leaveResStaticDb = new LeaveResponseStaticDB(); 


	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO employee should be able to search other employee details based on employee id
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserId()==empId)
			{
				return emp;
			}
		}
		return null;
	}
	
	@Override
	public List<Employee> searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		List<Employee> empList = new ArrayList<Employee>();
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserName().equals(name))
			{
				empList.add(emp);
			}
		}
		return empList;
		
	}

	@Override
	public Employee displayEmpDetails(String userName) {
		// TODO The function should display the employee details like id,sal,name,dept_id etc.
		
		int id = loginDB.getId(userName);
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserId()==id)
			{
				return emp;
			}
		}
		return null;
	}
	

	@Override
	public boolean changeAccountPassword(String userName,String oldPassword,String newPassword) {
		// TODO the function should change the password for the employee login details in login class
		int id = loginDB.getId(userName);
		for(Login login : LoginDatabase.getLoginDetails())
		{
			if(login.getEmpId()==id && login.getPassword().equals(oldPassword))
			{
				login.setPassword(newPassword);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO the function should add the leave details for the employee and should not decrease the leave count 
		//unless it is accepted which should be done in manager interface implementation
		boolean addLeaveStatus = lsDB.add(leave);
		return addLeaveStatus;
	}
	
	@Override
	public Leave editLeave(int leaveId, LocalDate fromDate,LocalDate toDate) {
		// The function should modify the leave details for this the leave status should be checked and the applied date should be verified.
		for(Leave leave : lsDB.getLeavesList())
		{
			if(leave.getLeaveId()==leaveId)
			{
				if(leave.getFromDate().compareTo(LocalDate.now())<0)
				{
					return null;
				}
				else
				{
				leave.setFromDate(fromDate);
				leave.setToDate(toDate);
				leave.setAppliedDate(LocalDate.now());
				return leave;
			}
			}
		}
		return null;
	}
	
	@Override
	public List<Leave> SearchLeave(int empId) {
		// the employee should search their leaves.(return can be changed if you want)
		//in if case compare empid;
		List<Leave> leavelist = new ArrayList<>();
		for(Leave leave :lsDB.getLeavesList())
		{
			if(leave.getEmpId()==empId)
			{
				leavelist.add(leave);
			}
		}
		return leavelist;
	}
	
	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO the function should check the date on which the leave was applied if it is less than 3 days then only 
		//it should able to delete the leave applied by the employee or else it can't be done 
		for(Leave leave : lsDB.getLeavesList())
		{
			if(leave.getLeaveId()==leaveId)
			{
				if(leave.getFromDate().compareTo(LocalDate.now())<0)
				{
					return false;
				}
				else
				{
				if((ChronoUnit.DAYS.between(LocalDate.now(), leave.getAppliedDate()))<3)
				{
					lsDB.removeLeave(leaveId);
					return true;
				}
			}
			}
		}
		return false;
	}
	public boolean changeAccountPassword(String newPassword,String userName)
	{
		int id = loginDB.getId(userName);
		for(Login login : LoginDatabase.getLoginDetails())
		{
			if(login.getEmpId()==id)
			{
				login.setPassword(newPassword);
				return true;	
			}
		}
		return false;
	}

	   public boolean checkOldPassword(String oldPassword,String userName)
	   {
		   int id = loginDB.getId(userName);
			for(Login login : LoginDatabase.getLoginDetails())
			{
				if(login.getEmpId()==id)
				{
					if(login.getPassword().equals(oldPassword))
					{
					
						return true;	
					}
					else
					{
						return false;
					}
					
				}
			}
			return false;
	   }
	   public int getIdFromUsername(String userName)
	   {
		   return loginDB.getId(userName);
	   }
	   public int getManagerId(int empId)
	   {
		   return esdb.getManagerId(empId);
	   }
	   
	   public boolean checkIfLeavePending(int leaveId,int empid)
	   {
		   for(Leave l : lsDB.getLeavesList())
		   {
			   if(l.getLeaveId()==leaveId && l.getStatus().equals("pending") && l.getEmpId()==empid)
			   {
				   
				   return true;
			   }
		   }
		   return false;
	   }

}
