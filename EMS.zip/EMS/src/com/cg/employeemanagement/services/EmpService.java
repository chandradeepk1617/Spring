package com.cg.employeemanagement.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;

public interface EmpService {
	public Employee searchEmployeeById(String empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayEmpDetails(String userName);
	public boolean changeAccountPassword(String userName,String oldPassword,String newPassword);
	public boolean addLeave(Leave leave);
	public Leave editLeave(int leaveId,LocalDate fromDate,LocalDate toDate);
	public List<Leave> SearchLeave(int empId);
	public boolean cancelLeave(int leaveId);
	public boolean validateTODate(LocalDate fromDate, LocalDate toDate);
	public boolean validateFromDate(LocalDate fromDate);
	public boolean isValidYear(String year,String yearPattern);
	public boolean isValidDay(int day,int month,int year);
	public boolean isValidMonth(int month);
	public boolean validatePassword(String newPassword,String passwordPattern);
	public boolean changeAccountPassword(String newPassword,String userName);
	public boolean checkOldPassword(String oldPassword,String userName);
	public int getIdFromUsername(String userName);
	public int getManagerId(int empId);
	public boolean checkIfLeavePending(int leaveId,int empid);
	public boolean validateEmpId(String empId);
}
