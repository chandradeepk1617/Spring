package com.cg.employeemanagement.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.exception.EmpException;
import com.cg.employeemanagement.services.AdminService;
import com.cg.employeemanagement.services.AdminServiceImpl;
import com.cg.employeemanagement.services.EmpService;
import com.cg.employeemanagement.services.EmpServiceImpl;
import com.cg.employeemanagement.services.LoginService;
import com.cg.employeemanagement.services.LoginServiceImpl;
import com.cg.employeemanagement.services.ManagerService;
import com.cg.employeemanagement.services.ManagerServiceImpl;

public class EmployeeManagementDemo {

	public static void main(String[] args) {
		System.out.println("WELCOME TO ACS \n");
		int flag = 0;
		int flag1 = 0;
		String yearPattern = "[0-9]{4}";
		String phonePattern = "[^0][0-9]{9}";
		String namePattern = "[A-Z]{1,1}[a-z]{2,25}";
		String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,12})";
		
		while (true) {
			System.out.println("Login types:\n" 
					+ "\tEnter 1 for : Admin \n " 
					+ "\tEnter 2 for : Manager\n "
					+ "\tEnter 3 for : Employee");
			
			String loginChoice;
			String choice = null;
			LoginService loginService = new LoginServiceImpl();
			
			Scanner scanner = new Scanner(System.in);
			
			loginChoice = scanner.next();
			
			while(true)
			{
				if(loginChoice.equals("1") || loginChoice.equals("2") || loginChoice.equals("3") )
				{
					break;
				}
				else {
				System.out.println("Enter valid choice");
				loginChoice = scanner.next();
				}
			}
			
			String userName;
			String password;
			boolean valid;
			System.out.println("Enter your User Name:");
			userName = scanner.next();
			System.out.println("Enter your password:");
			password = scanner.next();
			valid = loginService.validate(userName, password, loginChoice);
			
			if (valid && loginChoice.equals("1")) {
				boolean operation = true;
				while (operation) {
					System.out.println("Admin:\n" 
							+ "\t1.Add Employee\n" 
							+ "\t2.Delete Employee\n"
							+ "\t3.Modify employee By Id\n" 
							+ "\t4.Search employee by Id\n"
							+ "\t5.Search employee by name\n" 
							+ "\t6.display all the employees\n" 
							+ "\t7.Change Password\n" 
							+ "\t8.To Log out\n");

					choice = scanner.next();
					scanner.nextLine();
					AdminService adminService = new AdminServiceImpl();

					switch (choice) {
					case "1":
						float empSalary =0f;
						Employee emp;
						System.out.println("Enter Employee Name:");
						String empName = scanner.nextLine();
						
						while (flag != 1) {
							
							if (adminService.isValidName(empName, namePattern))
								flag = 1;
							else {
								System.out.println(
										"Name must start with a capital letter And must have atleast 3 characters");
								System.out.println("Enter Name Again");
								empName = scanner.nextLine();
							}
						}
						flag = 0;

						/*System.out.println("Enter Employee Salary");*/
						
						try
						{
						System.out.println("Enter Employee Salary");
						empSalary = scanner.nextFloat();
						}
						catch(InputMismatchException ime)
						{
							
						}
						
						System.out.println("Enter Employee Department Id");
						int empDeptId = scanner.nextInt();
						System.out.println("Enter employee date of birth in the format yyyy mm dd");
						LocalDate empDOB = null;
						while (flag != 1) {
							int year = 0;
							int month = 0;
							int dayOfMonth = 0;
							System.out.println("Enter year");
							while (flag1 != 1) {
								year = scanner.nextInt();
								if (adminService.isValidYear(String.valueOf(year), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								month = scanner.nextInt();
								if (adminService.isValidMonth(month)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								dayOfMonth = scanner.nextInt();
								if (adminService.isValidDay(dayOfMonth, month, year)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}
							empDOB = LocalDate.of(year, month, dayOfMonth);
							if (adminService.isValidDate(empDOB))
								flag = 1;
							else {
								System.out.println("Date of birth cannot be after the present date\n");
								System.out.println("Enter Date of birth again\n");
							}
						}
						flag = 0;
						System.out.println("Enter Employee Contact Number");
						Long empContactNumber = 0L;
						while (flag != 1) {
							empContactNumber = scanner.nextLong();
							if (adminService.isValidPhone(String.valueOf(empContactNumber), phonePattern))
								flag = 1;
							else {
								System.out.println("Contact number must have 10 digits and does not start with 0");
								System.out.println("Enter Contact number Again");
							}
						}
						flag = 0;

						System.out.println("Enter Employee Manager Id");
						int empManagerId = scanner.nextInt();
						emp = new Employee(empName, empSalary, empDeptId, empDOB, empContactNumber, empManagerId, 22);
						boolean status = adminService.addEmployee(emp);
						if (status) {
							System.out.println("Employee is added successfully");
						} else {
							throw new EmpException("error in adding the new employee to the database");
						}
						break;
					
					case "2":
						System.out.println("Enter Employee Id for deletion");
						int empDeleteId = scanner.nextInt();
						boolean deletionStatus = adminService.deleteEmployeeById(empDeleteId);
						if (deletionStatus) {
							System.out.println("Employee is deleted Sucessfully");
						} else {
							throw new EmpException("error in deleting the employee from database");
						}
						break;
					case "3":
						// Im writing code for only name modification as of now
						System.out.println("Enter Employee Id for Modification");
						int empToBeModifiedId = scanner.nextInt();
						System.out.println("\nEnter 1: to update name\n" + "Enter 2: to update Salary\n"
								+ "Enter 3: to update Department id\n" + "Enter 4: to update Date of Birth\n"
								+ "Enter 5: to update Contact Number\n" + "Enter 6: to update Manager Id\n");
						int modifyChoice = scanner.nextInt();
						boolean bool;
						switch (modifyChoice) {
						case 1:
							flag = 0;
							System.out.println("Enter the new Name");
							String newName = scanner.nextLine();
							// scanner.nextLine();
							while (flag != 1) {
								newName = scanner.nextLine();
								if (adminService.isValidName(newName, namePattern))
									flag = 1;
								else {
									System.out.println(
											"Name must start with a capital letter And must have atleast 3 characters");
									System.out.println("Enter Name Again");
								}
							}
							flag = 0;
							bool = adminService.modifyEmployeeName(empToBeModifiedId, newName);
							if(bool)
							{
								System.out.println("Employee's Name successfully updated");
							}
							break;
						case 2:
							System.out.println("Enter the new Salary");
							float newSal = scanner.nextFloat();
							bool = adminService.modifyEmployeeSalary(empToBeModifiedId, newSal);
							if(bool)
							{
								System.out.println("Employee's Salary successfully updated");
							}
							break;
						case 3:
							System.out.println("Enter the new Department Id");
							int newdeptId = scanner.nextInt();
							bool = adminService.modifyEmployeeDepartmentId(empToBeModifiedId, newdeptId);
							if(bool)
							{
								System.out.println("Employee's Department Id successfully updated");
							}
							break;
						case 4:
							flag1 = 0;
							flag = 0;
							System.out.println("Enter the correct Date Of Birth");
							LocalDate newDOB = null;
							int correctYear = 0;
							int correctMonth = 0;
							int correctDayOfMonth = 0;
							while (flag != 1) {

								System.out.println("Enter year");
								while (flag1 != 1) {
									correctYear = scanner.nextInt();
									if (adminService.isValidYear(String.valueOf(correctYear), yearPattern)) {
										flag1 = 1;
									} else {
										System.out.println("year must be in yyyy format");
										System.out.println("Enter year in yyyy format");
									}

								}
								flag1 = 0;
								System.out.println("Enter month");

								while (flag1 != 1) {
									correctMonth = scanner.nextInt();
									if (adminService.isValidMonth(correctMonth)) {
										flag1 = 1;
									} else {
										System.out.println("Month can't be greater than  12 or less than 1");
										System.out.println("Enter month again");
									}

								}
								flag1 = 0;

								System.out.println("Enter date");
								while (flag1 != 1) {
									correctDayOfMonth = scanner.nextInt();
									if (adminService.isValidDay(correctDayOfMonth, correctMonth, correctYear)) {
										flag1 = 1;
									} else {
										System.out.println("In proper day");
										System.out.println("Enter day again");
									}

								}
								flag1 = 0;
								newDOB = LocalDate.of(correctYear, correctMonth, correctDayOfMonth);
								if (adminService.isValidDate(newDOB))
									flag = 1;
								else {
									System.out.println("Date of birth cannot be after the present date");
									System.out.println("Emter Date of birth again");
								}
							}
							flag = 0;

							bool = adminService.modifyEmployeeDOB(empToBeModifiedId, newDOB);
							if(bool)
							{
								System.out.println("Employee's Date of Birth successfully updated");
							}
							break;
						case 5:
							System.out.println("Enter the new Contact Number");
							Long newContactNumber = 0L;
							while (flag != 1) {
								newContactNumber = scanner.nextLong();
								if (adminService.isValidPhone(String.valueOf(newContactNumber), phonePattern))
									flag = 1;
								else {
									System.out.println("Contact number must have 10 digits and does not start with 0");
									System.out.println("Enter Contact number Again");
								}
							}
							flag = 0;

							bool = adminService.modifyEmployeeContactNumber(empToBeModifiedId, newContactNumber);
							if(bool)
							{
								System.out.println("Employee's Contact Number successfully updated");
							}
							break;
						case 6:
							System.out.println("Enter the new Manager's Id");
							int newManagerId = scanner.nextInt();
							bool = adminService.modifyEmployeeManagerId(empToBeModifiedId, newManagerId);
							if(bool)
							{
								System.out.println("Employee new Manager Id successfully updated");
							}
							break;


						}
						break;

					case "4":
						Employee searchedEmp;
						String empSearchId=null;;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = adminService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = adminService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;

					case "5":
						System.out.println("Enter Employee name for searching");
						String empSearchByName = scanner.next();
						List<Employee> employeeList = adminService.searchEmployessByName(empSearchByName);
						if(employeeList.size()>0)
						{
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n"
									,"Employee Id","Name","Department Id","Salary","Date of Birth"
									,"Contact Number","Manager Id","Number of leaves left");
						
						for (Employee resultEmp : employeeList) {
								System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n", resultEmp.getUserId(),
										resultEmp.getUserName(),resultEmp.getDepartmentId(),resultEmp.getSalary(),
										resultEmp.getDateOfBirth(),resultEmp.getContactNumber(),resultEmp.getManagerId()
										,resultEmp.getNoOfLeaves());
						}
						}
						else
						{
							System.out.println("No Employee found with name : "+empSearchByName);
						}
						break;
					case "6":
						List<Employee> empTotalList = adminService.displayEmployees();
						if(empTotalList.size()>0)
						{
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n"
									,"Employee Id","Name","Department Id","Salary","Date of Birth"
									,"Contact Number","Manager Id","Number of leaves left");
							for (Employee totalEmp : empTotalList) {
								
								System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n", totalEmp.getUserId(),
										totalEmp.getUserName(),totalEmp.getDepartmentId(),totalEmp.getSalary(),
										totalEmp.getDateOfBirth(),totalEmp.getContactNumber(),totalEmp.getManagerId()
										,totalEmp.getNoOfLeaves());
							}
							System.out.println();
						}
						else
						{
							System.out.println("No employee to display");
						}
						break;
					case "7":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = adminService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(adminService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Be between 6 and 12 characters "
										+ "long Contain at least one digit."
										+ "Contain at least one lower case character."
										+ "Contain at least one upper case character."
										+ "Contain at least on special character from [ @ # $ % ! . ].");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = adminService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;

					case "8":
						operation = false;
						break;

					default:
						System.out.println("Exit");
					}
				}
			}

			else if (valid && loginChoice.equals("2")) {
				boolean operation = true;
				while (operation) {

					System.out.println(
							"Manager\n" 
							+ "\t1.Search By employee Id\n" 
							+ "\t2.Search employee by name\n"
							+ "\t3.Display own details\n" 
							+ "\t4.Display all subordinates\n"
							+ "\t5.Show leaves applied by employees\n" 
							+ "\t6.Accept leave\n" 
							+ "\t7.Reject leave\n"
							+ "\t8.To change Account Password\n" 
							+ "\t9.To Log out\n");

					choice = scanner.next();

					ManagerService managerService = new ManagerServiceImpl();
					switch (choice) {
					case "1":
						Employee searchedEmp;
						String empSearchId;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = managerService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = managerService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;

					case "2":
						
						System.out.println("Enter Employee name to be searched");
						String empName = scanner.next();
						List<Employee> empTotalList = managerService.searchEmployeeByName(empName);
						if(empTotalList.size()>0)
						{
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n"
									,"Employee Id","Name","Department Id","Salary","Date of Birth"
									,"Contact Number","Manager Id","Number of leaves left");
						for (Employee emp : empTotalList) {
								System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n", emp.getUserId(),
										emp.getUserName(),emp.getDepartmentId(),emp.getSalary(),
										emp.getDateOfBirth(),emp.getContactNumber(),emp.getManagerId()
										,emp.getNoOfLeaves());
							}
						}
						else
						{
							System.out.println("Employee with name"+empName+" not found \n");
						}
						break;

					case "3":
						
						Employee empOwnDetails = managerService.displayOwnDetails(userName);
						
						System.out.printf("%-25s:%-20s\n","Employee ID",empOwnDetails.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",empOwnDetails.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",empOwnDetails.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",empOwnDetails.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",empOwnDetails.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",empOwnDetails.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",empOwnDetails.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",empOwnDetails.getNoOfLeaves());
						System.out.println();
						break;

					case "4":
						
						List<Employee> subEmpList = managerService.displaySubEmployees(userName);
						if(subEmpList.size()>0)
						{
						System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n"
								,"Employee Id","Name","Department Id","Salary","Date of Birth"
								,"Contact Number","Manager Id","Number of leaves left");
						for (Employee subordinate : subEmpList) {
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n", subordinate.getUserId(),
									subordinate.getUserName(),subordinate.getDepartmentId(),subordinate.getSalary(),
									subordinate.getDateOfBirth(),subordinate.getContactNumber(),subordinate.getManagerId()
									,subordinate.getNoOfLeaves());
						}
						System.out.println();
						}
						else
						{
							System.out.println("There are no employees under You \n");
						}
						break;

					case "5":
						
						List<Leave> leaveList = managerService.showLeavesApplied(userName);
						if(leaveList.size()>0)
						{
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",
									"Leave Id","Employee Id","Manager Id","From Date","To Date","Applied Date"
									,"Reason for leave","Leave Status");
						for (Leave leave : leaveList) {
							
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",
									leave.getLeaveId(),leave.getEmpId(),leave.getManagerId(),leave.getFromDate(),
									leave.getToDate(),leave.getAppliedDate(),leave.getReason(),leave.getStatus());
//							System.out.printf("%-25s:%-25s\n","Leave Id",leave.getLeaveId());
//							System.out.printf("%-25s:%-25s\n","Employee Id",leave.getEmpId());
//							System.out.printf("%-25s:%-25s\n","Manager Id",leave.getManagerId());
//							System.out.printf("%-25s:%-25s\n","From Date",leave.getFromDate());
//							System.out.printf("%-25s:%-25s\n","To Date",leave.getToDate());
//							System.out.printf("%-25s:%-25s\n","Appled Date",leave.getAppliedDate());
//							System.out.printf("%-25s:%-25s\n","Reason for leave",leave.getReason());
//							System.out.printf("%-25s:%-25s\n","Leave Status",leave.getStatus());
//							
//							if (!leave.isLeaveStatus()) {
////								System.out.printf("%-25s:%-25s\n","Leave Status","Pending for approval\n");
////							}
						}
						}
						else
						{
							System.out.println("There are no leaves to be approved\n");
						}
						
						break;

					case "6":
						
						System.out.println("Enter leave id to be accepted");
						int leaveId = scanner.nextInt();
						boolean leaveAcceptStatus = managerService.accept(leaveId);
						if (leaveAcceptStatus) {
							System.out.println("Leave accepted sucessfully\n");
						}
						else {
							System.out.println("There is no leave with Id : "+leaveId +" to be approved");
						}
						break;

					case "7":
						
						System.out.println("Enter leave id for rejection");
						int leaveId2 = scanner.nextInt();
						boolean leaveIdExistOrNot = managerService.checkLeaveIdExistOrNot(leaveId2);
						if(leaveIdExistOrNot)
						{
						System.out.println("Enter reason for rejection");
						String reason = scanner.next();
						boolean rejectStatus = managerService.reject(leaveId2, reason);
						if (rejectStatus) {
							System.out.println("Sucessfully rejected\n");
						}
						}
						else {
							System.out.println("There is no leave with Id : "+leaveId2 +" to be rejected");
						}
						break;
						
					case "8":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = managerService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(managerService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Password should be between 6 to 12 characters long \n"
										+ "Contain at least one digit.\n"
										+ "Contain at least one lower case character.\n"
										+ "Contain at least one upper case character.\n"
										+ "Contain at least on special character from [ @ # $ % ! . ].\n");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = managerService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Old password is not correct\n");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;

					case "9":
						operation = false;
						break;

					default:
						System.out.println("Enter valid choice\n");
					}
				}

			} 
			////EMPLOYEE ROLE BEGINS
			else if (valid && loginChoice.equals("3")) {
				boolean operation = true;
				while (operation) {
					System.out.println("Employee\n" 
							+ "\t1.Search Employee By Id\n" 
							+ "\t2.Search Employee By Name\n"
							+ "\t3.Display their own details\n" 
							+ "\t4.change account password\n"
							+ "\t5.apply for leave\n" 
							+ "\t6.Edit leave\n" 
							+ "\t7.view his leave\n"
							+ "\t8.cancel any leave\n" 
							+ "\t9.to logout");
					int leaveId;
					String employeeChoice = scanner.next();
					EmpService employeeService = new EmpServiceImpl();
					switch (employeeChoice) {
					case "1":
						Employee searchedEmp;
						String empSearchId=null;;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = employeeService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = employeeService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;
					case "2":
						System.out.println("Enter Employee name to be searched");
						String empName = scanner.next();
						List<Employee> empTotalList = employeeService.searchEmployeeByName(empName);
						if(empTotalList.size()==0)
						{
							System.out.println("Employee with name "+empName+" not found");
						}
						else
						{
						for (Employee result : empTotalList) {
							System.out.printf("%-25s:%-20s\n","Employee ID",result.getUserId());
							System.out.printf("%-25s:%-20s\n","Name",result.getUserName());
							System.out.printf("%-25s:%-20s\n","Salary",result.getSalary());
							System.out.printf("%-25s:%-20s\n","Department Id",result.getDepartmentId());
							System.out.printf("%-25s:%-20s\n","Date of Birth",result.getDateOfBirth());
							System.out.printf("%-25s:%-20s\n","Contact Number",result.getContactNumber());
							System.out.printf("%-25s:%-20s\n","Manager Id",result.getManagerId());
							System.out.printf("%-25s:%-20s\n","Number of leaves left",result.getNoOfLeaves());
							System.out.println();
						}
						}
						break;
					case "3":
						Employee empOwnDetails = employeeService.displayEmpDetails(userName);
						System.out.println("Employee");
						System.out.printf("%-25s:%-20s\n","Employee ID",empOwnDetails.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",empOwnDetails.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",empOwnDetails.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",empOwnDetails.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",empOwnDetails.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",empOwnDetails.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",empOwnDetails.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",empOwnDetails.getNoOfLeaves());
						System.out.println();
						break;
					case "4":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = employeeService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(employeeService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Be between 6 and 12 characters "
										+ "long Contain at least one digit."
										+ "Contain at least one lower case character."
										+ "Contain at least one upper case character."
										+ "Contain at least on special character from [ @ # $ % ! . ].");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = employeeService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;


					case "5":
						
						System.out.println("Enter from date in the format yyyy mm dd");
						LocalDate fDate = null;
						LocalDate tDate = null;
						LocalDate today = null;
						int fromYear = 0;
						int fromMonth = 0;
						int fromDate = 0;
						int toYear = 0;
						int toMonth = 0;
						int toDate = 0;
						flag = 0;
						flag1 = 0;
						boolean fromDateFlag=true;
						boolean toDateFlag=true;
						while(fromDateFlag)
						{
							System.out.println("Enter year");
							fromYear = scanner.nextInt();
							System.out.println("Enter month");
							fromMonth = scanner.nextInt();
							System.out.println("Enter date");
							fromDate = scanner.nextInt();
							try
							{
							fDate = LocalDate.of(fromYear, fromMonth, fromDate);
							if (employeeService.validateFromDate(fDate)) {
                                fromDateFlag=false;
							}
							else
							{
								System.out.println("From date can't be less than present date");
							}
							}
							catch(Exception e)
							{
								System.out.println("InValid date fromat ");
								System.out.println("Enter from date again in 'yyyy-mm-dd' format");
							}
							
						}

						flag = 0;
						flag1 = 0;
						System.out.println("Enter to date in format yyyy mm dd");
						while(toDateFlag)
						{
							System.out.println("Enter year");
							toYear = scanner.nextInt();
							System.out.println("Enter month");
							toMonth = scanner.nextInt();
							System.out.println("Enter date");
							toDate = scanner.nextInt();
							try
							{
							tDate = LocalDate.of(toYear, toMonth, toDate);
							if (employeeService.validateTODate(fDate,tDate)) {
                                toDateFlag=false;
							}
							else
							{
								System.out.println("From date can't be less than from Date or can't be greater than 45 days from fromdate");
							}
							}
							catch(Exception e)
							{
								System.out.println("InValid date fromat ");
								System.out.println("Enter To date again in 'yyyy-mm-dd' format");
							}
							
						}


						System.out.println("Enter reason for leave");
						String reason = scanner.next();
						int empId = employeeService.getIdFromUsername(userName);// write code to get access present
										// employee id from loginDatabase;
						//Also get the manager manager id of employee 
						int mgrId=employeeService.getManagerId(empId);
						Leave leave = new Leave(fDate, tDate, today, false, empId, mgrId, reason);
						boolean leaveStatus = employeeService.addLeave(leave);
						if (leaveStatus) {
							System.out.println("Sucessfully");
						}
						break;
						
					case "6":
						
					
					      fromDateFlag=true;
					      toDateFlag=true;
					      fDate=null;
					      tDate=null;
					   //   LocalDate today1 = null;
						System.out.println("Enter leave id to modify leave");
						leaveId = scanner.nextInt();
						int empid = employeeService.getIdFromUsername(userName);
						boolean checkExist = employeeService.checkIfLeavePending(leaveId,empid);
						if(checkExist)
						{
						System.out.println("Enter from date in the format yyyy mm dd");
						while(fromDateFlag)
						{
							System.out.println("Enter year");
							fromYear = scanner.nextInt();
							System.out.println("Enter month");
							fromMonth = scanner.nextInt();
							System.out.println("Enter date");
							fromDate = scanner.nextInt();
							try
							{
							fDate = LocalDate.of(fromYear, fromMonth, fromDate);
							if (employeeService.validateFromDate(fDate)) {
                                fromDateFlag=false;
							}
							else
							{
								System.out.println("From date can't be less than present date");
							}
							}
							catch(Exception e)
							{
								System.out.println("InValid date fromat ");
								System.out.println("Enter from date again in 'yyyy-mm-dd' format");
							}
							
						}

						flag = 0;
						flag1 = 0;
						System.out.println("Enter to date in format yyyy mm dd");
						while(toDateFlag)
						{
							System.out.println("Enter year");
							toYear = scanner.nextInt();
							System.out.println("Enter month");
							toMonth = scanner.nextInt();
							System.out.println("Enter date");
							toDate = scanner.nextInt();
							try
							{
							tDate = LocalDate.of(toYear, toMonth, toDate);
							if (employeeService.validateTODate(fDate,tDate)) {
                                toDateFlag=false;
							}
							else
							{
								System.out.println("From date can't be less than from Date or can't be greater than 45 days from fromdate");
							}
							}
							catch(Exception e)
							{
								System.out.println("InValid date fromat ");
								System.out.println("Enter To date again in 'yyyy-mm-dd' format");
							}
							
						}
						

						Leave editedLeave = employeeService.editLeave(leaveId, fDate, tDate);
						System.out.println("leave modified to: " + editedLeave);
						}
						else
						{
							System.out.println("Can't be edited as leave is already reviewed by the manager or Leave id not belongs to you");
						}
						break;

					case "7":
						
						List<Leave> leaveList = new ArrayList<Leave>();
						 empid = employeeService.getIdFromUsername(userName);
//						int leave
						leaveList = employeeService.SearchLeave(empid);
						if(leaveList.size()==0)
						{
							System.out.println("You have no applied leaves");
						}
						else
						{
						for(Leave l : leaveList) {
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",
									"Leave Id","Employee Id","Manager Id","From Date","To Date","Applied Date"
									,"Reason for leave","Leave Status");
							System.out.printf("%-25s%-25s%-25s%-25s%-25s%-25s%-25s%-25s\n",
								l.getLeaveId(),l.getEmpId(),l.getManagerId(),l.getFromDate(),
								l.getToDate(),l.getAppliedDate(),l.getReason(),l.getStatus());
						}
						}
						break;

					case "8":
						
						System.out.println("Enter the leave Id to cancell the leave applied");
						leaveId = scanner.nextInt();
						empid = employeeService.getIdFromUsername(userName);
						boolean checkExists = employeeService.checkIfLeavePending(leaveId,empid);
						if(checkExists)
						{
						boolean cancellApprovalStatus = employeeService.cancelLeave(leaveId);
						if (cancellApprovalStatus) {
							System.out.println("Leave is cancelled successfully");
						}
						else
						{
							System.out.println("Leave can't be cancelled as you can cancel leave only before 3 days from applied date");
						}
						}
						else
						{
							System.out.println("Can't be cancelled as leave is already reviewed by the manager or Leave id not belongs to you");
						}
						break;
					case "9":
						operation = false;
						break;
					default:
						System.out.println("Enter Valid Choice");
					}
				}

			} 
			else {
				System.out.println("Invalid login credentials");
			}
			//scanner.close();
			
		}

	}

}
