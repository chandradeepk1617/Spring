package com.cg.employeemanagement.exception;

public class EmpException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public EmpException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
