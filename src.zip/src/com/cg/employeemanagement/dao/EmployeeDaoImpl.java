package com.cg.employeemanagement.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;



public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO employee should be able to search other employee details based on employee id
		return null;
	}

	@Override
	public Employee displayEmpDetails() {
		// TODO The function should display the employee details like id,sal,name,dept_id etc.
		return null;
	}

	@Override
	public boolean changeAccountPassword(String oldPassword,String newPassword) {
		// TODO the function should change the password for the employee login details in login class
		return false;
	}

	@Override
	public int checkAttendance() {
		// TODO the function should return the number of leaves remaining for the employee.
		return 0;
	}
	
	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO the function should check the date on which the leave was applied if it is less than 3 days then only 
		//it should able to delete the leave applied by the employee or else it can't be done 
		return false;
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO the function should add the leave details for the employee and should not decrease the leave count 
		//unless it is accepted which should be done in manager interface implementation
		return false;
	}

	@Override
	public Leave editLeave(int leaveId, LocalDate fromDate,LocalDate toDate) {
		// The function should modify the leave details for this the leave status should be checked and the applied date should be verified.
		return null;
	}

	@Override
	public Leave SearchLeave(int leaveId) {
		// the employee should search their leaves.(return can be changed if you want)
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return null;
	}

}
