package com.cg.employeemanagement.dto;

import java.time.LocalDate;

public class Leave {
	private int leaveId;
	private LocalDate fromDate;
	private LocalDate toDate;
	private LocalDate appliedDate;
	private boolean leaveStatus;
	private int empId;
	private int managerId;
	private static int idLeave=1;
	
	public Leave(LocalDate fromDate, LocalDate toDate, LocalDate appliedDate, boolean leaveStatus, int empId,int managerId) {
		super();
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.appliedDate = appliedDate;
		this.leaveStatus = leaveStatus;
		this.empId = empId;
		this.leaveId=idLeave;
		this.managerId=managerId;
		idLeave++;
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public LocalDate getFromDate() {
		return fromDate;
	}
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}
	public LocalDate getToDate() {
		return toDate;
	}
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}
	public LocalDate getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}
	public boolean isLeaveStatus() {
		return leaveStatus;
	}
	public void setLeaveStatus(boolean leaveStatus) {
		this.leaveStatus = leaveStatus;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	
	
}
