package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.dao.ManagerDao;
import com.cg.employeemanagement.dao.ManagerDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;





public class ManagerServiceImpl implements ManagerService{
	
	ManagerDao managerDao=new ManagerDaoImpl();
	
	@Override
	public Employee searchEmployeeById(int empId) {
		
		return managerDao.searchEmployeeById(empId);
	}
	
	@Override
	public List<Employee> searchEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return managerDao.searchEmployeeByName(name);
	}
	
	@Override
	public Employee displayOwnDetails(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displayOwnDetials(userName);
	}

	@Override
	public List<Employee> displaySubEmployees(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displaySubEmployees(userName);
	}
	
	@Override
	public List<Leave> showLeavesApplied(String userName) {
		// TODO Auto-generated method stub
		return managerDao.showLeavesApplied(userName);
	}
	
	@Override
	public boolean accept(int leaveId) {
		// TODO Auto-generated method stub
		return managerDao.accept(leaveId);
	}

	@Override
	public boolean reject(int leaveId,String reason) {
		// TODO Auto-generated method stub
		return managerDao.reject(leaveId,reason);
	}

	

	

	


}
