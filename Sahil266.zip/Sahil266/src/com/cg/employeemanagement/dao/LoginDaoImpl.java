package com.cg.employeemanagement.dao;


import java.util.List;

import com.cg.employeemanagement.dto.Login;
import com.cg.employeemanagement.entity.LoginDatabase;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean validate(String userName, String pwd, String userRole) {
		// function should check username and pwd from static loginDB present.
		// LoginDatabase loginDatabase=new LoginDatabase();
		List<Login> list= LoginDatabase.getLoginDetails();
		String userType=null;;
		if(userRole.equals("1"))
		{
			userType="admin";
		}
		else if(userRole.equals("2"))
			userType="manager";
		else if(userRole.equals("3"))
			userType="employee";
			
		for(Login l1:list)
		{
			
			if(l1.getUserName().equals(userName)
					&& l1.getPassword().equals(pwd)
					&& l1.getLoginType().equals(userType))
			{
				return true;
			}
		}
		return false;
	}

}
