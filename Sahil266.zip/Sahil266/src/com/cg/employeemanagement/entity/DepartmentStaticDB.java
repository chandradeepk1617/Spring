package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Department;


public class DepartmentStaticDB {
	private static List<Department> departmentList=new ArrayList<Department>();
	static
	{
		departmentList.add(new Department(101,"software"));
		departmentList.add(new Department(102,"IT"));
		departmentList.add(new Department(103,"Trainee"));
		departmentList.add(new Department(104,"Hacking"));
		departmentList.add(new Department(105,"programming"));
	}
	public static List<Department> getDepartmentList() {
		return departmentList;
	}
	public static void setDepartmentList(List<Department> departmentList) {
		DepartmentStaticDB.departmentList = departmentList;
	}
	
}
