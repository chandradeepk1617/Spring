package com.cg.employeemanagement.entity;


import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Leave;

public class ReviewedLeavesStaticDB {
	private static List<Leave> leavesList=new ArrayList<Leave>(); 
	public List<Leave> getLeavesList()
	{
		return leavesList;
	}
	public boolean add(Leave leave)
	{
		leavesList.add(leave);
		return true;
	}
}
