package com.cg.employeemanagement.validations;

import java.util.regex.Pattern;

public class Validation {
	public boolean validateEmpId(String empId)
	{
		return Pattern.matches("[0-9]{1,6}",empId);
		
			
	}

}
