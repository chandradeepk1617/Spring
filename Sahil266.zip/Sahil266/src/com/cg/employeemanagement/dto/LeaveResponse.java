package com.cg.employeemanagement.dto;

public class LeaveResponse {
	
	private int leaveId;
	private String reason;
	int empId;
	
	public LeaveResponse(int empId, int leaveId, String reason) {
		super();
		this.leaveId = leaveId;
		this.reason = reason;
		this.empId=empId;
	}
	@Override
	public String toString() {
		return "LeaveResponse [leaveId=" + leaveId + ", reason=" + reason + ", empId=" + empId + "]";
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	

}
