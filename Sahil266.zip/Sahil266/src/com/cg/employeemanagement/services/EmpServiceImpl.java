package com.cg.employeemanagement.services;

import java.time.Duration;
import java.time.LocalDate;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.validations.Validation;

public class EmpServiceImpl implements EmpService {

	EmployeeDao employeeDao = new EmployeeDaoImpl();
	Validation valid = new Validation();

	@Override
	public Employee searchEmployeeById(String empId) {
		boolean flag = valid.validateEmpId(empId);
		if(flag){
		int eId=Integer.parseInt(empId);
		return employeeDao.searchEmployeeById(eId);
		}
		else{
			return new Employee(0);
		}
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeByName(fName);
	}

	@Override
	public Employee displayEmpDetails(String userName) {
		// TODO Auto-generated method stub
		return employeeDao.displayEmpDetails(userName);
	}

	@Override
	public boolean changeAccountPassword(String userName, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		return employeeDao.changeAccountPassword(userName, oldPassword, newPassword);
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO Auto-generated method stub
		return employeeDao.addLeave(leave);
	}

	@Override
	public Leave editLeave(int leaveId, LocalDate fromDate, LocalDate toDate) {
		// TODO Auto-generated method stub
		return employeeDao.editLeave(leaveId, fromDate, toDate);
	}

	@Override
	public List<Leave> SearchLeave(int empId) {
		// TODO Auto-generated method stub
		return employeeDao.SearchLeave(empId);
	}

	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO Auto-generated method stub
		return employeeDao.cancelLeave(leaveId);
	}

	public boolean validateFromDate(LocalDate fromDate) {
		if (fromDate.compareTo(LocalDate.now()) < 0) {
			return false;
		} else {
			//this checks whether the from date is less than 45 days from present date
//			Period period = Period.between(LocalDate.now(), fromDate);
//			int months = period.getMonths();
//			int years = period.getYears();
//			System.out.println(months);
//			System.out.println(years);
			// System.out.println(days);
			Duration duration = Duration.between(LocalDate.now().atStartOfDay(),fromDate.atStartOfDay());
			Long days = duration.toDays();
			if(days>60)
			{
				return  true;
			}
			else
				return false;
		}
	}

	public boolean validateTODate(LocalDate fromDate, LocalDate toDate) {
		
//This checks whether the to date is greater than from date and should be less than 10 days from from date
		if(fromDate.compareTo(toDate)<0)
		{
			Duration duration = Duration.between(LocalDate.now().atStartOfDay(),fromDate.atStartOfDay());
			Long days = duration.toDays();
			if(days<60)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
		
		
		
		
	}
	public boolean isValidYear(String year,String yearPattern)
	{
		if(Pattern.matches(yearPattern,year))
		{
			return true;
		}
		else
			return false;
	}
	public boolean isValidMonth(int month)
	{
		if(month<=0||month>12)
		{
			return false;
		}
		else
			return true;
	}
	public boolean isValidDay(int day,int month,int year)
	{
		if(year%4==0&&year%400==0)
		{
			if(month==2||month==4||month==6||month==9||month==11)
			{
				if(month==2)
				{
					if(day<=0||day>29)
					{
						return false;
					}
					else
						return true;
				}
				else
				{
					if(day<=0||day>30)
					{
						return false;
					}
					else
					{
						return true;
					}
				}
			
					}
			else
			{
				if(day<=0||day>31)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}
		else
		{
		
		
		if(month==2||month==4||month==6||month==9||month==11)
		{
			if(month==2)
			{
				if(day<=0||day>28)
				{
					return false;
				}
				else
					return true;
			}
			else
			{
				if(day<=0||day>30)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		
				}
		else
		{
			if(day<=0||day>31)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		}
		}
	public boolean validatePassword(String newPassword,String passwordPattern)
    {
    	if(Pattern.matches(passwordPattern, newPassword))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	public boolean changeAccountPassword(String newPassword,String userName)
	{
		return employeeDao.changeAccountPassword(newPassword, userName);
	}

    public boolean checkOldPassword(String oldPassword,String userName)
    {
    	return employeeDao.checkOldPassword(oldPassword,userName);
    }
    public int getIdFromUsername(String userName)
    {
    	return employeeDao.getIdFromUsername(userName);
    }
    public int getManagerId(int empId)
    {
    	return employeeDao.getManagerId(empId);
    }
    public boolean checkIfLeavePending(int leaveId)
    {
    	return employeeDao.checkIfLeavePending(leaveId);
    }
}
