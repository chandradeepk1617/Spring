import java.time.*;
import java.util.*;

public class AcceptDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate a = LocalDate.of(2013,1,22);
		LocalDate date1 = LocalDate.now();
		System.out.println(a);
System.out.println(date1);		
		//Period diff  = Period.between(a,date1);
          Period diff = Period.between(a, date1);
	System.out.println(diff.getDays());
	System.out.println(diff.getMonths());
	System.out.println(diff.getYears());
	}

}
