package com.cg.mobilePurchase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;

import com.cg.mobilePurchase.dto.MobileDTO;

public class CustomerServiceImpl implements CustomerInterface {

	Connection con;
	@Override
	public boolean addMobile(MobileDTO mobile) {
		int rec=0;
		try {
			con = DatabaseConnectivity.getConnection();
		System.out.println(con);
			String query="INSERT INTO mobiles VALUES(?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1,mobile.getMobileid());
		//pst.setInt(2,mobile.getMobileid());
		pst.setString(2,mobile.getName());
		pst.setInt(3,mobile.getPrice());
        pst.setInt(4,mobile.getQuantity());		
		rec = pst.executeUpdate();
				
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rec!=0)
		{
			System.out.println(rec+" Records inserted");
            return true;		
		}
		else
			return false;

		
	}

	@Override
	public HashSet<MobileDTO> displayMobiles() {
		MobileDTO mobile=null;
		HashSet<MobileDTO> mobileHashSet = new HashSet<MobileDTO>();
		try {
		
			con = DatabaseConnectivity.getConnection();
			String query = "SELECT * FROM mobiles";
			PreparedStatement pst =con.prepareStatement(query);
			ResultSet rs1 = pst.executeQuery();
			while(rs1.next())
			{
		      //System.out.println(rs1.getInt(1),);
				mobile = new MobileDTO(rs1.getInt(1),rs1.getString(2),rs1.getInt(3),rs1.getInt(4));
		      mobileHashSet.add(mobile);
			}
			for(MobileDTO mob:mobileHashSet)
			System.out.println(mob);
		
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return mobileHashSet;
	}

}
