package com.cg.mobilePurchase.dao;

import java.util.ArrayList;
import java.util.HashSet;

import com.cg.mobilePurchase.dto.MobileDTO;

public interface CustomerInterface {
	boolean addMobile(MobileDTO mobile);
	HashSet<MobileDTO>displayMobiles();
	
	}
