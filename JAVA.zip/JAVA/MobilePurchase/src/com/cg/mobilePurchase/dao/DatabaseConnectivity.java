package com.cg.mobilePurchase.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectivity {

	static Connection con=null;
	
	public static Connection getConnection() throws SQLException
	{
		
		if(con==null)
		{
			try
					{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sys as sysdba","Capgemini123");
		System.out.println("HOOOOO");
					}
		catch(Exception E)
		{
			System.out.println("Exception");
		}
			}
		System.out.println(con);
		return con;
	}
}
