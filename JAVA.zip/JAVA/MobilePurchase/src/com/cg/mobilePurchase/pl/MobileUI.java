package com.cg.mobilePurchase.pl;

import java.util.HashSet;
import java.util.Scanner;

import com.cg.mobilePurchase.dao.CustomerServiceImpl;
import com.cg.mobilePurchase.dto.MobileDTO;

public class MobileUI {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CustomerServiceImpl cust=new CustomerServiceImpl();
		int choice;
		int flag=0;
		int id=0;
		String name="";
		int price=0;
		int quantity=0;
		while(flag!=1)
		{
			System.out.println("1 for Adding Mobile Into Database");
			System.out.println("2 for Displaying Mobiles");
			System.out.println("Enter choice");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter Mobile ID");
				id=sc.nextInt();
				System.out.println("Enter Mobile Name");
				name=sc.next();
				System.out.println("Enter Price");
				price=sc.nextInt();
				System.out.println("Enter Quantity");
				quantity=sc.nextInt();
				MobileDTO obj = new MobileDTO(id,name,price,quantity);
				System.out.println(obj.getMobileid()+obj.getName()+obj.getPrice()+obj.getQuantity());
				cust.addMobile(obj);
			case 2:
				HashSet<MobileDTO> hash = new HashSet<MobileDTO>();
				hash=cust.displayMobiles();
			
			}
			
		}

	}

}
