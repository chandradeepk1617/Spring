package com.cg.mobilePurchase.dto;

import java.sql.Date;

public class CustomerPurchase {
	private int purchaseId;
	private int cname;
	private String mail;
	private Long phnNo;
	private Date purchaseDate;
	private int mobileid;
	public CustomerPurchase()
	{
		
	}
	public CustomerPurchase(int purchaseId, int cname, String mail, Long phnNo, Date purchaseDate,
			int mobileid) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.mail = mail;
		this.phnNo = phnNo;
		this.purchaseDate = purchaseDate;
		this.mobileid = mobileid;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getCname() {
		return cname;
	}
	public void setCname(int cname) {
		this.cname = cname;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public Long getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(Long phnNo) {
		this.phnNo = phnNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	@Override
	public String toString() {
		return "CustomerPurchase [purchaseId=" + purchaseId + ", cname=" + cname + ", mail=" + mail + ", phnNo=" + phnNo
				+ ", purchaseDate=" + purchaseDate + ", mobileid=" + mobileid + "]";
	}
	
	

}
