package com.cg.mobilePurchase.dto;

public class MobileDTO implements Comparable{
	@Override
	public boolean equals(Object obj) {
		
	
		MobileDTO mobile =(MobileDTO)obj;
		if(this.mobileid==mobile.mobileid)
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	private int mobileid;
	private String name;
	private int price;
	private int quantity;
	public MobileDTO()
	{
		
	}
	public MobileDTO(int mobileid, String name, int price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
	}
	@Override
	public int compareTo(Object obj) {
		// TODO Auto-generated method stub
		MobileDTO mob1=(MobileDTO)obj;
		if(this.mobileid<mob1.mobileid)
			return -1;
		else if(this.mobileid>mob1.mobileid)
			return +1;
		else
			return 0;
	}
	

}
