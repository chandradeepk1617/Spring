
public class TestLambda2 {

	public static void main(String[] args) {
	LambdaAssignment2 lambda = (name)->
	{
		String name1="";
		String name2[]=name.split("");
		for(int i=0;i<name2.length;i++)
		{
			name1 = name1+name2[i]+" ";
		}
		return name1;
	};
	System.out.println(lambda.format("Chandu"));
	}

}
