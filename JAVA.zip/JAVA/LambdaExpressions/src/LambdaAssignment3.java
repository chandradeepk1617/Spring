
public interface LambdaAssignment3 {
	Boolean validate(String user,String pwd); 

}
