
public interface LambdaAssignment2 {
String format(String name);
}
