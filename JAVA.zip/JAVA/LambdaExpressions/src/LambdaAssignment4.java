
public interface LambdaAssignment4 {
public void set(int id);

}
