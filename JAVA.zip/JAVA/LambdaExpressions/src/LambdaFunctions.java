
public interface LambdaFunctions {
	int power(int x,int y);

}
