
public class TestLambda {

	public static void main(String[] args) {
		LambdaFunctions lambda = (num1,num2)->
		{
			return (int)Math.pow(num1, num2);
		};
System.out.println(lambda.power(4, 5));
	}

}
