import java.util.function.Function;



public class TestLambda3 {
	public static int factorial(int num)
	{
		int fact=1;
		for(int i=0;i<num;i++)
		{
			fact=fact*i;
		}
		//System.out.println(fact);
	return fact;
	}

	public static void main(String[] args) {
		LambdaAssignment3 lambda = (user,pwd)->
		{
			String uname = "chandu";
			String password = "chandu123";
			if(user.equals(uname)&&password.equals(pwd))
			{
				return true;
			}
			else
				return false;
		};
		System.out.println(lambda.validate("chandu","chandu123"));
		Function<Integer,Integer> fact=TestLambda3::factorial; 
		
		System.out.println(fact.apply(6));
		LambdaAssignment4 lambda5 = new Student()::setId;
		lambda5.set(5);
		
	}

}
