package com.cg.eis.bean;


public class Employee {
	public String name;
	public int id;
	public int sal;
	//enum desig g;
	public String designation;
	public String insuranceScheme;
	public Employee()
	{
		
	}
	public Employee(String name, int id, int sal) {
		super();
		this.name = name;
		this.id = id;
		this.sal = sal;
	
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", sal=" + sal + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}
	
	
	}
