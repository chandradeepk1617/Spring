package com.cg.eis.service;
import com.cg.eis.bean.*;

public interface EmployeeService {
	public void setInsuranceScheme(int sal,Employee e);

}
