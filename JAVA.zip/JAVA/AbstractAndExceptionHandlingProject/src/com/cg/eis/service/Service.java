package com.cg.eis.service;
import com.cg.eis.bean.*;
public class Service implements EmployeeService {
	public void setInsuranceScheme(int sal,Employee e)
	{
		if(e.sal<5000 && e.sal>3000)
		{
		e.insuranceScheme = "no scheme";
		e.designation = "CLERK";
		}
		else if(e.sal>5000 && e.sal<20000)
		{
			e.insuranceScheme = "Scheme c";
		     e.designation = "System Associate";
		}
			else if(e.sal>20000 && e.sal<40000)
		{
				e.insuranceScheme = "Scheme B";
		e.designation="Programmer";
		}
		else
		{
			e.insuranceScheme = "Scheme A";
		e.designation="Manager";
		}
		
	}
}
