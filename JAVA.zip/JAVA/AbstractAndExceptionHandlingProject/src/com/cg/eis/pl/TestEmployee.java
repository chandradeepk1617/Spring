package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
import java.util.Scanner;

public class TestEmployee extends Exception {
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		Employee emp[] =new Employee[4];
		Service s = new Service();
		int sal = 0;
		for(int i=0;i<4;i++)
		{
		System.out.println("Enetr name");
		String name = sc.next();
		System.out.println("Enetr id");
		int id = sc.nextInt();
		System.out.println("Enetr sal");
		try
		{
		sal = sc.nextInt();
		if(sal<3000)
		{
	    throw new TestEmployee();
	   
		}
	    
		
		}
		 
		catch(TestEmployee ae)
		{
			System.out.println("Cant enter below 3000");
			System.out.println(ae.getMessage());
			
		}
		finally
		{
			emp[i]=new Employee(name,id,sal);
		}
		
		}
		
		for(int i=0;i<4;i++)
		{
			s.setInsuranceScheme(emp[i].sal,emp[i]);
		}
		for(int i=0;i<4;i++)
		{
			System.out.println(emp[i]);
		}
		
	}
	

}
