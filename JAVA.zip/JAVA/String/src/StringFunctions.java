
public class StringFunctions {
    public void add(String a)
    {
    	System.out.println(a+a);
    }
    public void replace2(StringBuilder a)
    {
    	
    	for(int i=0;i<a.length();i++)
    	{
    		if(i%2!=0)
    			a.replace(i,i+1,"#");
    	}
    	System.out.println(a);
    }
    
    
    
    public void replaceUpper(StringBuilder a1)
    {
    	String s;
    	for(int i=0;i<a1.length();i++)
    	{
    		if(i%2!=0)
    		{
    		      s= String.valueOf(a1.charAt(i));
    		      s=s.toUpperCase();
    			a1.replace(i,i+1,s);
    		}
    	}
    	System.out.println(a1);
    }
    public void Positive(StringBuilder a)
    {
    	int j=0;
    	String x,y;
    	for(int i=0;i<a.length()-1;i++)
    	{
    		j=0;
    		x=String.valueOf(a.charAt(i));
    		y=String.valueOf(a.charAt(i+1));
    		j=x.compareTo(y);
    		if(j>0)
    		{
    			System.out.println("Negative");
    		    break;
    		}
    	}
    	if(j<0)
    		System.out.println("Positive");
    	
    	
    	
    }
    public void replace1(StringBuilder a)
    {
    	int len=a.length();
    	for(int i=0;i<len;i++)
    	{
    		
   
    		
    		for(int j=i+1;j<len;j++)
    		{
    			
    			if(a.charAt(i)==a.charAt(j))
    			{
    				a.delete(j, j+1);
    				len--;
    				j--;
    			}
    			
    		}
    	
    		
    	}
    	System.out.println(a);
    	
    }
	public static void main(String[] args) {
		String s = "chandu";
		StringBuilder s1 = new StringBuilder(s);
		StringBuilder s2 = new StringBuilder(s);
		StringBuilder s3 = new StringBuilder("ACB");
		
		StringFunctions str= new StringFunctions();
		str.replace1(s1);
        str.add(s); 
        str.replace2(s1);
        str.replaceUpper(s2);
        str.Positive(s3);
      
	}

}
