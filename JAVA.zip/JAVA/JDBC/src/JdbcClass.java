
import java.io.FileReader;
import java.sql.*;
import java.util.Enumeration;
import java.util.Properties;

import org.omg.Messaging.SYNC_WITH_TRANSPORT;
public class JdbcClass {

	public static void main(String[] args)  {
		
//Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="";
		String user="";
		String pwd="";
		FileReader fr = null;
		Properties props=null;
		try
		{
			fr = new FileReader("resource/oracle.properties");
	       	props = new Properties();
	       	props.load(fr);
		
		 Enumeration en = props.keys();
		 url=props.getProperty("jdbc.url");
		 user=props.getProperty("jdbc.user");
		 pwd=props.getProperty("jdbc.password");
		 		 	
		 
		 Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sys as sysdba","Capgemini123");
	 Statement st = con.createStatement();
		
		String query = "INSERT INTO emp(EMPNO,ENAME)VALUES(?,?)";
		String query2 = "DELETE FROM emp WHERE EMPNO=?";
		String query1 = "UPDATE EMP SET ENAME =? WHERE EMPNO =?";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1,120);
		pst.setString(2,"chandu");
		int rec = pst.executeUpdate();
		System.out.println(rec);
		System.out.println(rec);
		PreparedStatement pst3 = con.prepareStatement(query1);
		pst3.setString(1,"chanduReddy");
		pst3.setInt(2, 120);
		PreparedStatement pst2 = con.prepareStatement(query2);
		//pst2.setInt(1,120);
		pst2.setInt(1,120);
		rec = pst2.executeUpdate();
		System.out.println(rec);
//		pst.executeQuery(query2);
		 ResultSet rs = st.executeQuery("SELECT EMPNO,ENAME,JOB,HIREDATE FROM emp");
		 while(rs.next())
		{
			System.out.println("EMP NO = "+rs.getInt(1)+ "EMP NAME = "+rs.getString(2)+" JOB = "+rs.getString(3)+" HIREDATE = "+rs.getDate(4));
			
			
		}
		}
		 catch (Exception e)
		 {
		 	e.printStackTrace();
		 }
finally
{
	System.out.println("EXECUTED");
}

	}
}
