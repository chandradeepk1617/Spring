
public class TestPaintAppDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape sh1 = new Circle(7);
		Shape sh2 = new Sphere(7);
		Printable sh3 = new Circle(8);
		sh1.drawShape();
		System.out.println("Area of Circle"+sh1.calcArea());
		System.out.println("Circumference of Circle"+sh1.calcPerimeter());
		System.out.println("Print Radius"+((Circle)sh1).print());
		sh2.drawShape();
		System.out.println("Area of Sphere"+sh2.calcArea());
		System.out.println("Volume of Sphere"+((Sphere)sh2).calcVolume());
		System.out.println("Print Radius"+((Sphere)sh2).print());
		((Circle)sh3).drawShape();
		System.out.println("Area of Circle"+((Circle)sh3).calcArea());
		System.out.println("Circumference of Circle"+((Circle)sh3).calcPerimeter());
		System.out.println("Print Radius"+((Circle)sh3).print());
	}

}
