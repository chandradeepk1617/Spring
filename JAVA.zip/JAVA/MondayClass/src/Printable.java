
public interface Printable {
	int finalValue =10;
	public String print();

}
