import static java.lang.Math.*;
public class Circle extends Shape
implements Printable
{
	int radius;
	public Circle()
	{
		
	}
	public Circle(String type)
	{
		super(type);
	}
	public Circle(int radius)
	{
		super("Circle");
		this.radius = radius;
	}
	public float calcArea()
	{
		return ((float)(PI*radius*radius));
	}
	public float calcPerimeter()
	{
		return ((float)(2*PI*radius));
	}
	public String print()
	{
		return "Type "+type+"\n"+"Radius: "+radius;
	}
	

}
