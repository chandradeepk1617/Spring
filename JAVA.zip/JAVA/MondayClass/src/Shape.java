
public abstract class Shape {
	String type;
	public Shape()
	{
		
	}
	public Shape( String type)
	{
		this.type = type;
	}
public void drawShape()
{
	System.out.println(type+"DRAW IT IN RED COLOR");
}
public abstract float calcArea();

public abstract float calcPerimeter();
}
