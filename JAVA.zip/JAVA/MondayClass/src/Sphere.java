import static java.lang.Math.PI;

public class Sphere extends Circle {
	int radius;
	public Sphere()
	{
		
	}
	public Sphere(int radius)
	{
		super("Sphere");
		this.radius = radius;
	}
	public float calcArea()
	{
		return ((float)(PI*radius*radius));
	}
	public float calcPerimeter()
	{
		return ((float)(2*PI*radius));
	}
	public float calcVolume()
	{
		return ((float)((4.0/3.0)*PI*Math.pow(radius, 3)));
	}
	

}
