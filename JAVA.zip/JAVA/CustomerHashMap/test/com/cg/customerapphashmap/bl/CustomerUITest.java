package com.cg.customerapphashmap.bl;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.customerapphashmap.pl.CustomerUI;


public class CustomerUITest {
	boolean flag;
	CustomerUI cust= new CustomerUI();
	@Before
	public void start()
	{
		System.out.println("start");
	}
	@Test
	public void test() {
		//fail("Not yet implemented");
	flag = cust.isValid(1234);
	assertTrue(flag);
	}
	@Test
	public void Test()
	{
	flag = cust.isValid("chandu@gmail.com");
	assertTrue(flag);
	}
	@Test
	public void testName()
	{
		flag=cust.isValidName("Chandu");
		assertTrue(flag);
	}
	@Test
	public void testPhone()
	{
		flag = cust.isValidPhone("9963673280");
		assertTrue(flag);
	}
	
	@After
	public void stop()
	{
		System.out.println("stop");
	}

}