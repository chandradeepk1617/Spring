package com.cg.customerapphashmap.pl;
import com.cg.customerapphashmap.dao.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import com.cg.customerapphashmap.dto.*;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Pattern;

import com.cg.customerapphashmap.bl.*;
public class CustomerUI {
	String idPattern = "[^0][0-9]{0,5}";
	String emailPattern = "[a-z]{1,15}[@][a-z]{2,6}[.][a-z]{2,5}";
	String phonePattern = "[^0][0-9]{1,9}";
	String namePattern = "[A-Z]{1,1}[a-z]{1,25}";
	public boolean isValid(int id)
	{
		if(Pattern.matches(idPattern,String.valueOf(id)))
		return true;
		else
		{
		System.out.println("Wrong format");
		return false;
		}
	}
	public boolean isValid(String email)
	{
		if(Pattern.matches(emailPattern,email))
		return true;
		else
		{
		System.out.println("Wrong format");
		return false;
		}
	}
	public boolean isValidPhone(String phone)
	{
		if(Pattern.matches(phonePattern,phone))
			return true;
			else
			{
			System.out.println("Wrong format");
			return false;
			}
	}
	public boolean isValidName(String name)
	{
		if(Pattern.matches(namePattern,name))
			return true;
			else
			{
			System.out.println("Wrong format");
			return false;
			}
	}
public static void main(String[] args) {
		
		int id=0;
		String name="";
		String address="";
		String email="";
		String phone="";
		
		CustomerServiceImpl custImpl = new CustomerServiceImpl();
	   CustomerUI ui = new CustomerUI();
		Scanner sc=new Scanner(System.in);
		int choice;
		int flag=0;
		while(flag<6)
		{
			System.out.println("1. Add a Customer");
			System.out.println("2. Delete a Customer");
			System.out.println("3. Modify a Customer");
			System.out.println("4. Delete all Customers");
			System.out.println("5. fetch all Customers");
			System.out.println("6. Fetch Customer By Name");
			System.out.println("7. Fetch Customer By Id");
			System.out.println("8. Terminate");
		    System.out.println("Enter Your Choice");
		    choice = sc.nextInt();
		    switch(choice)
		    {
		    case 1:
		    	System.out.println("Enter Customer Id");
		    	flag=0;
		    	while(flag!=1)
		    	{
		    	id = sc.nextInt();
		    	if(ui.isValid(id))
		    	{
		    		flag=1;
		    	}
		    	else
		    	{
		    		System.out.println("Enter Id Again");
		    	}
		    	}
		    	flag=0;
		    	System.out.println("Enter Customer Name");
		    	while(flag!=1)
		    	{
		    	name = sc.next();
		    	if(ui.isValidName(name))
		    		flag=1;
		    	else
		    		System.out.println("Enter Name Again");
		    	}
		    	flag=0;
		    	System.out.println("Enter Customer Email");
		        while(flag!=1)
		        {
		    	email = sc.next();
		        if(ui.isValid(email))
		        	flag=1;
		        else
		        	System.out.println("Enter Email Again");
		        }
		        flag=0;
		    	System.out.println("Enter Customer PhoneNumber");
		    	while(flag!=1)
		    	{
		    	phone = sc.next();
		    	if(ui.isValidPhone(phone))
		    		flag=1;
		    	else
		    		System.out.println("Enter PhoneNumber Again");
		    	}
		    	System.out.println("Enter Customer Address");
		    	address = sc.next();
		    	CustomerDTO cust = new CustomerDTO(name,email,address,phone);
		    	HashMap<Integer,CustomerDTO> custHashMap1=new HashMap<Integer,CustomerDTO>();
		    	custImpl.addCustomer(id,cust);
		    	break;
		    case 2:
		    	System.out.println("Enter Id");
		    	id = sc.nextInt();
		    	boolean result =custImpl.deleteCustomer(id);
		    	if(result==false)
		    		System.out.println(id+"not found");
		    	break;
		    case 3:
		    	System.out.println("Enter Id");
		    	id=sc.nextInt();
		    	System.out.println("Enter Name");
		    	name = sc.next();
		    	custImpl.modifyCustomer(id,name);
		    	break;
		    case 4:
		    	custImpl.deleteAll();
		    	break;
		    case 5:
		    	HashMap<Integer,CustomerDTO> custHashMap2 = new HashMap<Integer,CustomerDTO>();
		    	custHashMap2=custImpl.fetchAll();
		    	Set<Entry<Integer,CustomerDTO>> entrySet = custHashMap2.entrySet();
		    	for(Entry entry:entrySet)
		    	{
		    		System.out.println("key :" +entry.getKey());
		    		System.out.println("value :"+entry.getValue());
		    	}
		    	break;
		    	
		    case 6:
		    	System.out.println("Enter Name");
		    	name = sc.next();
		    	HashMap<Integer,CustomerDTO> custHashMap3=new HashMap<Integer,CustomerDTO>();
		    	custHashMap3=custImpl.fetchCustomerByName(name);
		         entrySet = custHashMap3.entrySet();
		    	for(Entry entry:entrySet)
		    	{
		    		System.out.println(entry.getKey());
		    		System.out.println(entry.getValue());
		    	}
		    	break;
		    case 7:
		    	System.out.println("Enter Id");
		    	id=sc.nextInt();
		    	CustomerDTO fetchId = custImpl.fetchCustomerById(id);
		    	if(fetchId==null)
		    		System.out.println("Record with"+id+" not Found");
		    	else
		    	System.out.println(fetchId);
		    	break;
		    case 8:
		    	flag=7;
		    	break;
		    default:
		    	System.out.println("Enter Correct choice");
		    }
		}

	}

	



}
