package com.cg.customerapphashmap.bl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.customerapphashmap.dto.*;



public interface CustomerService {
	HashMap<Integer,CustomerDTO> custHashMap = new HashMap<Integer,CustomerDTO>();
boolean addCustomer(int id,CustomerDTO cust);
 boolean deleteCustomer(int id);
 boolean modifyCustomer(int id,String name);
 boolean deleteAll();
 HashMap fetchAll();
 CustomerDTO fetchCustomerById(int id);
 HashMap fetchCustomerByName(String name);

 
}
