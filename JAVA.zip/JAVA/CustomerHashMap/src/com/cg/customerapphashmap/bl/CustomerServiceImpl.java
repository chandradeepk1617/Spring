package com.cg.customerapphashmap.bl;
import com.cg.customerapphashmap.dto.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.regex.Pattern;

import com.cg.customerapphashmap.dao.*;
;
public class CustomerServiceImpl implements CustomerService {
    
	CustomerDAOImpl custDAO = new CustomerDAOImpl();
	@Override
	public boolean addCustomer(int id,CustomerDTO cust) {
		// TODO Auto-generated method stub
	
	
		return custDAO.addCustomer(id, cust);
	}

	@Override
	public boolean deleteCustomer(int id) {
		// TODO Auto-generated method stub
		return custDAO.deleteCustomer(id);
	}

	@Override
	public boolean modifyCustomer(int id, String name) {
		// TODO Auto-generated method stub
		return custDAO.modifyCustomer(id, name);
	}

	@Override
	public boolean deleteAll() {
		// TODO Auto-generated method stub
		return custDAO.deleteAll();
	}

	@Override
	public HashMap fetchAll() {
		// TODO Auto-generated method stub
		return custDAO.fetchAll();
	}

	@Override
	public CustomerDTO fetchCustomerById(int id) {
		// TODO Auto-generated method stub
		return custDAO.fetchCustomerById(id);
	}

	@Override
	public HashMap fetchCustomerByName(String name) {
		// TODO Auto-generated method stub
		return custDAO.fetchCustomerByName(name);
	}
	
	
}
