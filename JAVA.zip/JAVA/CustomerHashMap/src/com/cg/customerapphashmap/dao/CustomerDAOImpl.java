package com.cg.customerapphashmap.dao;
import com.cg.customerapphashmap.dto.CustomerDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class CustomerDAOImpl implements CustomerDAO {
	public CustomerDAOImpl()
	{
		PropertyConfigurator.configure("resource/customerlog.properties");
		
	}
	static Logger logger = Logger.getRootLogger();
	int index;
	int found;
	int rec=0;
	Connection con;
	public boolean addCustomer(int id,CustomerDTO cust) {
		try
		{
			con = DatabaseConnectivity.getConnection();	
			String query ="INSERT INTO customer_details VALUES(?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1,id);
			pst.setString(2, cust.getCustName());
			pst.setString(3, cust.getCustEmail());
			pst.setString(4, cust.getCustAddress());
			pst.setString(5, cust.getCustPhoneNumber());
			rec=pst.executeUpdate();
			System.out.println(rec+" records inserted");
			System.out.println("Successfully added");
			
		}
		catch(Exception E)
		{
			
			E.printStackTrace();
		}
	if(rec!=0)
	{
		logger.info("ADDING A CUSTOMER");
	return true;
	}
	else
		return false;
	
	
	}

	@Override
	public boolean deleteCustomer(int id) {
		int rec=0;
	try
	{
		Connection con = DatabaseConnectivity.getConnection();
	    String query = "DELETE FROM customer_details where CID=?";
	    PreparedStatement pst = con.prepareStatement(query);
	    pst.setInt(1, id);
	     rec=pst.executeUpdate();
	    System.out.println(rec+" Rows Deleted");
	}
	catch(Exception E)
	{
		E.printStackTrace();
		System.out.println("Exception");
	}
	if(rec!=0)
{
		logger.info("Deleting A CUSTOMER");
		return true;
}
	else
		return false;
	}

	@Override
	public boolean modifyCustomer(int id, String name) {
		int rec=0;
		try
		{
	     Connection con = DatabaseConnectivity.getConnection();
		String query ="UPDATE customer_details SET CNAME=? WHERE CID=?";
		PreparedStatement pst = con.prepareStatement(query);
		
		pst.setString(1,name);
		pst.setInt(2, id);
		rec = pst.executeUpdate();
		System.out.println(rec+" Rows Updated");
		}
		catch(Exception E)
		{
			E.printStackTrace();
		}
		if(rec!=0)
		{
			logger.info("Modifying A CUSTOMER");
		return true;
		}
		else
			return false;
	}

	@Override
	public boolean deleteAll() {
		int rec=0;
		try
		{
		Connection con =DatabaseConnectivity.getConnection();
		String query ="DELETE FROM customer_details";
		PreparedStatement pst = con.prepareStatement(query);
           rec=pst.executeUpdate();
           System.out.println(rec+"ROWS Deleted");
		}
		catch(Exception E)
		{
			System.out.println("Exception");
			E.printStackTrace();
		}
		if(rec!=0)
		{
			logger.info("Deleting all customers");
			return true;	
		}
		
		else
			return false;
	}

	@Override
	public HashMap fetchAll() {
		HashMap<Integer,CustomerDTO> custHash1 = new HashMap<Integer,CustomerDTO>();
		try
		{
			CustomerDTO cust = null;
			
			Connection con = DatabaseConnectivity.getConnection();
			Statement st = con.createStatement();
			String query = "SELECT * FROM customer_details";
			PreparedStatement pst =con.prepareStatement(query);
			ResultSet rs1 = pst.executeQuery();
			
		
			while(rs1.next())
		{
	        cust=new CustomerDTO(rs1.getString(2),rs1.getString(3),rs1.getString(4),rs1.getString(5));
		    custHash1.put(rs1.getInt(1),cust);  
		}
			}
		catch(Exception E)
		{
			System.out.println("exception");
		}
		logger.info("Fetch all customers finished");
		
		return custHash1;
	}

	@Override
	public CustomerDTO fetchCustomerById(int id) {
		CustomerDTO cust=null;
		try
		{
			
			Connection con = DatabaseConnectivity.getConnection();
			Statement st = con.createStatement();
			String query = "select * from customer_details WHERE CID=?";
			PreparedStatement pst =con.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				cust=new CustomerDTO(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			}
			return cust;
		}
		catch(Exception E)
		{
			System.out.println("exception");
		}
		logger.info("Fetching customer by id");
		return cust;

	}

	@Override
	public HashMap fetchCustomerByName(String name) {
		CustomerDTO cust =null;
		HashMap<Integer,CustomerDTO> custHash = new HashMap<Integer,CustomerDTO>();
		try
		{
			 
			Connection con = DatabaseConnectivity.getConnection();
			
			String query = "select * from customer_details WHERE CNAME=?";
			PreparedStatement pst =con.prepareStatement(query);
			pst.setString(1, name);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
								cust=new CustomerDTO(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
                     custHash.put(rs.getInt(1),cust);			
			}
			
		}
		catch(Exception E)
		{
			System.out.println("exception");
		}
		logger.info("Fetching customer by name");
		return custHash;
		}
}
	
	
	
