package com.cg.customerapphashmap.dao;

import java.util.*;

import com.cg.customerapphashmap.dto.CustomerDTO;


public class StaticDB {
	private static HashMap<Integer,CustomerDTO> custHashMap = new HashMap<Integer,CustomerDTO>();
static
{
	custHashMap.put(1,new CustomerDTO("chandu","chandu@gmail.com","Hyderabad","9963673280"));
	custHashMap.put(2,new CustomerDTO("ravi","ravi@gmail.com","Hyderabad","9247571403"));
	custHashMap.put(3,new CustomerDTO("phani","phani@gmail.com","Vijayawada","9292202424"));
}
public static HashMap<Integer,CustomerDTO> getCustHashMap() {
	return custHashMap;
}
public static void setCustHashMap(HashMap<Integer,CustomerDTO> custHashMap) {
	StaticDB.custHashMap = custHashMap;
}

}
