package com.cg.customerapphashmap.dao;
import com.cg.customerapphashmap.dto.CustomerDTO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public interface CustomerDAO {
	HashMap<Integer,CustomerDTO> custHashMap = new HashMap<Integer,CustomerDTO>();
	boolean addCustomer(int id,CustomerDTO cust);
	 boolean deleteCustomer(int id);
	 boolean modifyCustomer(int id,String name);
	 boolean deleteAll();
	 HashMap fetchAll();
	 CustomerDTO fetchCustomerById(int id);
	 HashMap fetchCustomerByName(String name);
	 

}
