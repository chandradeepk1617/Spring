
public class TestEmployee {

	public static void main(String[] args) {
		Employee subhash = new Employee(444,"Subhash",56000.0F);
		Employee akhila = new Employee(555,"Akhila",50000.0F);
		Employee rajat = new WageEmp(456,"RAJAT",10000F,4,500);
		System.out.println("Rajat Info "+rajat+" ANNUAL GROSS SAL "+rajat.calcEmpAnnGrossSal());
		System.out.println("Subhash Info "+subhash+" ANNUAL GROSS SAL "+subhash.calcEmpAnnGrossSal());
		System.out.println("Akhila Info "+akhila+" ANNUAL GROSS SAL "+akhila.calcEmpAnnGrossSal());
	}

}
