
public class StringClass {

	public static void main(String[] args) {
		String str1 = "1";
		String str2 = "2";
	    String str3 = "Capgemini";
		String str4 = new String("Capgemini");
		String str5 = new String("Capgemini");
		System.out.println(str1==str2);
		System.out.println(str1==str3);
		//System.out.println(str1==str4);
		//System.out.println(str4==str5);
		System.out.println(str1.hashCode());
		System.out.println(str3.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str4.hashCode());
		System.out.println(str5.hashCode());
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		System.out.println(str1.equals(str4));
		System.out.println(str4.equals(str5));
		
		// TODO Auto-generated method stub

	}

}
