
public class Employee {
	private int empId;
	private String empName;
	private float empbasicSal;
	public Employee()
	{
		
	}
	public Employee(int empId,String empName,float empbasicSal)
	{
		this.empId = empId;
		this.empName = empName;
		this.empbasicSal=empbasicSal;
		
	}
	public String toString()
	{
		return "Employee [empId="+empId+ ", empName="+empName+", EmpbasicSal"+empbasicSal+"]";
		
	}
	public float calEmpGrossSal()
	{
		return empbasicSal;
	}
	public float calcEmpAnnGrossSal()
	{
		return empbasicSal*12;
	}

	
}
