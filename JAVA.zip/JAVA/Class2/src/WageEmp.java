
public class WageEmp extends Employee {
	private int ratePerHour;
	private int noOfHours;
public WageEmp()
{
	
}
public WageEmp(int empId, String empName, float empbasicSal,int ratePerHour,int noOfHours) 
{
	super(empId, empName, empbasicSal);
	this.ratePerHour=ratePerHour;
	this.noOfHours=noOfHours;
	
	// TODO Auto-generated constructor stub
}

public float calcEmpGrossSal()
{
	return super.calEmpGrossSal()+(ratePerHour*noOfHours*20);
}
public float calcEmpAnnGrossSal()
{
	return calcEmpGrossSal()*12;
}
public String toString()
{
	return super.toString()+" "+ratePerHour+" " +noOfHours;
}
}

