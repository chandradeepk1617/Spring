
public class TestEmpDemo2 {

	public static void main(String[] args) {
		Employee Aadarsh = new Employee(666,"Aadarsh",60000);
		WageEmp Phani = new WageEmp(777,"Phani",60000,5,500);
		WageEmp Nikhil = new WageEmp(888,"Nikhil",60000,5,600);
		// TODO Auto-generated method stub
byte b = 89;
int i = 80000;
i = b;
System.out.println(i);
Employee Sam = null;
Sam = Phani;
	WageEmp e2 = null;
	e2=(WageEmp)Aadarsh;
	}

}
