
public class Department {
	String departmentName;
	int deptid;
	int mgrid;
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public int getMgrid() {
		return mgrid;
	}
	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}
	public Department(String departmentName, int deptid, int mgrid) {
		super();
		this.departmentName = departmentName;
		this.deptid = deptid;
		this.mgrid = mgrid;
	}
	@Override
	public String toString() {
		return "Department [departmentName=" + departmentName + ", deptid=" + deptid + ", mgrid=" + mgrid + "]";
	}

}
