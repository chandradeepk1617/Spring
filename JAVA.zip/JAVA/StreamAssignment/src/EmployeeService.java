
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
public class EmployeeService {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
EmployeeRepository empRep = new EmployeeRepository();
HashSet<String> hs = new HashSet<String>();
ArrayList<Employee> al =empRep.alist;
HashSet<String> hashDept = new HashSet<String>();
for(Department dept:EmployeeRepository.deptHashSet) 
{
	   String name = dept.getDepartmentName();
	   hashDept.add(name);
}
int choice;
int flag=0;
while(flag!=1)
{
System.out.println("1 for sum of all salaries");
System.out.println("2 for Department wise count of employees");
System.out.println("3 for Senior most  Employee");
System.out.println("4 for Employee Name And Service");
System.out.println("5 for Employees without department");
System.out.println("6 for Department without employees");
System.out.println("7 for department with highest employees");
System.out.println("8 for exit");
System.out.println("enter your choice");
choice=sc.nextInt();
switch(choice)
{
case 1:
double Salary=empRep.alist.stream().mapToDouble(f->f.getSalary()).sum();
System.out.println(Salary);
break;

case 2:
	for(String name:hashDept)
	{
	
		long count = al.stream().filter(x->x.getDepartment()==name).count();
		System.out.println(name+" "+count);
	}
	break;
case 3:
 	List<Employee> sortedlist =al.stream().sorted((i1,i2)->i1.getHiredate().compareTo(i2.getHiredate())).limit(1).collect(Collectors.toList());
    for(Employee e:sortedlist)
    	System.out.println(e);
    break;
case 4:
	long[] days = al.stream().mapToLong(emp->ChronoUnit.DAYS.between(emp.getHiredate(),LocalDate.now())).toArray();
    long[] months = al.stream().mapToLong(emp->ChronoUnit.MONTHS.between(emp.getHiredate(),LocalDate.now())).toArray();

    
    int i=0;
    for(Employee emp:al)
    {
    System.out.println(emp.getFirstName()+" "+emp.getLastName()+" "+months[i]+" "+days[i]);
    i++;
    }
    break;
    
case 5:
List<Employee> emplist = al.stream().filter(all->all.getDepartment()==null).collect(Collectors.toList());
if(emplist.isEmpty())
{
	System.out.println("No Employees");
}
    for(Employee emp1:emplist)
{
	System.out.println("HI"+emp1);
}
    break;

case 6:   
   long count=0;
   long max=0;
   for(String deptname:hashDept)
    {
    	count=0;
    	count=al.stream().filter(emp->emp.getDept().getDepartmentName()==deptname).count();
    if(count==0)
    	System.out.println(deptname);
    }
   break;

case 7:
	max=0;
	   for(String deptname:hashDept)
	    {
		    count=0;
	    	count=al.stream().filter(emp->emp.getDept().getDepartmentName()==deptname).count();
	    if(max<count)
	    	max=count;
	    
	    }
   for(String deptname:hashDept)
   {
	   count=0;
   	count=al.stream().filter(emp->emp.getDept().getDepartmentName()==deptname).count();
   if(max==count)
   {
	  System.out.println(deptname+count);
   }
   	
  }
   break;
case 8:
	flag=1;
case 9:
	
}
}
}
}
