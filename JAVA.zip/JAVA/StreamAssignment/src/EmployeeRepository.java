import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;

public class EmployeeRepository {
	static ArrayList<Employee> alist = new ArrayList<Employee>();
	static HashSet<Department> deptHashSet = new HashSet<Department>();
	static
	{
		Department dept = new Department("Accounts",1,111);
		LocalDate date = LocalDate.of(2016, 5, 14);
		Employee emp = new Employee(1,"chandu","reddy","chandu@gmail.com","9963673280","Employee",111,12000.00,"Accounts",date,dept);
		alist.add(emp);
		LocalDate date1 = LocalDate.of(2017, 5, 14);
		Employee emp1 = new Employee(2,"Akhila","reddy","akhila@gmail.com","7660047193","Assistant",111,15000.00,"Accounts",date1,dept);
		alist.add(emp1);
		Department dept1 = new Department("Marketing",2,222);
		LocalDate date2 = LocalDate.of(2016,2,15);
		Employee emp2 = new Employee(3,"Phani","naidu","phani@gmail.com","9292202424","Assistant",222,12000.00,"Marketing",date2,dept1);
		alist.add(emp2);
		LocalDate date3 = LocalDate.of(2015, 12, 16);
		Employee emp3 = new Employee(4,"Nikhil","reddy","nikhil@gmail.com","8639232725","Employee",222,15000.00,"Marketing",date3,dept1);
		alist.add(emp3);
		Department dept2 = new Department("Manufacturing",3,333);
		LocalDate date4 = LocalDate.of(2017, 8, 16);
		Employee emp4 = new Employee(5,"Venkatesh","kaladi","venky@gmail.com","9872478954","Employee",333,12000.00,"Manufacturing",date4,dept2);
		alist.add(emp4);
		LocalDate date5 = LocalDate.of(2014, 8, 16);
		Employee emp5 = new Employee(6,"Justly","thomas","thomas@gmail.com","9876892122","Assistant",333,15000.00,"Manufacturing",date5,dept2);
		alist.add(emp5);
		Department dept3 = new Department("CSE",4,444);
	deptHashSet.add(dept);
	deptHashSet.add(dept1);
	deptHashSet.add(dept2);
	deptHashSet.add(dept3);
	
	}

}
