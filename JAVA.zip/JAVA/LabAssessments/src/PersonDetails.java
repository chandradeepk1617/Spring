
public class PersonDetails {
	enum Gender
	{
		M,F;
	}
	String FirstName;
	String LastName;
	 Gender g;
	int age;
	long phone;
	PersonDetails()
	{
		FirstName="CHANDU";
		LastName="REDDY";
		g = Gender.M;
		age=21;
		
	}
	PersonDetails(String Fn,String Ln,Gender h,int a)
	{
		FirstName=Fn;
		LastName=Ln;
		g=h;
		age=a;
	}
	void getPhone(long ph)
	{
		phone = ph;
	}
	void show()
	{
		System.out.println(FirstName);
		System.out.println(LastName);
		System.out.println(g);
		System.out.println(age);
		System.out.println(phone);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonDetails person = new PersonDetails();
		person.getPhone(996367);
		person.show();
		PersonDetails person1 = new PersonDetails("Akhila","reddy",Gender.F,19);
		person1.getPhone(79899);
		person1.show();

	}

}
