
public class CurrentAccount extends Account {
	final int overdraftlimit = 500;
	public void withdraw(double bal)
	{
		double b;
		if(super.getBalance()-bal<=0)
		{
			if(super.getBalance()-bal<=500)
			{
				b = super.getBalance();
				super.setBalance(b-bal);
			}
			else
				System.out.println("INSUFFICIENT BALANCE");
				
		}
		else
		{
			
			b = super.getBalance();
			super.setBalance(b-bal);
		}
	}

}
