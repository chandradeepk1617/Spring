
public class Ointment extends Medicine{
	String Instructions = "KEEP AWAY FROM CHILDREN";
	String Type = "Ointment";
	public Ointment(String MedicineName,int ExpiryInMonths,String Manufacturer,int Price)
	{
		super(MedicineName,ExpiryInMonths,Manufacturer,Price);
	}
	public String toString()
	{
		return "Medicine Type = "+Type+"\n"+super.toString()+" \n Instructions = "+Instructions;
	}

}
