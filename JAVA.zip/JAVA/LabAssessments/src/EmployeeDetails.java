

public class EmployeeDetails {

	
	int empno;
	String  empname;
    String gen;
    String phoneno;
	double sal;
	
	EmployeeDetails()
	{
		empno=0;
		empname="";
		gen="";
		phoneno="0";
		sal=0.0;
		
	}
	
	EmployeeDetails(int empno,String empname,String gen,String phoneno,double sal)
	{
		this.empno=empno;
		this.empname=empname;
		this.gen=gen;
		this.phoneno=phoneno;
		this.sal=sal;
		
	}
	
	 public  String toString()
	 {
		 String s=empno+"\n"+empname+"\n"+gen+"\n"+phoneno+"\n"+sal;
	return s;	 
	 }
	 
	
	
}


