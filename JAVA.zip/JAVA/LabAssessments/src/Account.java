
public class Account {
	private long AcctNum;
	public double balance;
    private Person Accholder;
	public long getAcctNum() {
		return AcctNum;
	}
	public void setAcctNum(long acctNum) {
		AcctNum = acctNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccholder() {
		return Accholder;
	}
	public void setAccholder(Person accholder) {
		Accholder = accholder;
	}
	public void deposit(double bal)
	{
		balance = balance+bal;
		System.out.println("Deposited Successfully");
	}
	public void withdraw(double bal)
	{
		if(balance-bal<500)
		{
			System.out.println("INSUFFICIENT BALANCE");
		}
		else
		{
			balance = balance-bal;
		}
	}
	public void Display()
	{
		System.out.println("ACCOUNT NUMBER      "+getAcctNum());
		System.out.println(" ACCOUNT HOLDER NAME"+Accholder.getName());
		System.out.println(" ACCOUNT HOLDER AGE"+Accholder.getAge());
		System.out.println(" ACCOUNT Balance"+getBalance());
	}
	
	

}
