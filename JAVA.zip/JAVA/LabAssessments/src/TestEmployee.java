
import java.util.Scanner;
public class TestEmployee {

	public static void main(String[] args) {
		System.out.println("ENTER NUMBER OF OBJECTS");
		Scanner sc = new Scanner(System.in);
		int objCount = sc.nextInt();
		// TODO Auto-generated method stub
        EmployeeDetails Obj[] = new EmployeeDetails[objCount];
        for(int i=0;i<objCount;i++)
        {
        	System.out.println("ENTER NAME");
        	String name = sc.next();
        	System.out.println("ENTER PHONE NUMBER");
        	String phn = sc.next();
        	System.out.println("ENTER Employee number");
        	int num = sc.nextInt();
        	System.out.println("ENTER GENDER");
        	String gender = sc.next();
        	System.out.println("ENTER SALARY");
        	double sal = sc.nextDouble();
        	Obj[i]=new EmployeeDetails(num,name,gender,phn,sal);
        	
        }
        for(int i=0;i<objCount;i++)
        {
        	System.out.println(Obj[i]);
        }
	}

}
