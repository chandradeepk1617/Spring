import java.util.Scanner;
public class TestAccount {
public static void main(String args[])
{
	int a=0,z=0;
	Scanner sc= new Scanner(System.in);
 Person P = new Person();
 P.setName("CHANDU");
 P.setAge(20);
 Person P1 = new Person();
 P1.setName("Akhila");
 P1.setAge(20);
 Account A = new SavingsAccount();
 A.setAcctNum(123456);
 A.setBalance(5000.0);
 A.setAccholder(P);
 Account B = new CurrentAccount();
 B.setAcctNum(123457);
 B.setBalance(5000.0);
 B.setAccholder(P1);
 while(z<1)
 {
	 System.out.println("ENTER THE TYPE \n1 for Savings\n 2 for Current\n 3 for exit");
	 System.out.println("ENTER YOUR CHOICE");
	 int x = sc.nextInt();
	 if(x==3)
		 z=1;
	 switch(x)
	 {
	 
	 case 1:
	while(a<1)
	{
    System.out.println("1 for View Details");
	System.out.println("2 for Depositing Money");
	System.out.println("3 for WithDrawing Money");
	System.out.println("4 for Checking Balance");
	System.out.println("5 for exit");
	
	System.out.println("Enter your choice");
	
	int choice = sc.nextInt();
	if(choice==5)
		a=1;
	else
	{
	switch(choice)
	{
	case 1:
		A.Display();
		break;
	case 2:
		System.out.println("ENTER THE AMMOUNT TO DEPOSIT");
		double b;
		b=sc.nextDouble();
		A.deposit(b);
		break;
	case 3:
		System.out.println("ENTER THE AMMOUNT TO With Draw");
		 double c;
		c=sc.nextDouble();
		A.withdraw(c);
		break;
	case 4:
		System.out.println("THE BALANCE IS"+A.getBalance());
		break;
	default:
		System.out.println("ENTER CORRECT CHOICE");
	}
	}
	}
	break;
	 case 2:
		 while(a<2)
			{
		    System.out.println("1 for View Details");
			System.out.println("2 for Depositing Money");
			System.out.println("3 for WithDrawing Money");
			System.out.println("4 for Checking Balance");
			System.out.println("5 for exit");
			
			System.out.println("Enter your choice");
			
			int choice = sc.nextInt();
			if(choice==5)
				a=2;
			else
			{
			switch(choice)
			{
			case 1:
				B.Display();
				break;
			case 2:
				System.out.println("ENTER THE AMMOUNT TO DEPOSIT");
				double b;
				b=sc.nextDouble();
				B.deposit(b);
				break;
			case 3:
				System.out.println("ENTER THE AMMOUNT TO With Draw");
				 double c;
				c=sc.nextDouble();
				B.withdraw(c);
				break;
			case 4:
				System.out.println("THE BALANCE IS"+B.getBalance());
				break;
			default:
				System.out.println("ENTER CORRECT CHOICE");
			}
			}
			}
		 
 }
}
}
}