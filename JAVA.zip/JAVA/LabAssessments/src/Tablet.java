
public class Tablet extends Medicine {
	String Instructions = "Store in a dry place";
	String Type = "Tablet";

	public Tablet(String medicineName, int expiryInMonths, String manufacturer, int price) 
	{
		super(medicineName, expiryInMonths, manufacturer, price);
		// TODO Auto-generated constructor stub
	}
	public String toString()
	{
		return "Medicine Type = "+Type+"\n"+super.toString()+"\n Instructions = "+Instructions;
	}
	

}
