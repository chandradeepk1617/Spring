
public class Medicine {
	String MedicineName;
	int ExpiryInMonths;
	String Manufacturer;
	int Price;
	public Medicine(String medicineName, int expiryInMonths, String manufacturer, int price) {
		MedicineName = medicineName;
		ExpiryInMonths = expiryInMonths;
		Manufacturer = manufacturer;
		Price = price;
	}
	@Override
	public String toString() {
		return "Medicine \nMedicineName=" + MedicineName + "\n ExpiryDate=" + ExpiryInMonths + "\n Manufacturer="
				+ Manufacturer + "\n Price=" + Price;
	}
	
	

}
