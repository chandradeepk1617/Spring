import java.util.Random;
import java.util.Scanner;
public class TestMedicine {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
int num;
Random R = new Random();

String MName;
String Manu;
int ExpMonths;
int Pri;
Scanner sc = new Scanner(System.in);

Medicine M[] = new Medicine[10];
for(int i=0;i<3;i++)
{
	num = R.nextInt(3);

    switch(num)
    {
    case 0:
    	System.out.println("Enter Medicine Name ");
    	MName = sc.next();
    	System.out.println("Enter Medicine Expiry In Months");
    	ExpMonths = sc.nextInt();
    	System.out.println("Enter Medicine Manufacturer Name ");
    	Manu = sc.next();
    	System.out.println("Enter Medicine Price ");
    	Pri = sc.nextInt();
    	M[i] = new Tablet(MName,ExpMonths,Manu,Pri);
    	break;
    case 1:
    	System.out.println("Enter Medicine Name ");
    	MName = sc.next();
    	System.out.println("Enter Medicine Expiry In Months");
    	ExpMonths = sc.nextInt();
    	System.out.println("Enter Medicine Manufacturer Name ");
    	Manu = sc.next();
    	System.out.println("Enter Medicine Price ");
    	Pri = sc.nextInt();
    	M[i] = new Ointment(MName,ExpMonths,Manu,Pri);
    	break;

    case 2:
    	System.out.println("Enter Medicine Name ");
    	MName = sc.next();
    	System.out.println("Enter Medicine Expiry In Months");
    	ExpMonths = sc.nextInt();
    	System.out.println("Enter Medicine Manufacturer Name ");
    	Manu = sc.next();
    	System.out.println("Enter Medicine Price ");
    	Pri = sc.nextInt();
    	M[i] = new Syrup(MName,ExpMonths,Manu,Pri);
    	break;
    default:
    	System.out.println("ENETER CORRECT CHOICE");
    	
    }
    
}
for(int i=0;i<3;i++)
{
	if(M[i] instanceof Syrup)
	{
		System.out.println("Syrup Type");
	}
	else if(M[i] instanceof Ointment)
	{
		System.out.println("Ointment Type");
	}
	else
	{
		System.out.println("Tablet Type");
	}
	System.out.println("Medicine Deatils \n"+M[i].toString());
}
	
	}

}
