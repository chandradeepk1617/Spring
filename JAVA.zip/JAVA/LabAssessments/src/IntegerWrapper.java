
public class IntegerWrapper {
	public void add(byte a,byte b)
	{
		System.out.println("Addition of byte"+(a+b));
	}
	public void add(int a,int b)
	{
		System.out.println("Addition of Int "+(a+b));
	}
	public void add(Integer a,Integer b)
	{
		System.out.println("Addition of  Integer Wrapper"+(a+b));
	}
	
	public static void main(String[] args) {
		IntegerWrapper I = new IntegerWrapper();
		I.add(10,10);
		I.add((byte)10,(byte)10);
		I.add(new Integer(10),new Integer(10));
		I.add((byte)10000,(byte)10000);
		
		
		// TODO Auto-generated method stub

		
	}

}
