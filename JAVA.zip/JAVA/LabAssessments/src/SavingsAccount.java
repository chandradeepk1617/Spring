
public class SavingsAccount extends Account {
	final int minBalance=500;
	public void withdraw(double bal)
	
	{
		System.out.println("SAVINGS ACCOUNT CALLED");
		if(super.getBalance()-bal<minBalance)
		{
			System.out.println(" INSUFFICIENT FUNDS");
			
		}
		else
		{
			double b = super.getBalance();
			super.setBalance(b-bal);
		}
	}
	

}
