import java.util.ArrayList;
import java.util.Iterator;

public class TestEmpArrayListDemo {

	public static void main(String[] args) 
	{
		ArrayList<Employee> emplist = new ArrayList<Employee>();
		Employee e1 = new Employee(111,"Chandu",6666.6F);
		Employee e2 = new Employee(222,"Subhash",7777.6F);
				Employee e3 = new Employee(333,"Phani",8888.6F);
				Employee e4 = new Employee(444,"Sonu",9999.6F);
				Employee e5 = new Employee(555,"Punith",5666.6F);
	emplist.add(e1);
	emplist.add(e2);
	emplist.add(e3);
	emplist.add(e4);
	emplist.add(e5);
	System.out.println(emplist);
	Iterator<Employee> it =emplist.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	
	}

}
