
public class Employee implements Comparable<Employee> {
private int empId;
private String empName;
private float empSal;
public Employee(int empId, String empName, float empSal) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSal = empSal;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
}
public Employee() {
	super();
}
@Override
public boolean equals(Object obj) {
	// TODO Auto-generated method stub
	Employee ee =(Employee)obj;
	if(this.empId==ee.empId)
	{
		return true;
	}
	else
	{
		return false;
	}

}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return this.empId;
}
@Override
public int compareTo(Employee emp) {
	// TODO Auto-generated method stub
	if(this.empId<emp.empId)
		return -1;
	else if(this.empId==emp.empId)
		return 0;
	else
		return +1;
}

}
