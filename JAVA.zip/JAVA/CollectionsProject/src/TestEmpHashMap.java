import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;

public class TestEmpHashMap {

	public static void main(String[] args) {
		ArrayList<Integer> empArrayList = new ArrayList<Integer>();
		Scanner sc = new Scanner(System.in);
		String namePattern = "[A-Z]{0,1}[a-z]{5,20}";
		String phonePattern = "[6-9]{0,1}[0-9]{10,10}";
		String idPattern = "[^0][0-9]{2,2}";
		String salPattern = "[^0][0-9]{2,10}[/.][0-9]{0,9}";
		
		
		ConcurrentHashMap<Long,Employee> emp=new ConcurrentHashMap<Long,Employee>(); 
		ConcurrentHashMap<Long,Employee> empdup=new ConcurrentHashMap<Long,Employee>(); 
		Employee emp1 = new Employee(111,"Chandu",6666.6F);
		Employee emp2 = new Employee(222,"Subhash",7777.6F);
		Employee emp3 = new Employee(333,"Phani",8888.6F);
		Employee emp4 = new Employee(444,"Chandu",6666.6F);
		Employee emp5 = new Employee(555,"Punith",5666.6F);
	empArrayList.add(111);
	empArrayList.add(222);
	empArrayList.add(333);
	empArrayList.add(444);
	empArrayList.add(555);
	
	
	emp.put(9963673280L,emp1);
	emp.put(8639232725L,emp2);
	emp.put(9292202424L,emp3);
	emp.put(9493798717L,emp4);
	emp.put(9872478954L,emp5);
	Set<Long> keySet = emp.keySet();
	for(Long l:keySet)
		System.out.println(l);
	
	Collection<Employee> c = emp.values();	
	for(Employee e:c)
		System.out.println(e);
	Set<Entry<Long,Employee>> entrySet;
	
int choice=0;
int flag=0;
String name ="";
int found=0;
int variable=0;
do
{
	System.out.println("1. For Searching \n 2. For Deletion \n 3 for Displaying Entries \n 4 For Inserting Values\n 5 for Displaying in Sorted Order \n 6 for exit");
	choice = sc.nextInt();
	switch(choice)
{
case 1:
	found=0;
System.out.println("enter name");
name= sc.next();
entrySet = emp.entrySet();
for(Entry entry:entrySet)
{
	Employee em=(Employee)entry.getValue();
	if(em.getEmpName().equals(name))
	{
		found=1;
		System.out.println(entry.getValue());
		System.out.println(entry.getKey());
	}
	
	
}
if(found==0)
	System.out.println("Not Found");
break;
case 2:
	int index=0;
System.out.println("enter the employee name to delete");
name=sc.next();
found=0;
long keyValue;
entrySet = emp.entrySet();
for(Entry entry:entrySet)
{
	index=0;
	Employee empObject=(Employee)entry.getValue();
	if(empObject.getEmpName().equals(name))
	{
		
		keyValue = (Long)entry.getKey();
		//empArrayList.remove(empObject.getEmpId());
		emp.remove(keyValue);
		found = 1;
		
		
		
	}	
}
if(found==0)
{
	System.out.println("Not Found");
}
else

{
	System.out.println("Deleted successfully");
}
break;
case 3:
	entrySet = emp.entrySet();
	for(Entry entry:entrySet)
{
	
	System.out.println(entry.getKey());
	System.out.println(entry.getValue());
    
}
break;
case 4:
	
	entrySet= emp.entrySet();
	found=0;
	
	Long phn=0L;
	long phone;
	String ename="";
	float empsal=0;
	int empid=0;
	flag=0;
	System.out.println("Enter Key");
	while(flag!=1)
	{
	phn = sc.nextLong();
	if(Pattern.matches(phonePattern,phn.toString()))
	{
		flag=1;
	}
	else
	{
		System.out.println("Wrong Format Must Contain 10 digits");
		System.out.println("Enter Key Again");
	}
	}
	for(Entry key:entrySet)
	{
	phone = (Long)key.getKey();
	if(phone==phn)
		found=1;
	}
	
	flag=0;
	
	if(found==0)
	{
	
	System.out.println("Enter Id");
	while(flag!=1)
	{
	empid=sc.nextInt();
	if(Pattern.matches(idPattern,String.valueOf(empid)))
	{
		flag=1;
	}
	else
	{
		System.out.println("Wrong format");
		System.out.println("Enter Id Again");
	}
	}
	flag=0;
	System.out.println("Enter Name");
	while(flag!=1)
	{
		ename = sc.next();
		if(Pattern.matches(namePattern,ename))
		{
			flag=1;
		}
		else
		{
			System.out.println("Invalid Format must contain only alphabets");
		System.out.println("ENter Name Again");
		}
	}
	flag=0;
	System.out.println("Enter Sal");
	while(flag!=1)
	{
	empsal = sc.nextFloat();
	if(Pattern.matches(salPattern,String.valueOf(empsal)))
	{
		flag=1;
	}
	else
	{
		System.out.println("Wrong Format");
		System.out.println("ENter Salary Again");
	}
	}
	Employee emp6 = new Employee(empid,ename,empsal);
	
	emp.put(phn,emp6);
	empArrayList.add(empid);
	variable++;
	}
	else
	{
		System.out.println(" Key already Found Can't Enter a Duplicate Value");
	}
	break;
case 6:
	flag=5;
	break;
case 5:
	Collections.sort(empArrayList);
	entrySet = emp.entrySet();
	empdup.putAll(emp);
	Set<Entry<Long,Employee>> entrySet1 = empdup.entrySet();
	long keyVal;
      for(int id:empArrayList)
		{
		for(Entry entry:entrySet1)
		{
			Employee emp7 = (Employee)entry.getValue();
			if(id==emp7.getEmpId())
			{
				keyVal=(Long)entry.getKey();
				System.out.println(entry.getKey());
				System.out.println(entry.getValue());
				empdup.remove(keyVal);
				break;
				
			}
		}
	}
		
	break;
	
default:
	System.out.println("enter correct choice");
}
	}while(flag<5);

}
}