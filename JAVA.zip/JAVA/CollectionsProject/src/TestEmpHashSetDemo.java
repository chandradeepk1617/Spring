import java.util.HashSet;
import java.util.Iterator;

public class TestEmpHashSetDemo {
	public static void main(String [] args)
	{
		HashSet<Employee> empSet = new HashSet<Employee>();
		Employee e1 = new Employee(111,"Chandu",6666.6F);
		Employee e2 = new Employee(222,"Subhash",7777.6F);
		Employee e3 = new Employee(333,"Phani",8888.6F);
		Employee e4 = new Employee(111,"Chandu",6666.6F);
		Employee e5 = new Employee(555,"Punith",5666.6F);
		System.out.println("i1 :"+e1.hashCode());
		System.out.println("i2 :"+e2.hashCode());
		System.out.println("i3 :"+e3.hashCode());
		System.out.println("i4 :"+e4.hashCode());
		System.out.println("i5 :"+e5.hashCode());
	empSet.add(e1);
	empSet.add(e2);
	empSet.add(e3);
	empSet.add(e4);
	empSet.add(e5);
	System.out.println(empSet);
	Iterator<Employee> it =empSet.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	}

}
