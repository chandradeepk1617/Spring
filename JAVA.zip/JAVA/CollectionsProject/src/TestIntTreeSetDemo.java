import java.util.Iterator;
import java.util.TreeSet;

public class TestIntTreeSetDemo {

	public static void main(String[] args) 
	{
		TreeSet<Integer> intSet = new TreeSet<Integer>();
		intSet.add(new Integer(40));
		intSet.add(new Integer(20));
		intSet.add(new Integer(100));
		intSet.add(new Integer(40));
		intSet.add(new Integer(90));
		System.out.println(intSet);
		Iterator<Integer> it = intSet.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		for(int i:intSet)
		{
			System.out.println(i);
		}
	}

}
