import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayListDemo {

	public static void main(String[] args) {
		ArrayList intlist = new ArrayList();
		Integer i1 = new Integer(70);
		Integer i2 = new Integer(20);
		Integer i3 = new Integer(60);
		Integer i4 = new Integer(30);
		Integer i5 = new Integer(40);
	intlist.add(i1);
	intlist.add(i2);
	intlist.add(i3);
	intlist.add(i4);
	intlist.add(i5);
	System.out.println(intlist);
	Iterator it = intlist.iterator();
	while(it.hasNext())
	{
		//Object obj = it.next();
		System.out.println("  :  "+it.next());
	}
	
	
	}

}
