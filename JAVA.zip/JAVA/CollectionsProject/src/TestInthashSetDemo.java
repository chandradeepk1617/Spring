import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class TestInthashSetDemo {

	public static void main(String[] args) {
		HashSet<Integer> intlist = new HashSet<Integer>();
		Integer i1 = new Integer(70);
		Integer i2 = new Integer(20);
		Integer i3 = new Integer(60);
		Integer i4 = new Integer(20);
		Integer i5 = new Integer(40);
		System.out.println("i1 :"+i1.hashCode());
		System.out.println("i2 :"+i2.hashCode());
		System.out.println("i3 :"+i3.hashCode());
		System.out.println("i4 :"+i4.hashCode());
		System.out.println("i5 :"+i5.hashCode());
		
	intlist.add(i1);
	intlist.add(i2);
	intlist.add(i3);
	intlist.add(i4);
	intlist.add(i5);
	System.out.println(intlist);
	Iterator it = intlist.iterator();
	while(it.hasNext())
	{
		//Object obj = it.next();
		System.out.println("  :  "+it.next());
	}
		// TODO Auto-generated method stub

	}

}
