import java.util.Collection;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo {

	public static void main(String[] args) 
	{
HashMap<Long,String> phoneDir = new HashMap<Long,String>();
phoneDir.put(9963673280L, "Chandu");
phoneDir.put(8639232725L, "Phani");
phoneDir.put(7989958484L, "Akhila");
phoneDir.put(9493798717L, "Harish");
phoneDir.put(9872478954L, "Venkatesh");
System.out.println(phoneDir);
System.out.println("--------Get all Keys--------");
Set<Long> keySet=phoneDir.keySet();
for(Long key:keySet)
{
	System.out.println(key);
}
System.out.println("--------Get all Values--------");
Collection<String> allNames = phoneDir.values();
for(String name:allNames)
{
	System.out.println(name);
}
System.out.println("--------Get All Records--------");
Set<Entry<Long,String>> entrySet = phoneDir.entrySet();
for(Entry entry:entrySet)
{
	System.out.println("key :"+entry.getKey()+" Values :"+entry.getValue());
}

	}


}
