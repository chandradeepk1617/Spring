import java.util.Iterator;
import java.util.TreeSet;

public class TestEmpTreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Employee> empTreeSet= new TreeSet<Employee>();
		Employee e1 = new Employee(111,"Chandu",6666.6F);
		Employee e2 = new Employee(222,"Subhash",7777.6F);
		Employee e3 = new Employee(333,"Phani",8888.6F);
		Employee e4 = new Employee(111,"Chandu",6666.6F);
		Employee e5 = new Employee(555,"Punith",5666.6F);
	empTreeSet.add(e1);
	empTreeSet.add(e2);
	empTreeSet.add(e3);
	empTreeSet.add(e4);
	empTreeSet.add(e5);
	System.out.println(empTreeSet);
	Iterator<Employee> it =empTreeSet.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}

	}

}
