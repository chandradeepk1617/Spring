import static java.lang.Math.PI;

public class Circle extends Shape implements Sortable {
	float radius;
	public Circle()
	{
		
	}
	
	public Circle(float radius)
	{
		super("Circle");
		this.radius = radius;
	}
	public float calcArea()
	{
		return ((float)(PI*radius*radius));
	}
	public float calcPerimeter()
	{
		return ((float)(2*PI*radius));
	}
	public String toString()
	{
		return "Type "+type+"\n"+"Radius: "+radius+"\n"+calcArea();
	}
	public boolean compare(float s)
	{
		if(s>calcArea())
		{
			return false;
		}
		else 
			return true;
	}
	

}
