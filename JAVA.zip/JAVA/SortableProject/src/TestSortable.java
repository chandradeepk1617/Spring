import java.util.Scanner;
import java.util.Random;


public class TestSortable {
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		Shape sh[] = new Shape[4];
        Random R = new Random();
        Shape x;
        float radius,side;
	 int ran = 0;
		for(int i=0;i<4;i++)
		{
		ran=R.nextInt(2);
		if(ran==0)
		{
			System.out.println("Circle");
			System.out.println("radius");
			radius = sc.nextFloat();
			sh[i] = new Circle(radius);
		}
		else
		{
			System.out.println("Square");
			System.out.println("Side");
			side = sc.nextFloat();
			sh[i] = new Square(side);
		}
		
	
	
		
	
		}
	
	float min = 0;
	int index=0;
	for(int i=0;i<4;i++)
	{
		min = sh[i].calcArea();
		index=i;
		for(int j=i+1;j<4;j++)
		{
			if(sh[j] instanceof Circle)
			{
			if(((Circle)sh[j]).compare(min))
				{
				 min = sh[j].calcArea();
				index = j;
				}
			}
			
			
			if(sh[j] instanceof Square)
			{
			if(((Square)sh[j]).compare(min))
				{
				 min = sh[j].calcArea();
				index = j;
				}
				
			}
			
			
		}
		if(index!=i)
		{
		x=sh[i];
		sh[i]=sh[index];
		sh[index]=x;
		}
	}
	for(int i=0;i<4;i++)
	{
			System.out.println(sh[i]);
		
	}
}
}
