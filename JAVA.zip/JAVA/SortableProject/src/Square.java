
public class Square extends Shape implements Sortable {
float side;
public Square()
{
	
}
public Square(float side)
{
	super("Square");
	this.side=side;
}
public float calcArea()
{
	return (float)(side*side);
}
public float calcPerimeter()
{
	return (float)(4*side);
}
public boolean compare(float s)
{
	if(s>calcArea())
	{
		return false;
	}
	else 
		return true;
}
@Override
public String toString() {
	return "Type ="+type+"\nside=" + side +"\n Area ="+calcArea();
}

}
