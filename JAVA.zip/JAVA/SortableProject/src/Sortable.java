
public interface Sortable {
	public boolean compare(float s);

}
