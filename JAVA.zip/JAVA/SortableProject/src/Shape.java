
public abstract class Shape {
	String type;
	public Shape()
	{
		
	}
	public Shape( String type)
	{
		this.type = type;
	}
public void drawShape()
{
	System.out.println(type+"DRAW IT IN RED COLOR");
}
public abstract float calcArea();


@Override
public String toString() {
	return "Shape [type=" + type + "]";
}
public abstract float calcPerimeter();
}
