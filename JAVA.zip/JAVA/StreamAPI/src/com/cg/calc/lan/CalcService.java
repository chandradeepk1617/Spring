package com.cg.calc.lan;

@FunctionalInterface
public interface CalcService {
 default int add(int num1,int num2)
 {
	 return num1+num2;
 };
 Boolean show(String name);
 
}
 