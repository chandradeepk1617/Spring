package com.cg.calc.lan;

import java.util.regex.Pattern;
import java.util.function.Supplier;
import java.util.function.Predicate;
import java.util.function.Function;
public class MainPrg {

	public static void main(String[] args) {
////		// TODO Auto-generated method stub
////		CalcService calc = (num,num1)-> {
////			System.out.println(num+num1);
////			return (num+num1);};
//		CalcService calc = (name)->{
//		//System.out.println(name);
//		String StringPattern = "[A-Z]{1,1}[a-z]{2,20}";
//		Boolean b = Pattern.matches(StringPattern, name);
//		return b;
//		};
//		System.out.println(calc.show("Chandu"));
//		System.out.println(calc.add(4,5));
	Supplier <String> sup = ()->
			{
		return "chandu";
			};
			System.out.println(sup.get());
	Predicate <String> pr = (name)->
	{
		String StringPattern = "[A-Z]{1,1}[a-z]{2,20}";
		Boolean b = Pattern.matches(StringPattern, name);
		return b;
	};
	System.out.println(pr.test("Chandu"));
	Function<String,Boolean> fc = (name)->
	{
		String StringPattern = "[A-Z]{1,1}[a-z]{2,20}";
		Boolean b = Pattern.matches(StringPattern, name);
		return b;
	};
	System.out.println(fc.apply("Chandu"));
	}

}
