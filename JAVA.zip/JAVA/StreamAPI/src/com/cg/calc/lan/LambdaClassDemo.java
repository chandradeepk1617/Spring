package com.cg.calc.lan;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;



public class LambdaClassDemo {
public static void main(String [] args)
{
	Stream<Integer> stream = Stream.of(5,7,20,3); 
//
//stream.filter(x->x>5).forEach(num->System.out.println(num));
//stream.forEach(num->System.out.println(num));
//stream.filter(x->x>1).map(x->x+2).forEach(num->System.out.println(num));
	stream.reduce((x,y)->(x+y));
	
List<String> words = Arrays.asList("chandu","cha","phani","om");
words.stream().filter(str->str.length()>3).forEach(str->System.out.println(str));

}
}
