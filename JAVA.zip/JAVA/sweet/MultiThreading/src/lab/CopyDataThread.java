package lab;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyDataThread  implements Runnable{
	FileInputStream fis;
	FileOutputStream fos;
	
	CopyDataThread(	FileInputStream fis,FileOutputStream fos)
	{
		this.fis=fis;
		this.fos=fos;
	}
 public void run()
 {int count =0;
	 try
	 {
		 
	 int i=0;    
     while((i=fis.read())!=-1){    
    	 count ++;
         
      
      fos.write((byte)i);
      if(count%10==0)
      {Thread.sleep(1000);
    	  System.out.println("ten characters are printed");
      count =0;
     }    
	 }
	 }
	 catch(Exception e)
	 {
		 
	 }
 }
}
