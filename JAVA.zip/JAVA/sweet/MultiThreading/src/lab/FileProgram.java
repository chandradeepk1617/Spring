package lab;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileProgram {
	

	public static void main(String[] args) {
		try
		{
		FileInputStream fis=new FileInputStream("C:/Users/SBIYYAPU/Desktop/readingfile.txt");
		FileOutputStream fos=new FileOutputStream("C:/Users/SBIYYAPU/Desktop/writingfile.txt");
		CopyDataThread ct=new CopyDataThread(fis,fos);
		Thread cthread=new Thread(ct);
		cthread.start();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

	}

}
