import java.util.ArrayList;
import java.util.Collections;
public class ArrayListStringSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> product = new ArrayList<String>();
		product.add("Akhil");
		product.add("Akhila");
		product.add("Phani");
		product.add("Chandu");
		Collections.sort(product);
		for(String s:product)
		{
			System.out.println(s);
		}

	}

}
