import java.util.ArrayList;
public class StringArraySorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] product = new String[4];
		product[0] = "chandu";
		product[1] = "phani"; 
		product[2] = "akhil";
		product[3] = "akhila";
		String str = "";
		int j;
		for(int i=0;i<product.length;i++)
		{
			String min = product[i];
			int index = i;
			for(j=i+1;j<product.length;j++)
			{
				if(min.compareTo(product[j])>0)
					
					{
					min=product[j];
					index = j;
					}
			}
			str = product[i];
			product[i]=product[index];
			product[index]=str;
			
		}
		for(int i=0;i<product.length;i++)
			System.out.println(product[i]);
	
	}

}
