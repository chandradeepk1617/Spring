import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CompileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String input = "Shop,Mop,Hopping,CHopping";
Pattern pattern = Pattern.compile("hop",Pattern.CASE_INSENSITIVE);
Matcher m = pattern.matcher(input);
	System.out.println(m.matches());
	while(m.find())
	{
		System.out.println(m.group()+":"+m.start()+":"+m.end());
	}
	
	}

}
