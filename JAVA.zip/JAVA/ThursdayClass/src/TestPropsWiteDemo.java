import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class TestPropsWiteDemo {

	public static void main(String[] args) {
		
		try {
			FileWriter fw= new FileWriter("dbinfo.properties");
			Properties dbProps = new Properties();
			dbProps.setProperty("dbUserName", "system");
			dbProps.setProperty("dbPwd", "root");
			dbProps.setProperty("dbType", "oracle");
			dbProps.store(fw,"This is Db Info");
		
		System.out.println("DB info stored successfully in prop file successfully");
		}
		catch (IOException e) {
		
			e.printStackTrace();
		}

	}

}
