import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Enumeration;
import java.util.Properties;



public class TestproReadDemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReader fr = null;
		Properties props=null;
		try
{
		fr = new FileReader("TestProperty.properties");
       	props = new Properties();
       	props.load(fr);
       	System.out.println("Number of properties:"+props.size());
       Enumeration en = props.keys();
while(en.hasMoreElements())
{
	String key = (String)en.nextElement();
	System.out.println("key :"+key+ "\nvalue : "+props.getProperty(key)) ;
	
}
}
catch (Exception e)
{
	e.printStackTrace();
}

}
}
