import java.util.Scanner;
import java.util.regex.Pattern;

public class TestPatternDemo {

	public static void main(String[] args) {
		String name =null;
		String namePattern = "[A-Z]{0,1}[0-9A-Za-z]{8,20}";
		// TODO Auto-generated method stub
try(Scanner sc = new Scanner(System.in))
{
	System.out.println("ENTER NAME");
	name = sc.next();
	if(Pattern.matches(namePattern,name))
	{
		System.out.println("VALID");
	}
	else
	{
		System.out.println("NAME should have atleast 8 characters and a max of 20 charcaters and must have a small and capital letter");
		
	}
	
}
catch (Exception e)
{
	e.printStackTrace();
}
//

	}

}
