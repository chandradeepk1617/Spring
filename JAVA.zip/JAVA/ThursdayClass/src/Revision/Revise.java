package Revision;

public class Revise {
protected int x,y;
	

}
