package Revision;

public class Main {
	int x=4;
	private Main(int y)
	{
		x=y;
	}
	static void func()
	{
		
	}
	public static void main(String[] args) {
		Revise r = new Revise();
		System.out.println(r.x+r.y);
		System.out.println();
		Main z = new Main(5);
		S
		System.out.println(z.x);
//for(int i=0;true;i++)
//{
//	System.out.println("hello");
//}
	}
}
