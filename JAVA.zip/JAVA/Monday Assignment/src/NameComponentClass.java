import com.cg.customerapp.exception.CustomerException;

public class NameComponentClass {
	String stringPatetrn = "[";
	public boolean isValidName(String name)
	{
		String match = "chandu";
		System.out.println("HI");
		if(name.equals(match))
		return true;
		else 
			return false;
			
	}

}
