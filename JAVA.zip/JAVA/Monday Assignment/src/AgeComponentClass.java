import com.cg.customerapp.exception.*;
public class AgeComponentClass {
	public boolean isValidAge(int age)
	{
		if(age>0&&age<70)
		return true;
		else
			throw new CustomerException("Age is invalid");
	}

public String isValidAgeWithNegativeAge(int age)
{
	if(age>0&&age<70)
		return "true";
		else
		return "flase";
}
}