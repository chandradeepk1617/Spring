package com.cg.customeraapp.test;

public class AgeComponentClass {
	public boolean isValidAge(int age)
	{
		return true;
	}
}
