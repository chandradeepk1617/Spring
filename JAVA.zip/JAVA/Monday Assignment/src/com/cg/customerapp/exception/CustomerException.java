package com.cg.customerapp.exception;

public class CustomerException extends RuntimeException {
	String message;
	public CustomerException()
	{
		
	}
public CustomerException(String message)
{
	this.message=message;
}
public String toString()
{
	return "Exception Occured is" +message;
}
}
