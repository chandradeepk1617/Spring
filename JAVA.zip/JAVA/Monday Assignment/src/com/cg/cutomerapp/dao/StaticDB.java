package com.cg.cutomerapp.dao;

import java.util.*;

import com.cg.cutomerapp.dto.*;

public class StaticDB {
	private static List<CustomerDTO> custArrList = new ArrayList<CustomerDTO>();
static
{
	custArrList.add(new CustomerDTO(1,"chandu","chandu@gmail.com","Hyderabad","9963673280"));
	custArrList.add(new CustomerDTO(2,"ravi","ravi@gmail.com","Hyderabad","9247571403"));
	custArrList.add(new CustomerDTO(3,"phani","phani@gmail.com","Vijayawada","9292202424"));
}
public static List<CustomerDTO> getCustArrList() {
	return custArrList;
}
public static void setAl(List<CustomerDTO> custArrList) {
	StaticDB.custArrList = custArrList;
}

}
