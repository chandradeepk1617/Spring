package com.cg.cutomerapp.dao;
import com.cg.cutomerapp.dto.*;

import java.util.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class CustomerDAOImpl implements CustomerDAO {

public CustomerDAOImpl()
{
	PropertyConfigurator.configure("resource/customerlog.properties");
}
static Logger logger = Logger.getRootLogger();
	int index;
	int found;
	@Override
	
	public boolean addCustomer(CustomerDTO cust1) {
		List<CustomerDTO> custarr = StaticDB.getCustArrList();
		
	custarr.add(cust1);
		logger.info("ADDING A CUSTOMER");
	return true;
		
	}

	@Override
	public boolean deleteCustomer(int id) {
		index=0;
		found=0;
		List<CustomerDTO> custarr = StaticDB.getCustArrList();
		for(CustomerDTO cust2:custarr)
		{
			if(cust2.getCustId()==id)
			{
				custarr.remove(index);
				found=1;
				break;
			}
			index++;
		}
		if(found==0)
		return false;
		else
		return true;
	}

	@Override
	public boolean modifyCustomer(int id,String name) {
		// TODO Auto-generated method stub
		found=0;
		List<CustomerDTO> custarr = StaticDB.getCustArrList();
		for(CustomerDTO modify:custarr)
		{
			if(modify.getCustId()==id)
			{
				System.out.println("Enter Name");
				modify.setCustName(name);
			    found=1;
			    break;
			}
			
				
		}
		if(found==1)
		{
			return true;
		}
		else
		{
			System.out.println(id+"not found");
		return false;
		}
	}

	@Override
	public boolean deleteAll() {
		
		StaticDB.getCustArrList().clear();
		
		return true;
	}

	@Override
	public ArrayList fetchAll() {
		// TODO Auto-generated method stub
     return (ArrayList)StaticDB.getCustArrList();
	
	
	}

	@Override
	public CustomerDTO fetchCustomerById(int id) {
		CustomerDTO key = null;
		for(CustomerDTO fetch:StaticDB.getCustArrList())
		{
			if(fetch.getCustId()==id)
			{
				key=fetch;
			}
		}
		return key;
	}

	@Override
	public CustomerDTO fetchCustomerByName(String name) {
		
		CustomerDTO key = null;	
		for(CustomerDTO fetch:StaticDB.getCustArrList())
		{
			if(fetch.getCustName().equals(name))
			{
				key=fetch;
			}
		}
		return key;
	}
	
}
