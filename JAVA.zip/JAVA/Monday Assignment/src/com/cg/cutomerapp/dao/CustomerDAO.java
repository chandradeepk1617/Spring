package com.cg.cutomerapp.dao;
import com.cg.cutomerapp.dto.*;
import java.util.ArrayList;
import java.util.List;

public interface CustomerDAO {
	List<CustomerDTO> custArrList = new ArrayList<CustomerDTO>();
	boolean addCustomer(CustomerDTO cust);
	 boolean deleteCustomer(int id);
	 boolean modifyCustomer(int id,String name);
	 boolean deleteAll();
	 ArrayList fetchAll();
	 CustomerDTO fetchCustomerById(int id);
	 CustomerDTO fetchCustomerByName(String name);
	 

}
