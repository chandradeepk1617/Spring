package com.cg.cutomerapp.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.cutomerapp.bl.CustomerServiceImpl;
import com.cg.cutomerapp.dao.CustomerDAOImpl;
import com.cg.cutomerapp.dto.CustomerDTO;
import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;


public class CustomerUI {

public static void main(String[] args) {
		
		int id;
		String name;
		String address;
		String email;
		String phone;
		
		CustomerServiceImpl custImpl = new CustomerServiceImpl();
	
		Scanner sc=new Scanner(System.in);
		int choice;
		int flag=0;
		while(flag!=1)
		{
			System.out.println("1. Add a Customer");
			System.out.println("2. Delete a Customer");
			System.out.println("3. Modify a Customer");
			System.out.println("4. Delete all Customers");
			System.out.println("5. fetch all Customers");
			System.out.println("6. Fetch Customer By Name");
			System.out.println("7. Fetch Customer By Id");
			System.out.println("8. Terminate");
		    System.out.println("Enter Your Choice");
		    choice = sc.nextInt();
		    switch(choice)
		    {
		    case 1:
		    	System.out.println("Enter Customer Id");
		    	id = sc.nextInt();
		    	System.out.println("Enter Customer Name");
		    	name = sc.next();
		    	System.out.println("Enter Customer Email");
		    	email = sc.next();
		    	System.out.println("Enter Customer PhoneNumber");
		    	phone = sc.next();
		    	System.out.println("Enter Customer Address");
		    	address = sc.next();
		    	CustomerDTO cust = new CustomerDTO(id,name,email,address,phone);
		    	custImpl.addCustomer(cust);
		    	break;
		    case 2:
		    	System.out.println("Enter Id");
		    	id = sc.nextInt();
		    	boolean result = custImpl.deleteCustomer(id);
		    	if(result==false)
		    		System.out.println(id+" Not Found");
		   
		    	break;
		    	
		    case 3:
		    	System.out.println("Enter Id");
		    	id=sc.nextInt();
		    	System.out.println("Enter Name");
		    	name = sc.next();
		    	System.out.println(custImpl.modifyCustomer(id,name));
		    	break;
		    case 4:
		    	custImpl.deleteAll();
		    	break;
		    case 5:
		    	ArrayList<CustomerDTO> custArrList1 = custImpl.fetchAll();
		    	custArrList1.stream().filter(cust1->cust1.getCustName().length()>5).map(cust1->cust1.getCustName().toUpperCase()).forEach(cust1->System.out.println(cust1));
		    	for(CustomerDTO custDTO1:custArrList1)
		    	{
		    		System.out.println(custDTO1);
		    	}
		    	break;
		    	
		    case 6:
		    	System.out.println("Enter Name");
		    	name = sc.next();
		    	CustomerDTO fetchName = custImpl.fetchCustomerByName(name);
		    	if(fetchName==null)
		    		System.out.println("Record with "+name+" not found");
		    	else
		    		System.out.println(fetchName);
		    	break;
		    case 7:
		    	System.out.println("Enter Id");
		    	id=sc.nextInt();
		    	CustomerDTO fetchId = custImpl.fetchCustomerById(id);
		    	if(fetchId==null)
		    		System.out.println("Record with"+id+" not Found");
		    	else
		    	System.out.println(fetchId);
		    	break;
		    case 8:
		    	flag=1;
		    	break;
		    default:
		    	System.out.println("Enter Correct choice");
		    }
		}

	}

	



}
