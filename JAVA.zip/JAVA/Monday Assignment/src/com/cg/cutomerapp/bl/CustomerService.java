package com.cg.cutomerapp.bl;
import java.util.ArrayList;
import java.util.List;

import com.cg.cutomerapp.dto.CustomerDTO;

public interface CustomerService {
	List<CustomerDTO> custArrList = new ArrayList<CustomerDTO>();
void addCustomer(CustomerDTO cust);
 boolean deleteCustomer(int id);
 boolean modifyCustomer(int id,String name);
 boolean deleteAll();
 ArrayList fetchAll();
 CustomerDTO fetchCustomerById(int id);
 CustomerDTO fetchCustomerByName(String name);
 
 
}
