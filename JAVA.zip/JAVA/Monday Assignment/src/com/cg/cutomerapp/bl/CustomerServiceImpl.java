package com.cg.cutomerapp.bl;

import java.util.*;

import com.cg.cutomerapp.dao.CustomerDAOImpl;
import com.cg.cutomerapp.dto.CustomerDTO;
public class CustomerServiceImpl implements CustomerService {
	int index;
	int found;
	CustomerDAOImpl custDAO =new CustomerDAOImpl();
	@Override
	
	public void addCustomer(CustomerDTO cust1) {
		
	 (custDAO).addCustomer(cust1);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean deleteCustomer(int id) {
//		index=0;
//		found=0;
//		for(CustomerDTO cust2:custArrList)
//		{
//			if(cust2.getCustId()==id)
//			{
//				custArrList.remove(index);
//				found=1;
//			}
//			index++;
//		}
//		if(found==0)
//		return false;
//		else
//		return true;
	return (custDAO).deleteCustomer(id);
	}

	@Override
	public boolean modifyCustomer(int id,String name) {
		// TODO Auto-generated method stub
//		found=0;
//		String name;
//		Scanner sc = new Scanner(System.in);
//		for(CustomerDTO modify:custArrList)
//		{
//			if(modify.getCustId()==id)
//			{
//				System.out.println("Enter Name");
//				name = sc.next();
//				modify.setCustName(name);
//			    found=1;
//			    break;
//			}
//			
//				
//		}
//		if(found==1)
//		{
//			return true;
//		}
//		else
//		{
//			System.out.println(id+"not found");
//		return false;
//		}
		return (custDAO).modifyCustomer(id,name);
	}

	@Override
	public boolean deleteAll() {
		
		//custArrList.clear();
		
		return (custDAO).deleteAll();
	}

	@Override
	public ArrayList fetchAll() {
		// TODO Auto-generated method stub
//	index=0;
//	CustomerDTO fetchAll=null;
//	for(CustomerDTO fetch:custArrList)
//	{
//		if(ind==index)
//		{
//			fetchAll=fetch;
//		break;
//		}
//		else
//			index++;
//	}
//
	
	return (custDAO).fetchAll();
	}

	@Override
	public CustomerDTO fetchCustomerById(int id) {
//		CustomerDTO key = null;
//		for(CustomerDTO fetch:custArrList)
//		{
//			if(fetch.getCustId()==id)
//			{
//				key=fetch;
//			}
//		}
		return (custDAO).fetchCustomerById(id);
	}

	@Override
	public CustomerDTO fetchCustomerByName(String name) {
		
//		CustomerDTO key = null;	
//		for(CustomerDTO fetch:custArrList)
//		{
//			if(fetch.getCustName().equals(name))
//			{
//				key=fetch;
//			}
//		}
		return (custDAO).fetchCustomerByName(name);
	}

	
}
