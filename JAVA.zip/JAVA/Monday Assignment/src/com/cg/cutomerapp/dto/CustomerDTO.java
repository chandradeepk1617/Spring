package com.cg.cutomerapp.dto;

public class CustomerDTO {
	private int custId;
	private String custName;
	private String custEmail;
	private String custAddress;
	private String custPhoneNumber;
	public CustomerDTO(int custId, String custName, String custEmail, String custAddress, String custPhoneNumber) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.custAddress = custAddress;
		this.custPhoneNumber = custPhoneNumber;
	}
	public int getCustId() {
		return custId;
	}
	public String getCustName() {
		return custName;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public void setCustPhoneNumber(String custPhoneNumber) {
		this.custPhoneNumber = custPhoneNumber;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public String getCustPhoneNumber() {
		return custPhoneNumber;
	}
	@Override
	public String toString() {
		return "CustomerDTO [custId=" + custId + ", custName=" + custName + ", custEmail=" + custEmail
				+ ", custAddress=" + custAddress + ", custPhoneNumber=" + custPhoneNumber + "]";
	}
	
	

}
