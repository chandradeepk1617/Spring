import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.After;

public class NameComponentClassTest {

	@Before
	public void start()
	{
		System.out.println("Start");
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		NameComponentClass obj = new NameComponentClass();
		Boolean flag=obj.isValidName("chandu");
		assertTrue(flag);
	}
	@After
	public void stop()
	{
		System.out.println("Stop");
	}
	

}
