import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.customerapp.exception.CustomerException;

public class AgeComponentClassTest {

	static AgeComponentClass obj = new AgeComponentClass();

	@BeforeClass
	public static void start()
	{
		System.out.println("call me");
		
	}
		@Test
	
	public void test() {
		boolean flag;
		//fail("Not yet implemented");
	obj = new AgeComponentClass();
	}
	
	@Test//(expected=CustomerException.class)
	public void testWithNegativeValue()
{
		boolean flag;
	
		flag = obj.isValidAge(23);
		assertTrue(flag);
        
       
	}
	@Test(expected=CustomerException.class)
	public void testException()
	{
		boolean flag;
		flag = obj.isValidAge(80);
        assertFalse(flag);
	}
	@Test
	public void testEquals()
	{
		 String flag1 = obj.isValidAgeWithNegativeAge(60);
	        assertEquals("true",flag1);
	}
@AfterClass
	public static void stop()
{
	System.out.println("hogaya");
	obj=null;
}
}
