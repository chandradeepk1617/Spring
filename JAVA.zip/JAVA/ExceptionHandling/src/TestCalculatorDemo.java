import java.util.Scanner;

class Calculator
{
	int num1;
	int num2;
	int result;
	public int divide()
	{
		try
		{
		result = num1/num2;
		throw new ArrayIndexOutOfBoundsException("CHANDU45");
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Please check the divisor"+ae.getMessage());
		//	System.out.println(toString());
			return 0;
		}
		catch(Exception ae)
		{
			System.out.println(ae.getMessage()+"Generic Exception");
			return 0;
		}
		finally
		{
			System.out.println("It is executed always with or without exception");
		}
		//return result;
	}
	public Calculator()
	{
		
	}
	public Calculator(int num1, int num2)
	{
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	@Override
	public String toString() {
		return "Calculator [num1=" + num1 + ", num2=" + num2 + "]";
	}
	
	
	
}
public class TestCalculatorDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
System.out.println("ENETR NUM1");
int no1 = sc.nextInt();

System.out.println("ENTER NUM2");
try 
{
int no2 = sc.nextInt();
Calculator calc = new Calculator(no1,no2);
System.out.println("Result of Division"+calc.divide());
}
catch(Exception ae)
{
	System.out.println("Please check the type "+ae.getMessage());
	
}

	}

}
