import java.io.IOException;

class WishMe
{
	public void method1() throws IOException
	{
		System.out.println("INSIDE METHOD 1");
		method2();
	}
	public void method2() throws IOException
	{
		System.out.println("inside method2");
		throw new IOException();
	}
}
public class TestThrowsDemo {

	public static void main(String[] args) {
		WishMe w = new WishMe();
		try {
			w.method1();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}

}
