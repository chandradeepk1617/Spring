import java.util.Scanner;

public class TestAccountDemo {
	int currentBalance = 50000;
	int withdrawAmt;
	public void withdraw(int wamt)
	{
		if(wamt>currentBalance)
		{
			try 
			{
			
			throw new LowBalanceException("HI");
		}
			catch(Exception e)
			{
			System.out.println("insufficient Balance"+e.getMessage());
			}
			}
			
	
		currentBalance = currentBalance-wamt;
		System.out.println("BALANCE"+currentBalance);
	}
	public static void main(String [] args)
	{
		TestAccountDemo d = new TestAccountDemo();
		Scanner sc = new Scanner(System.in);
		int wamt = sc.nextInt();
		d.withdraw(wamt);
	}

}
