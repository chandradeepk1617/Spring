
public class LowBalanceException extends RuntimeException 
{
	String msg;
	public LowBalanceException()
	{
		
	}
	public LowBalanceException(String a)
	{
  this.msg = a;
  System.out.println(msg);
	}
	

}
