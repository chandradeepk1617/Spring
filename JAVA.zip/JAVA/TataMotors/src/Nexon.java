
public class Nexon extends Car{
int price;
int capacity;
String company="Nexon";
public Nexon(int price, int capacity,String location) {
	super(location);
	this.price = price;
	this.capacity = capacity;
}
public void run()
{
	System.out.println("Nexon is running");
}
public void getDetails()
{
	toString();
}
@Override
public String toString() {
	return super.toString()+"Nexon [price=" + price + ", capacity=" + capacity + ", company=" + company + "]";
}
}
