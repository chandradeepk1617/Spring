import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
Car car[] = new Car[4];
car[0] = new Ford(50000,4,"hyderabad");
car[1] = new Ford(60000,6,"Vijayawada");
car[2] = new Nexon(70000,4,"Banglore");
car[3] = new Nexon(80000,6,"pune");
System.out.println("1 to view all cars");
System.out.println();
int choice;
choice = sc.nextInt();


	}

}
