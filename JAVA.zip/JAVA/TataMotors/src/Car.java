
public class Car {
String location;

public Car(String location) {
	super();
	this.location = location;
}
public void run()
{
	System.out.println("in car Class");
}
public void getDetails()
{
	toString();
}
@Override
public String toString() {
	return "Car [location=" + location + "]";
}
}
