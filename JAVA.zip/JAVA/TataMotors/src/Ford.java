
public class Ford extends Car{
int price;
int capacity;
String company="Ford";
public Ford(int price, int capacity,String location) {
	super(location);
	this.price = price;
	this.capacity = capacity;
}
public void run()
{
	System.out.println("Ford is running");
}
public void getDetails()
{
	toString();
}
public String toString() {
	return super.toString()+"Nexon [price=" + price + ", capacity=" + capacity + ", company=" + company + "]";
}
}
