

	import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class PrintEvenNumbers {
	
	
	public static void main(String [] args) throws IOException
	{
		FileReader fs= new FileReader("numbers.txt");
		FileReader fs1= new FileReader("data.dat");
		FileWriter fw = new FileWriter("chandu.txt");
	int ch;
StringBuffer sb = new StringBuffer();
	String s="";
	int i=0;
	while((ch=fs.read())!=-1)
		s=s+String.valueOf((char)ch);
	
	String[] arr = s.split(",");
	for(i=0;i<arr.length;i++)
	{
		int j = Integer.parseInt(arr[i]);
		if(j%2==0)
			System.out.println(j);
		
	}
	while((ch=fs1.read())!=-1)
	{
		sb.append(String.valueOf((char)ch));
		
	}
	sb.reverse();
	System.out.println("Reverse Sequence Characters in a file are"+sb);
	for(i=0;i<sb.length();i++)
		fw.write(sb.charAt(i));
	
	fs.close();
	fs.close();
	fw.flush();
	fw.close();

	}

}