import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadOperationDemo {
 public static void main(String [] args)throws IOException
 {
	 FileOutputStream fs = new FileOutputStream("data.dat");
	 BufferedInputStream bs = new BufferedInputStream(System.in);
	 char ch;
	 while((ch=(char)bs.read())!='\n')
	 {
		 fs.write(ch);
	 }
	 fs.close();
	 bs.close();
 }
	
}
