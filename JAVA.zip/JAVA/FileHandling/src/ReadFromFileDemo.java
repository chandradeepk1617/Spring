import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
public class ReadFromFileDemo  {
public static void main(String [] args) throws IOException
{
	FileInputStream fs= new FileInputStream("data.dat");
//BufferedOutputStream bs =new BufferedOutputStream();
int ch;
StringBuffer sb = new StringBuffer();
char ch1;
int i=0;
while((ch=fs.read())!=-1)
		{
	//System.out.println((char)ch);
//	ch1[i]=((char)ch);
//	i++;
	//ch1 = char
	sb.append(String.valueOf((char)ch));
		}
//for(int j=ch1.length;j>=0;j--)
//{
//	System.out.println(ch1[j]);
//}
//fs.close();
sb.reverse();
System.out.println(sb);
}
}
