import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class EvenNum {
	public static void main(String args[]) throws IOException{
		Scanner sc=new Scanner(new File("numbers.txt"));
		String s = sc.next();
		int num,i=0;
		String s1[] =s.split(",");
		while(i<s1.length){
			num=Integer.parseInt(s1[i]);
			if(num%2==0)
				System.out.println(num);
		i++;
		}
		sc.close();
	}
}
