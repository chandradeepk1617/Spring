import com.cg.Date;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date suhasDOJ = new Date();
		Date amanDOJ = new Date(20,01,2020);
		
		System.out.println("suhas DOJ:"+suhasDOJ);
		System.out.println("amanDOJ:"+amanDOJ);

	}

}
