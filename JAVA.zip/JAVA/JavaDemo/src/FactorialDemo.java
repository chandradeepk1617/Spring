
public class FactorialDemo {
	public static void main(String[] args)
	{
		int number=Integer.parseInt(args[0]);
		int factorial=1;
		for(int i=number;i>1;i--)
		{
			factorial=factorial*i;
		}
		System.out.println(factorial);
		
		
	}
	

}
