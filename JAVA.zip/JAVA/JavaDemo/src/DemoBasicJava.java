
public class DemoBasicJava {

	public static void main(String[] args) {
		for(int i=0;i<args.length;i++)
		{
			System.out.println("ARGS["+i+"]:"+args[i]);
		}
		int sum=0;
		for(int i=1;i<args.length;i++)
		{
			int x = Integer.parseInt(args[i]);
			sum=sum+x;
			System.out.println("SUM IS "+sum);
		}
		// TODO Auto-generated method stub
		System.out.println("welcome");
		DemoBasicJava obj = new DemoBasicJava();
	     obj.main(2);
	     WishMe obj1 = new WishMe();
	     obj1.show();
	}
	public int main(int no){
		System.out.println("IN OVERLOADED MAIN"+no);
		return 2;
	}
}
	class WishMe
	{
		void show()
		{
			System.out.println("HELLO");
		}
	}


