
public class EnumDemo {
	public enum gender
	 {
		 male,female
	 }
	public static void main(String[] args) {
		

	}

}
