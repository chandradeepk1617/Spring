
public class EmployeDetails
{
 public enum gender
 {
	 male,female
 }
	
	int empno;
	String  empname;
    gender gen;
    String phoneno;
	double sal;
	
	EmployeDetails()
	{
		empno=0;
		empname="";
		gen=null;
		phoneno="0";
		sal=0.0;
		
	}
	
	EmployeDetails(int empno,String empname,gender g,String phoneno,double sal)
	{
		empno=this.empno;
		empname=this.empname;
		gen=g;
		phoneno=this.phoneno;
		sal=this.sal;
		
	}
	
	 public  String toString()
	 {
		 String s=empno+" "+empname+" "+gen;
	return s;	 
	 }
	 
	
	
}
