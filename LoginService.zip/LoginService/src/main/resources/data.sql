insert into Login(user_Name,password,login_Type,emp_Id) values('Adarsha','Adarsha','admin',3);
insert into Login(user_Name,password,login_Type,emp_Id) values('Sahil','Sahil','manager',2);
insert into Login(user_Name,password,login_Type,emp_Id) values('Chandu','Chandu','employee',1);
