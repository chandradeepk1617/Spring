package com.cg.ems.login.dao;
import com.cg.ems.login.dto.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface LoginRepository extends JpaRepository<Login,String>{
public Login findByUserName(String name);
public Login findByEmpId(int empId);
}
