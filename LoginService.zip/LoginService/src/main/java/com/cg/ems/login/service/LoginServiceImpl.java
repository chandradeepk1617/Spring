package com.cg.ems.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.login.dao.LoginRepository;
import com.cg.ems.login.dto.Login;
@Service
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginRepository dao;
	public Login getLoginDetailsByUserName(String name)
	{
		Login login = dao.findByUserName(name);
		return login;
	}
	public int getEmpIdByUserName(String name)
	{
		Login login = dao.findByUserName(name);
		return login.getEmpId();
	}
	public Login addLoginDetails(Login login)
	{
	 return dao.save(login);
	}
	public Login changePassword(Login login)
	{
		return dao.save(login);
	}
	public Login getLoginDetailsById(int empId)
	{
		Login login = dao.findByEmpId(empId);
		return login;
	}
	public boolean validateLogin(String userName,String password)
	{
		Login login = dao.findByUserName(userName);
		if(login.getUserName().equals(userName)&&login.getPassword().equals(password))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public void deleteLogin(String userName)
	{
		Login login = dao.findByUserName(userName);
		dao.delete(login);
	}
}
