package com.cg.ems.login.controller;
import com.cg.ems.login.dao.LoginRepository;
import com.cg.ems.login.dto.Login;
import com.cg.ems.login.service.*;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Api("Login Service")
@CrossOrigin("*")
public class LoginController {
    @Autowired
	LoginService service;
    Logger logger=LoggerFactory.getLogger(LoginController.class);
	@GetMapping("/login/name/{name}")
	@ApiOperation(value = "Fetches login details by userName")
	public Login getLoginDetailsByUserName(@ApiParam(value="UserName in String ")@PathVariable String name)
	{
		logger.info("Fetching loginDetails by userName");
		return service.getLoginDetailsByUserName(name);
	}
	@GetMapping("/login/{id}")
	@ApiOperation(value = "Fetches login details by EmployeeId")
	public Login getLoginDetailsByEmpId(@ApiParam(value="empId",example="1")@PathVariable int id)
	{
		logger.info("fetching loginDetails By empId");
		return service.getLoginDetailsById(id);
	}
	@PostMapping("/login/add")
	@ApiOperation(value="Add login Details of a employee")
	public Login addLoginDetails(@ApiParam(value="Login object in json format")@RequestBody Login login)
	{
		logger.info("Adding loginDetails of a new Employee");
		return service.addLoginDetails(login);
	}
	@PutMapping("/login/changePassword")
	@ApiOperation(value = "Changes password of a user")
	public Login changePassword(@ApiParam(value="Login Object in json format")@RequestBody Login login)
	{
		logger.info("Changing password of Employee");
		return service.changePassword(login);
	}
	@GetMapping("/login/id/{name}")
	@ApiOperation(value = "Fetches Employee Id by userName")
	//@HystrixCommand(fallbackMethod = "getEmpIdByUserNameFailed",commandKey = "getEmpIdByUserName")
	public int getEmpIdByUserName(@ApiParam(value="UserName in String ")@PathVariable String name)
	{
		logger.info("fetches EmployeeId by userName");
		return service.getEmpIdByUserName(name);
	}
	public int getEmpIdByUserNameFailed(String name)
	{
		return 0;
	}
	@GetMapping("/login/validate/{name}/{password}")
	@ApiOperation(value = "Validates userName and password")
	//@HystrixCommand(fallbackMethod = "validateLoginFailed",commandKey = "validateLogin")
	public boolean validateLogin(@ApiParam(value="UserName in String ")@PathVariable String name,@ApiParam(value="Password in String ")@PathVariable String password)
	{
		logger.info("Validates userName and Password");
		return service.validateLogin(name, password);
	}
	public boolean validateLoginFailed(String name,String password)
	{
		return false;
	}
	@DeleteMapping("/login/delete/{name}")
	@ApiOperation(value = "Deletes login details of a user by userName")
	public void deleteLogin(@ApiParam(value="UserName in String ")@PathVariable String name)
	{
		logger.info("Deletes loginDetails of employee");
	service.deleteLogin(name);
	}
	
}
