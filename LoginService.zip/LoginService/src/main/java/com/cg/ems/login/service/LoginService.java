package com.cg.ems.login.service;

import com.cg.ems.login.dto.Login;

public interface LoginService {
	public Login getLoginDetailsByUserName(String name);
	public int getEmpIdByUserName(String name);
	public Login addLoginDetails(Login login);
	public Login changePassword(Login login);
	public Login getLoginDetailsById(int empId);
	public boolean validateLogin(String userName,String password);
	public void deleteLogin(String userName);
}
