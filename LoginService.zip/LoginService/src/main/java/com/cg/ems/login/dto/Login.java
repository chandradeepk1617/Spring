package com.cg.ems.login.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Login {
@Id

String userName;

String password;

String loginType;

int empId;
public Login() {
	super();
}
public Login(String userName, String password, String loginType, int empId) {
	super();
	this.userName = userName;
	this.password = password;
	this.loginType = loginType;
	this.empId = empId;
}

public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getLoginType() {
	return loginType;
}
public void setLoginType(String loginType) {
	this.loginType = loginType;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}

}
