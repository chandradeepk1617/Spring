Insert into employee(emp_name,emp_id,emp_salary,dept_id,dateofbirth,contact_Number,manager_Id,num_of_leaves,designation) values('Sahil',2,80000,101,To_Date('1989/04/12','yyyy/mm/dd'),7539921040,2,22,'manager');

Insert into employee(emp_name,emp_id,emp_salary,dept_id,dateofbirth,contact_Number,manager_Id,num_of_leaves,designation) values('Chandu',1,50000,101,To_Date('1999/04/21','yyyy/mm/dd'),9963673280,2,22,'employee');

Insert into employee(emp_name,emp_id,emp_salary,dept_id,dateofbirth,contact_Number,manager_Id,num_of_leaves,designation) values('Adarsha',3,100000,101,To_Date('1985/12/21','yyyy/mm/dd'),7539921041,2,22,'admin');

