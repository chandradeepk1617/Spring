package com.cg.ems.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ems.employee.dto.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
public List<Employee> findByEmpId(int id);
public List<Employee> findByEmpName(String name);
public List<Employee> findByManagerId(int id);

}
