package com.cg.ems.employee.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.ems.employee.exception.EmployeeNotFoundException;

@ControllerAdvice
public class EmployeeControllerAdvice {
	@ExceptionHandler(EmployeeNotFoundException.class)
    public final ResponseEntity<String> exceptionHandler
                        ( EmployeeNotFoundException e) 
    {
       
     System.out.println();
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }
}
