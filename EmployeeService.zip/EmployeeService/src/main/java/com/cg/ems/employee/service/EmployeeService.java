package com.cg.ems.employee.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.ems.employee.dto.Employee;
import com.cg.ems.employee.exception.EmployeeNotFoundException;

public interface EmployeeService {
	public List<Employee> findEmployeeById(int id) throws EmployeeNotFoundException;
	public List<Employee> findEmployeeByName(String name) throws EmployeeNotFoundException;
	public List<Employee> findEmployeeByManagerId(int id);
	public List<Employee> findEmployeeByUserName(String name);
	public Employee addNewEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	public void deleteEmployee(int id);
}
