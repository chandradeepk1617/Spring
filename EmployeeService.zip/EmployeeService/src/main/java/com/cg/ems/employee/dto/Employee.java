package com.cg.ems.employee.dto;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Employee {
	private String empName;
	@Id
private int empId;
public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public Date getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public int getNumOfLeaves() {
		return numOfLeaves;
	}
	public void setNumOfLeaves(int numOfLeaves) {
		this.numOfLeaves = numOfLeaves;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
private int empSalary;
private int deptId;
private Date dateofbirth;
private long contactNumber;
private int managerId;
private int numOfLeaves;
private String designation;
public Employee(String empName, int empId, int empSalary, int deptId, Date dateofbirth, long contactNumber,
		int managerId, int numOfLeaves, String designation) {
	super();
	this.empName = empName;
	this.empId = empId;
	this.empSalary = empSalary;
	this.deptId = deptId;
	this.dateofbirth = dateofbirth;
	this.contactNumber = contactNumber;
	this.managerId = managerId;
	this.numOfLeaves = numOfLeaves;
	this.designation = designation;
}
public Employee() {
	super();
}
@Override
public String toString() {
	return "Employee [empName=" + empName + ", empId=" + empId + ", empSalary=" + empSalary + ", deptId=" + deptId
			+ ", dateofbirth=" + dateofbirth + ", contactNumber=" + contactNumber + ", managerId=" + managerId
			+ ", numOfLeaves=" + numOfLeaves + ", designation=" + designation + "]";
}

}
