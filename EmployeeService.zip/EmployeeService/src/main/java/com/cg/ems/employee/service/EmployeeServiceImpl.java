package com.cg.ems.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.ems.employee.dao.EmployeeRepository;
import com.cg.ems.employee.dto.*;
import com.cg.ems.employee.exception.EmployeeNotFoundException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository dao;

	public List<Employee> findEmployeeById(int id) throws EmployeeNotFoundException{
		System.out.println(dao.findByEmpId(id).size());
		if (dao.findByEmpId(id).size() > 0)
			return dao.findByEmpId(id);
		else
			throw new EmployeeNotFoundException("Employee with id" + id + " not found");
	}

	public List<Employee> findEmployeeByName(String name) throws EmployeeNotFoundException{
		if (dao.findByEmpName(name).size() > 0)
			return dao.findByEmpName(name);
		else
			throw new EmployeeNotFoundException("Employee with name" + name + " not found");
	}

	public List<Employee> findEmployeeByManagerId(int id) {
		return dao.findByManagerId(id);
	}

	public List<Employee> findEmployeeByUserName(String name) {
		int id;
		id = new RestTemplate().getForObject("http://localhost:8081/login/id/" + name, Integer.class);
		System.out.println(dao.findByEmpId(id));
		return dao.findByEmpId(id);
	}

	public Employee addNewEmployee(Employee employee) {
		return dao.save(employee);
	}

	public Employee updateEmployee(Employee employee) {
		return dao.save(employee);
	}

	public void deleteEmployee(int id) {
		Employee employee = dao.findByEmpId(id).get(0);
		dao.delete(employee);
	}
	
}
