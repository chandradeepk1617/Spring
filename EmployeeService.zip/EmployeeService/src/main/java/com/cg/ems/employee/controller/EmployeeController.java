package com.cg.ems.employee.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ems.employee.dao.EmployeeRepository;
import com.cg.ems.employee.dto.Employee;
import com.cg.ems.employee.service.EmployeeService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
@RestController
@CrossOrigin("*")
@Api("Employee Service")
public class EmployeeController {
	@Autowired
	EmployeeService service;
	 Logger logger=LoggerFactory.getLogger(EmployeeController.class);
	@GetMapping("/employee/id/{id}")
	@ApiOperation(value = "Fetches Employee details by Id")
	//@HystrixCommand(fallbackMethod = "EmployeeNotFound",commandKey = "findEmployeeById")
	public List<Employee> findEmployeeById(@ApiParam(value="empId",example="1")@PathVariable int id)
	{
		logger.info("Fetching details of employee with id"+id);
		return service.findEmployeeById(id);
	}
	
	@GetMapping("/employee/name/{name}")
	@ApiOperation(value = "Fetches Employee details by name")
	//@HystrixCommand(fallbackMethod = "EmployeeNameNotFound",commandKey = "findEmployeeByName")
	public List<Employee> findEmployeeByName(@ApiParam(value="name")@PathVariable String name)
	{
		logger.info("Fetching details of employee with name"+name);
		return service.findEmployeeByName(name);
	}

	@GetMapping("/employee/managerid/{id}")
	@ApiOperation(value = "Fetches Employee details by managerId")
	@HystrixCommand(fallbackMethod = "EmployeeByManagerIdNotFound",commandKey = "findEmployeeByManagerId")
	public List<Employee> findEmployeeByManagerId(@ApiParam(value="managerId",example="1")@PathVariable int id)
	{
		logger.info("Fetching details of employees with managerId"+id);
		return service.findEmployeeByManagerId(id);
	}
	public List<Employee> EmployeeByManagerIdNotFound(int id)
	{
		List<Employee> empList = new ArrayList<Employee>();
		return empList;
	}
	@GetMapping("/employee/userName/{name}")
	@ApiOperation(value = "Fetches Employee details by userName")
	//@HystrixCommand(fallbackMethod = "EmployeeByUserNameNotFound",commandKey = "findEmployeeByUserName")
	public List<Employee> findEmployeeByUserName(@ApiParam(value="name")@PathVariable String name)
	{
		logger.info("Fetching details of employee with userName"+name);
		return service.findEmployeeByUserName(name);
	}
	
	@PutMapping("/employee/update")
	@ApiOperation(value = "Updates Employee Details")
	@HystrixCommand(fallbackMethod = "UpdateEmployeeNotFound",commandKey = "updateEmployee")
	public Employee updateEmployee(@ApiParam(value="Employee object in json")@RequestBody Employee employee )
	{
		logger.info("Updating details of a employe");
	return service.updateEmployee(employee);	
	}
	public Employee updateEmployeeNotFound(Employee employee)
	{
		return null;
	}
	
	@PostMapping("/employee/add")
	@ApiOperation("Adds new Employee")
	public Employee addEmployee(@ApiParam(value="Employee in json format")@RequestBody Employee employee)
	{
		return service.addNewEmployee(employee);
	}
	@DeleteMapping("/employee/delete/{id}")
	@ApiOperation("Delete Employee By id")
	public void deleteEmployee(@ApiParam(value="Employee id",example="1")@PathVariable int id)
	{
		service.deleteEmployee(id);
	}
}
