package com.cg.employeemaintaince.service;

import com.cg.employeemaintaince.dao.LoginDao;
import com.cg.employeemaintaince.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {

	
	private LoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public boolean validate(String userName, String password, int userRole) {
		// TODO Auto-generated method stub
		return loginDao.validate(userName, password, userRole);
	}

}
