package com.cg.employeemaintaince.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Login;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean validate(String userName, String pwd, int userRole) {
		// TODO Auto-generated method stub
		String userType;
		if(userRole==1)
		{
			userType="admin";
		}
		else if(userRole==2)
		{
			userType="manager";
		}
		else 
		{
			userType="employee";
		}
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		try
		{
			String str="SELECT user FROM Login user WHERE user.userName=:n";
			TypedQuery query=em.createQuery(str, Login.class);
			query.setParameter("n", userName);
			Login userLogin=(Login) query.getSingleResult();
			System.out.println("Login details are: "+userLogin+"\nusername: "+userLogin.getUserName().equals(userName));
			if(userLogin.getPassword().equals(pwd) && userLogin.getUserName().equals(userName)  &&  userLogin.getLoginType().equals(userType))
			{
				return true;
			}
			else
				return false;
		}
		catch(Exception e)
		{
			return false;
		}
		
	}

}
