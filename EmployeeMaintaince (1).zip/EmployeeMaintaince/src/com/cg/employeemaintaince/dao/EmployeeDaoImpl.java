package com.cg.employeemaintaince.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;
import com.cg.employeemaintaince.dto.Login;

public class EmployeeDaoImpl implements EmployeeDao{

	
	@Override
	public int getEmpIdFromLoginTable(String userName)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		return entity.getEmpId();
	}
	
	@Override
	public int getManagerIdForEmp(String userName)
	{
		int empId=new EmployeeDaoImpl().getEmpIdFromLoginTable(userName);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		return entity.getManagerId();
	}
	
	@Override
	public int getLeaveBalance(String userName)
	{
		int empId=new EmployeeDaoImpl().getEmpIdFromLoginTable(userName);
		System.out.println("empId: "+empId);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		System.out.println("Emp details are: "+entity);
		System.out.println("leaves are: "+entity.getNoOfLeaves());
		return entity.getNoOfLeaves();
	}
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		em.close();
		emf.close();
		return entity;
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT e FROM Employee e WHERE e.empName=:n";
		TypedQuery query=em.createQuery(str, Employee.class);
		query.setParameter("n", fName);
		List<Employee> empList=query.getResultList();
		return empList;
	}

	@Override
	public Employee displayEmpDetails(String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		
			String str="SELECT user FROM Login user WHERE user.userName=:n";
			TypedQuery query=em.createQuery(str,Login.class);
			query.setParameter("n", userName);
			Login userLogin=(Login) query.getSingleResult();
			System.out.println("Login details are: "+userLogin);
			String empQueryString="SELECT e FROM Employee e WHERE e.empId=:id";
			TypedQuery empQuery=em.createQuery(empQueryString,Employee.class );
			empQuery.setParameter("id", userLogin.getEmpId());
			Employee empDetails=(Employee) empQuery.getSingleResult();
			return empDetails;
		
	}

	@Override
	public boolean changeAccountPassword(String userName, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(checkOldPassword(oldPassword,userName))
		{
			if(changeAccountPassword(newPassword,userName))
			{
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave newLeave=new Leave();
		newLeave.setAppliedDate(leave.getAppliedDate());
		newLeave.setEmpId(leave.getEmpId());
		newLeave.setFromDate(leave.getFromDate());
		newLeave.setLeaveId(leave.getLeaveId());
		newLeave.setLeavesRemaining(leave.getLeavesRemaining());
		newLeave.setLeaveStatus(leave.getLeaveStatus());
		newLeave.setManagerId(leave.getManagerId());
		newLeave.setNoOfDatesApplied(leave.getNoOfDatesApplied());
		newLeave.setReason(leave.getReason());
		newLeave.setToDate(leave.getToDate());
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(newLeave);
		et.commit();
		em.close();
		emf.close();
		return true;
	}

	@Override
	public Leave editLeaveFromDate(int leaveId, Date fromDate)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		if(entity!=null && entity.getLeaveStatus().equals("not approved"))
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setFromDate(fromDate);
			entity.setAppliedDate(java.sql.Date.valueOf(LocalDate.now()));
			em.close();
			emf.close();
			et.commit();
			return entity;
		}
		else
		{
			em.close();
			emf.close();
			return null;
		}
	}

	@Override
	public Leave SearchLeave(int leaveId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		try
		{
			String str="SELECT leave FROM Leave leave WHERE leave.leaveId=:n";
			TypedQuery query=em.createQuery(str, Leave.class);
			query.setParameter("n", leaveId);
			Leave leaveList=(Leave) query.getSingleResult();
			return leaveList;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}

	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			System.out.println("first");
			em.remove(entity);
			System.out.println("gigb");
			System.out.println("status: "+entity.getLeaveStatus());
			if(entity.getLeaveStatus().equals("approved"))
			{
				System.out.println("entered");
				int empId=entity.getEmpId();
				int noOfLeaves=entity.getLeavesRemaining();
				noOfLeaves++;
				changeNoOfLeaves(empId,noOfLeaves);
				changeLeavesOfEmp(empId,noOfLeaves);
			}

			et.commit();
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}
	
	public static void changeLeavesOfEmp(int empId,int noOfLeaves)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT leave FROM Leave leave WHERE leave.empId=:n";
		TypedQuery query=em.createQuery(str, Leave.class);
		query.setParameter("n", empId);
		List<Leave> leaveList=query.getResultList();
		for(Leave leave:leaveList)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			leave.setLeavesRemaining(noOfLeaves);
			et.commit();
		}
		em.close();
		emf.close();
	}
	
	public static void changeNoOfLeaves(int empId,int noOfLeaves)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee emp=em.find(Employee.class, empId);
		EntityTransaction et=em.getTransaction();
		et.begin();
		emp.setNoOfLeaves(noOfLeaves);
		et.commit();
		em.close();
		emf.close();
	}

	public static boolean changeAccountPassword(String newPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setPassword(newPassword);
			et.commit();
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	public static boolean checkOldPassword(String oldPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null && entity.getPassword().equals(oldPassword))
		{
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public Leave editLeaveToDate(int leaveId, Date toDate) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		if(entity!=null && entity.getLeaveStatus().equals("not approved"))
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setToDate(toDate);
			entity.setAppliedDate(java.sql.Date.valueOf(LocalDate.now()));
			em.close();
			emf.close();
			et.commit();
			return entity;
		}
		else
		{
			em.close();
			emf.close();
			return null;
		}
	}

	@Override
	public Leave editLeaveReason(int leaveId, String newReason) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		if(entity!=null && entity.getLeaveStatus().equals("not approved"))
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setReason(newReason);
			entity.setAppliedDate(java.sql.Date.valueOf(LocalDate.now()));
			em.close();
			emf.close();
			et.commit();
			return entity;
		}
		else
		{
			em.close();
			emf.close();
			return null;
		}
	}

	@Override
	public Date getFromDate(int leaveId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		return entity.getFromDate();
	}

	@Override
	public Date getToDate(int leaveId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		return entity.getToDate();
	}

}
