package com.cg.employeemaintaince.dao;

import java.util.List;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;


public interface ManagerDao {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayOwnDetials(String useName);
	public List<Employee> displaySubEmployees(String userName);
	public List<Leave> showLeavesApplied(String userName);
	public boolean accept(int leaveId,String userName);
	public boolean reject(int leaveId,String reason,String userName);
	public boolean changeAccountPassword(String userName,String oldPassword,String newPassword);
}
