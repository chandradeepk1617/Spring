package com.cg.employeemaintaince.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="emp")
public class Emp {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CUST_SEQ")
    @SequenceGenerator(sequenceName = "customer_seq", allocationSize = 1, name = "CUST_SEQ")
	@Column(name="EMPID")
	private int empId;
	@Column(name="EMPNAME")
	private String empName;
	@Column(name="EMPSALARY")
	private float salary;
	@Column(name="EMPDEPTID")
	private int departmentId;
	@Column(name="EMPDOB")
	private Date dateOfBirth;
	@Column(name="EMPCONTACTNUMBER")
	private Long contactNumber;
	@Column(name="MANAGERID")
	private int managerId;
	@Column(name="NOOFLEAVES")
	private int noOfLeaves;
	
	
	public Emp()
    {
		// TODO Auto-generated constructor stub
	}


	public Emp(String userName, float salary, int departmentId, Date dateOfBirth, Long contactNumber,
			int managerId, int noOfLeaves) {
		super();
		this.empName = userName;
		this.salary = salary;
		this.departmentId = departmentId;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.managerId = managerId;
		this.noOfLeaves = noOfLeaves;
	}


	public int getUserId() {
		return empId;
	}


	public void setUserId(int userId) {
		this.empId = userId;
	}


	public String getUserName() {
		return empName;
	}


	public void setUserName(String userName) {
		this.empName = userName;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	public int getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public int getManagerId() {
		return managerId;
	}


	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}


	public int getNoOfLeaves() {
		return noOfLeaves;
	}


	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}


	@Override
	public String toString() {
		return "Employee [userId=" + empId + ", userName=" + empName + ", salary=" + salary + ", departmentId="
				+ departmentId + ", dateOfBirth=" + dateOfBirth + ", contactNumber=" + contactNumber + ", managerId="
				+ managerId + ", noOfLeaves=" + noOfLeaves + "]";
	}
	
}
