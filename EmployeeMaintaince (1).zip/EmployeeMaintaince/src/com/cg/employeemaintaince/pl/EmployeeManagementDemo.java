package com.cg.employeemaintaince.pl;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;
import com.cg.employeemaintaince.exception.EmpException;
import com.cg.employeemaintaince.service.AdminService;
import com.cg.employeemaintaince.service.AdminServiceImpl;
import com.cg.employeemaintaince.service.EmployeeService;
import com.cg.employeemaintaince.service.EmployeeServiceImpl;
import com.cg.employeemaintaince.service.LoginServiceImpl;
import com.cg.employeemaintaince.service.ManagerService;
import com.cg.employeemaintaince.service.ManagerServiceImpl;

public class EmployeeManagementDemo {

	public static void main(String[] args) {
		/*
		 * Scanner sc=new Scanner(System.in); AdminDaoImpl ad=new AdminDaoImpl();
		 * LoginDaoImpl l=new LoginDaoImpl(); EmployeeDaoImpl empDao=new
		 * EmployeeDaoImpl(); ManagerDaoImpl mng=new ManagerDaoImpl();
		 * 
		 * 
		 * 
		 * System.out.println("Enter employee name"); String name=sc.next();
		 * System.out.println("Enter Salary"); float sal=sc.nextFloat();
		 * System.out.println("Enter Contact number"); long number=sc.nextLong();
		 * System.out.println("Enter ManagerId"); int mgr=sc.nextInt();
		 * System.out.println("Enter department id"); int dept=sc.nextInt();
		 * System.out.println("Enter DOB in format yyyy-mm-dd"); String d=sc.next();
		 * Date dat=Date.valueOf(d); System.out.println("Enter DOJ"); String
		 * j=sc.next(); Date dat1=Date.valueOf(j);
		 * System.out.println("Enter martials status as single(s)/married(m)"); String
		 * martial=sc.next(); System.out.println("Enter address"); String
		 * address=sc.next(); System.out.println("Enter designation"); String
		 * des=sc.next(); System.out.println("Enter grade id"); int grade=sc.nextInt();
		 * Employee emp=new Employee(); emp.setEmpName(name); emp.setSalary(sal);
		 * emp.setContactNumber(number); emp.setDateOfBirth(dat);
		 * emp.setDepartmentId(dept); emp.setManagerId(mgr); emp.setNoOfLeaves(22);
		 * emp.setDateOfJoining(dat1); emp.setEmpMartialStatus(martial);
		 * emp.setEmpAddress(address); emp.setEmpDesignation(des); emp.setGrade(grade);
		 * ad.addEmployee(emp); System.out.println("Employee is inserted");
		 * 
		 * 
		 * 
		 * System.out.println("Enter the empid to be deleted:"); int id=sc.nextInt();
		 * boolean b=ad.deleteEmployeeById(id); System.out.println("boolean is: "+b);
		 * 
		 * 
		 * 
		 * 
		 * System.out.println("Enter usesrname to change password"); String s=sc.next();
		 * System.out.println("enter old pwd"); String old=sc.next();
		 * if(ad.checkOldPassword(old, s)) { System.out.println("Enter new pwd"); String
		 * s1=sc.next(); System.out.println("Result is: "+ad.changeAccountPassword(s1,
		 * s)); } else { System.out.println("pwd not match"); }
		 * 
		 * 
		 * 
		 * 
		 * 
		 * System.out.println("Enter emp names to get searched"); String id=sc.next();
		 * System.out.println("Done and result is: "+ad.searchEmployessByName(id));
		 * 
		 * 
		 * System.out.println("Enter your choice 1.admin 2.employee 3.manager"); int
		 * userType=sc.nextInt(); System.out.println("Enter user name"); String
		 * name=sc.next(); System.out.println("Enter pwd"); String pwd=sc.next();
		 * if(l.validate(name, pwd, userType)) { System.out.println("Login sucessful");
		 * //System.out.println("employee own details: "+empDao.displayEmpDetails(name))
		 * ;
		 * 
		 * System.out.println("Change password Enter old password"); String
		 * old=sc.next(); System.out.println("Enter new password"); String
		 * newPwd=sc.next();
		 * System.out.println(empDao.changeAccountPassword(name,old,newPwd));
		 * 
		 * 
		 * 
		 * 
		 * 
		 * System.out.println("Applying for leave");
		 * System.out.println("Enter fromdate in yyyy-mm-dd"); String
		 * fromDate=sc.next(); Date f=Date.valueOf(fromDate); LocalDate
		 * fDate=LocalDate.parse(fromDate); System.out.println("Enter todate"); String
		 * toDate=sc.next(); Date t=Date.valueOf(toDate); LocalDate
		 * tDate=LocalDate.parse(toDate); System.out.println("Enter reason"); String
		 * reason=sc.next(); Leave leave=new Leave();
		 * leave.setAppliedDate(java.sql.Date.valueOf(LocalDate.now()));
		 * leave.setEmpId(empDao.getEmpIdFromLoginTable(name)); leave.setFromDate(f);
		 * leave.setLeavesRemaining(empDao.getLeaveBalance(name));
		 * leave.setLeaveStatus("approved");
		 * leave.setManagerId(empDao.getManagerIdForEmp(name));
		 * leave.setNoOfDatesApplied((int) ChronoUnit.DAYS.between(fDate, tDate));
		 * leave.setReason(reason); leave.setToDate(t);
		 * System.out.println("Leave is: "+empDao.addLeave(leave));
		 * 
		 * 
		 * 
		 * 
		 * System.out.println("Cancel leave: "); System.out.println("Enter leave id");
		 * int id=sc.nextInt(); //System.out.println("Enter fromdate in yyyy-mm-dd");
		 * //String fromDate=sc.next(); //Date f=Date.valueOf(fromDate);
		 * System.out.println(" edit Leave is found: "+empDao.cancelLeave(id));
		 * 
		 * 
		 * 
		 * System.out.println("Password changing:");
		 * System.out.println("Enter newpass"); String npwd=sc.next();
		 * System.out.println("Enter old"); String old=sc.next();
		 * System.out.println("Password changed is :  "+empDao.changeAccountPassword(
		 * name, old, npwd));
		 * 
		 * 
		 * System.out.println("Manager search:old pwd "); String n=sc.next();
		 * System.out.println("new"); int id=sc.nextInt(); //String od=sc.next();
		 * System.out.println("Search result :"+mng.reject(id, n, name)); } else
		 * System.out.println("Invalid credentials")
		 */;

		int flag = 0;
		int flag1 = 0;
		while (true)
		{
			System.out.println("Login types:\n" + "\tEnter 1 for : Admin \n " + "\tEnter 2 for : Manager\n "
					+ "\tEnter 3 for : Employee");
			int loginChoice;
			String choice = null;
			LoginServiceImpl loginService = new LoginServiceImpl();
			Scanner scanner = new Scanner(System.in);
			loginChoice = scanner.nextInt();
			String userName;
			String password;
			boolean valid;
			System.out.println("Enter your User Name:");
			userName = scanner.next();
			System.out.println("Enter your password:");
			password = scanner.next();
			valid = loginService.validate(userName, password, loginChoice);
			if (valid && loginChoice == 1) 
			{
				boolean operation = true;
				while (operation) 
				{
					System.out.println(
							"Admin:\n" + "\t1.Add Employee\n" + "\t2.Delete Employee\n" + "\t3.Modify employee By Id\n"
									+ "\t4.Search employee by Id\n" + "\t5.Search employee by name\n"
									+ "\t6.display all the employees\n" + "\t7.Change Password\n" + "\t8.to exit\n");

					choice = scanner.next();
					scanner.nextLine();
					AdminService adminService = new AdminServiceImpl();

					switch (choice) 
					{
						case "1":
							float empSalary = 0f;
							Employee emp=new Employee();
							System.out.println("Enter Employee Name:");
							String empName = scanner.nextLine();
							while (flag != 1) 
							{
								if (adminService.isValidName(empName))
									flag = 1;
								else 
								{
									System.out.println(
										"Name must start with a capital letter And must have atleast 3 characters");
									System.out.println("Enter Name Again");
									empName = scanner.nextLine();
								}
							}
							flag = 0;

							/* System.out.println("Enter Employee Salary"); */
							while(flag !=1)
							{
								try 
								{
									System.out.println("Enter Employee Salary");
									empSalary = scanner.nextFloat();
									flag=1;
								} 
								catch (InputMismatchException ime) 
								{
									flag=0;
								}
							}
							
							flag=0;
							int empDeptId=0;
							while(flag!=1)
							{
								System.out.println("Enter Employee Department Id");
								empDeptId = scanner.nextInt();
								if(adminService.isValidDepartmentId(empDeptId))
								{
									flag=1;
								}
								else
								{
									System.out.println("The Department Id that entered is not valid");
									System.out.println("Enter correct department Id");
								}
							}
							
							flag=0;
							System.out.println("Enter employee date of birth in the format yyyy mm dd");
							Date empDOB = null;
							while (flag != 1) 
							{
								int year = 0;
								int month = 0;
								int dayOfMonth = 0;
								System.out.println("Enter year");
								while (flag1 != 1) 
								{
									year = scanner.nextInt();
									if (adminService.isValidYear(String.valueOf(year))) 
									{
										flag1 = 1;
									} 
									else 
									{
										System.out.println("year must be in yyyy format");
										System.out.println("Enter year in yyyy format");
									}
								}
								flag1 = 0;
								System.out.println("Enter month");
								while (flag1 != 1) 
								{
									month = scanner.nextInt();
									if (adminService.isValidMonth(month)) 
									{
										flag1 = 1;
									} 
									else 
									{
										System.out.println("Month can't be greater than  12 or less than 1");
										System.out.println("Enter month again");
									}
								}
								flag1 = 0;
								System.out.println("Enter date");
								while (flag1 != 1) 
								{
									dayOfMonth = scanner.nextInt();
									if (adminService.isValidDay(dayOfMonth, month, year)) 
									{
										flag1 = 1;
									} 
									else 
									{
										System.out.println("Improper day");
										System.out.println("Enter day again");
									}
								}
								String dob=year+"-"+month+"-"+dayOfMonth;
								empDOB = Date.valueOf(dob);
							    if (adminService.isValidDate(empDOB))
							    	flag = 1;
							    else 
							    {
							    	System.out.println("Date of birth cannot be after the present date\n");
							    	System.out.println("Enter Date of birth again\n");
							    }
							}
							
							flag=0;
							flag1=0;
							System.out.println("Enter employee date of Joining in the format yyyy mm dd");
							Date empDOJ = null;
							while (flag != 1) 
							{
								int year = 0;
								int month = 0;
								int dayOfMonth = 0;
								System.out.println("Enter year");
								while (flag1 != 1) 
								{
									year = scanner.nextInt();
									if (adminService.isValidYear(String.valueOf(year))) 
									{
										if(year>(empDOB.getYear()+18))
										{
											flag1 = 1;
										}
										else
										{
											System.out.println("Joining year must be 18 years greater than the year of DOB");
											System.out.println("Enter year in yyyy format again");
										}
									} 
									else 
									{
										System.out.println("year must be in yyyy format");
										System.out.println("Enter year in yyyy format");
									}
								}
								flag1 = 0;
								System.out.println("Enter month");
								while (flag1 != 1) 
								{
									month = scanner.nextInt();
									if (adminService.isValidMonth(month)) 
									{
										flag1 = 1;
									} 
									else 
									{
										System.out.println("Month can't be greater than  12 or less than 1");
										System.out.println("Enter month again");
									}
								}
								flag1 = 0;
								System.out.println("Enter date");
								while (flag1 != 1) 
								{
									dayOfMonth = scanner.nextInt();
									if (adminService.isValidDay(dayOfMonth, month, year)) 
									{
										flag1 = 1;
									} 
									else 
									{
										System.out.println("In proper day");
										System.out.println("Enter day again");
									}
								}
								String dob=year+"-"+month+"-"+dayOfMonth;
								empDOB = Date.valueOf(dob);
							    if (adminService.isValidDate(empDOB))
							    	flag = 1;
							    else 
							    {
							    	System.out.println("Date of birth cannot be after the present date\n");
							    	System.out.println("Enter Date of birth again\n");
							    }
							}
							flag = 0;
							System.out.println("Enter Employee Contact Number");
							Long empContactNumber = 0L;
							while (flag != 1) 
							{
								empContactNumber = scanner.nextLong();
								if (adminService.isValidPhone(String.valueOf(empContactNumber)))
									flag = 1;
								else 
								{
									System.out.println("Contact number must have 10 digits and does not start with 0");
									System.out.println("Enter Contact number Again");
								}
							}
							
							flag = 0;
							int empManagerId=0;
							System.out.println("Enter Employee Manager Id");
							while(flag !=1 )
							{
								empManagerId= scanner.nextInt();
								if(adminService.isValidManagerId(empManagerId))
								{
									flag=1;
								}
								else
								{
									System.out.println("Entered ManagerId is not valid");
									System.out.println("Enter Manager Id again");
								}
							}
							flag=0;
							String empAddress;
							System.out.println("Enter Employee Address");
							empAddress=scanner.next();
							System.out.println("Enter Employee martial status (s) for single and (m) for married");
							String martialStatus="a";
							while(flag!=1)
							{
								martialStatus=scanner.next();
								if(adminService.isValidMartialStatus(martialStatus))
								{
									flag=1;
								}
								else
								{
									System.out.println("Invalid martial status");
									System.out.println("Enter correct status again");
								}
							}
							
							flag=0;
							String grade=adminService.getValidGrade(empSalary); 
							String designation=adminService.getDesignation(empDeptId);
							//creating emp object
							//System.out.println("Object creation started:");
							//System.out.println("name");
							emp.setEmpName(empName);
							//System.out.println("DOB");
							emp.setDateOfBirth(empDOB);
							//System.out.println("DOJ");
							emp.setDateOfJoining(empDOJ);
							//System.out.println("DeptId");
							emp.setDepartmentId(empDeptId);
							//System.out.println("grade");
							emp.setGrade(grade);
							//System.out.println("Desig");
							emp.setEmpDesignation(designation);
							//System.out.println("sal");
							emp.setSalary(empSalary);
							//System.out.println("ms");
							emp.setEmpMartialStatus(martialStatus);
							//System.out.println("address");
							emp.setEmpAddress(empAddress);
							//System.out.println("no");
							emp.setContactNumber(empContactNumber);
							emp.setManagerId(empManagerId);
							emp.setNoOfLeaves(22);
							boolean status = adminService.addEmployee(emp);
							if (status) 
							{
								System.out.println("Employee is added successfully");
							} 
							else 
							{
								throw new EmpException("error in adding the new employee to the database");
							}
							break;
						case "2":
							System.out.println("Enter Employee Id for deletion");
							int empDeleteId = scanner.nextInt();
							boolean present=adminService.isValidManagerId(empDeleteId);
							if(present)
							{
								boolean deletionStatus = adminService.deleteEmployeeById(empDeleteId);
								if (deletionStatus) 
								{
									System.out.println("Employee is deleted Sucessfully");
								} 
								else 
								{
									throw new EmpException("error in deleting the employee from database");
								}
							}
							else
							{
								System.out.println("Employee Id is not valid");
							}
							
							break;
						case "3":
						// Im writing code for only name modification as of now
							System.out.println("Enter Employee Id for Modification");
							int empToBeModifiedId = scanner.nextInt();
							System.out.println("\nEnter 1: to update name\n" + "Enter 2: to update Salary\n"
									+ "Enter 3: to update Department id\n" + "Enter 4: to update Date of Birth\n"
									+ "Enter 5: to update Contact Number\n" + "Enter 6: to update Manager Id\n"
									+"Enter 7: to update Martial Stauts\n"+"Enter 8: to update Address\n");
							int modifyChoice = scanner.nextInt();
							boolean bool;
							switch (modifyChoice) 
							{
								case 1:
									flag = 0;
									System.out.println("Enter the new Name");
									String newName = scanner.nextLine();
									// scanner.nextLine();
									while (flag != 1) 
									{
										newName = scanner.nextLine();
										if (adminService.isValidName(newName))
											flag = 1;
										else 
										{
											System.out.println(
													"Name must start with a capital letter And must have atleast 3 characters");
											System.out.println("Enter Name Again");
										}
									}
									flag = 0;
									bool = adminService.modifyEmployeeName(empToBeModifiedId, newName);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id not Found");
									}
									break;
								case 2:
									System.out.println("Enter the new Salary");
									float newSal = scanner.nextFloat();
									bool = adminService.modifyEmployeeSalary(empToBeModifiedId, newSal);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 3:
									System.out.println("Enter the new Department Id");
									int deptFlag=0;
									int newdeptId=0;
									while(deptFlag!=1)
									{
										newdeptId = scanner.nextInt();
										if(adminService.isValidDepartmentId(newdeptId))
										{
											deptFlag=1;
										}
										else
										{
											System.out.println("Enter correct department Id");
										}
									}
									bool = adminService.modifyEmployeeDepartmentId(empToBeModifiedId, newdeptId);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 4:
									flag1 = 0;
									flag = 0;
									System.out.println("Enter the correct Date Of Birth");
									Date newDOB = null;
									int correctYear = 0;
									int correctMonth = 0;
									int correctDayOfMonth = 0;
									while (flag != 1) 
									{
										System.out.println("Enter year");
										while (flag1 != 1) 
										{
											correctYear = scanner.nextInt();
											if (adminService.isValidYear(String.valueOf(correctYear))) 
											{
												flag1 = 1;
											} 
											else 
											{
												System.out.println("year must be in yyyy format");
												System.out.println("Enter year in yyyy format");
											}
										}
										flag1 = 0;
										System.out.println("Enter month");
										while (flag1 != 1) 
										{
											correctMonth = scanner.nextInt();
											if (adminService.isValidMonth(correctMonth)) 
											{
												flag1 = 1;
											} 
											else 
											{
												System.out.println("Month can't be greater than  12 or less than 1");
												System.out.println("Enter month again");
											}
										}
										flag1 = 0;
										System.out.println("Enter date");
										while (flag1 != 1)
										{
											correctDayOfMonth = scanner.nextInt();
											if (adminService.isValidDay(correctDayOfMonth, correctMonth, correctYear)) 
											{
												flag1 = 1;
											} 
											else 
											{
												System.out.println("In proper day");
												System.out.println("Enter day again");
											}
										}
										flag1 = 0;
										String newDate=correctYear+"-"+correctMonth+"-"+correctDayOfMonth;
										newDOB = Date.valueOf(newDate);
										if (adminService.isValidDate(newDOB))
											flag = 1;
										else 
										{
											System.out.println("Date of birth cannot be after the present date");
											System.out.println("Emter Date of birth again");
										}
									}
									flag = 0;
									bool = adminService.modifyEmployeeDOB(empToBeModifiedId, newDOB);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 5:
									System.out.println("Enter the new Contact Number");
									Long newContactNumber = 0L;
									while (flag != 1) 
									{
										newContactNumber = scanner.nextLong();
										if (adminService.isValidPhone(String.valueOf(newContactNumber)))
											flag = 1;
										else 
										{
											System.out.println("Contact number must have 10 digits and does not start with 0");
											System.out.println("Enter Contact number Again");
										}
									}
									flag = 0;
									bool = adminService.modifyEmployeeContactNumber(empToBeModifiedId, newContactNumber);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 6:
									System.out.println("Enter the new Manager's Id");
									int newManagerId=0 ;
									int managerFlag=0;
									while(managerFlag !=1 )
									{
										newManagerId= scanner.nextInt();
										if(adminService.isValidManagerId(newManagerId))
										{
											managerFlag=1;
										}
										else
										{
											System.out.println("Entered ManagerId is not valid");
											System.out.println("Enter Manager Id again");
										}
									}
									bool = adminService.modifyEmployeeManagerId(empToBeModifiedId, newManagerId);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 7:
									System.out.println("Enter new Employee martial status (s) for single and (m) for married");
									String newMartialStatus="a";
									int martialStatusFlag=0;
									while(martialStatusFlag!=1)
									{
										newMartialStatus=scanner.next();
										if(adminService.isValidMartialStatus(newMartialStatus))
										{
											martialStatusFlag=1;
										}
										else
										{
											System.out.println("Invalid martial status");
											System.out.println("Enter correct status again");
										}
									}
									bool=adminService.modifyEmployeeMartialStatus(empToBeModifiedId, newMartialStatus);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
								case 8:
									System.out.println("Enter new address");
									String newAddress=scanner.next();
									bool=adminService.modifyEmployeeAddress(empToBeModifiedId, newAddress);
									if(bool)
									{
										System.out.println("Sucessfully modified");
									}
									else
									{
										System.out.println("Employee Id Not Found");
									}
									break;
							}
							break;
						case "4":
							Employee searchedEmp;
							String empSearchId = null;
							System.out.println("Enter employee id to be searched");
							empSearchId = scanner.next();
							while (empSearchId.length() > 10) 
							{
								System.out.println("Employee Id must not be more than 10 characters\nEnter again");
								empSearchId = scanner.next();
							}
							searchedEmp = adminService.searchEmployeeById(empSearchId);
							while (searchedEmp != null && searchedEmp.getEmpId() == 0) 
							{
								System.out.println("Employee Id must be a numeric value");
								System.out.println("Enter employee id to be searched again");
								empSearchId = scanner.next();
								searchedEmp = adminService.searchEmployeeById(empSearchId);
							}
							if (searchedEmp != null) 
							{
								System.out.println("The employee details are: \n");
								System.out.printf("%-25s:%-20s\n", "Employee ID", searchedEmp.getEmpId());
								System.out.printf("%-25s:%-20s\n", "Name", searchedEmp.getEmpName());
								System.out.printf("%-25s:%-20s\n", "Salary", searchedEmp.getSalary());
								System.out.printf("%-25s:%-20s\n", "Department Id", searchedEmp.getDepartmentId());
								System.out.printf("%-25s:%-20s\n", "Date of Birth", searchedEmp.getDateOfBirth());
								System.out.printf("%-25s:%-20s\n", "Date of Joining", searchedEmp.getDateOfJoining());
								System.out.printf("%-25s:%-20s\n", "Grade", searchedEmp.getGrade());
								System.out.printf("%-25s:%-20s\n", "Designation", searchedEmp.getEmpDesignation());
								System.out.printf("%-25s:%-20s\n", "Martial Status", searchedEmp.getEmpMartialStatus());
								System.out.printf("%-25s:%-20s\n", "Address", searchedEmp.getEmpAddress());
								System.out.printf("%-25s:%-20s\n", "Contact Number", searchedEmp.getContactNumber());
								System.out.printf("%-25s:%-20s\n", "Manager Id", searchedEmp.getManagerId());
								System.out.printf("%-25s:%-20s\n", "Number of leaves left", searchedEmp.getNoOfLeaves());
								System.out.println();
							} 
							else 
							{
								System.out.println("Employee with id " + empSearchId + " not found \n");
							}
							break;
						case "5":
							System.out.println("Enter Employee name for searching");
							String empSearchByName = scanner.next();
							List<Employee> employeeList = adminService.searchEmployessByName(empSearchByName);
							if(employeeList.size()>0)
							{
								for (Employee resultEmp : employeeList) 
								{
									System.out.println(resultEmp);
								}
							}
							else
							{
								System.out.println("Employees with name " + empSearchByName + " not found \n");
							}
							
							break;
						case "6":
							List<Employee> empTotalList = adminService.displayEmployees();
							for (Employee totalEmp : empTotalList) 
							{
								System.out.println(totalEmp);
							}
							break;
						case "7":
							System.out.println("Enter old password");
							String oldPassword = scanner.next();
							boolean checkOldPassword = adminService.checkOldPassword(oldPassword, userName);
							if (checkOldPassword) 
							{
								System.out.println("Enter new password");
								flag = 0;
								String newPassword = null;
								while (flag != 1) 
								{
									newPassword = scanner.next();
									if (adminService.validatePassword(newPassword)) 
									{
										flag = 1;
									}
									else 
									{
										System.out.println(
												"Be between 6 and 12 characters " + "long Contain at least one digit."
														+ "Contain at least one lower case character."
														+ "Contain at least one upper case character."
														+ "Contain at least on special character from [ @ # $ % ! . ].");
										System.out.println("Enter New Password again");
									}
								}
								flag = 0;
								boolean pwdChangeStatus = adminService.changeAccountPassword(newPassword, userName);
								if (pwdChangeStatus)
								{
									System.out.println("changed successfully\n");
								} 
								else 
								{
									System.out.println("Enter correct old password");
								}
							} 
							else 
							{
								System.out.println("Enter correct old password");
							}
							break;
						case "8":
							operation = false;
							break;
						default:
							System.out.println("Exit");
						}
					}
				}
				else if (valid && loginChoice == 2)
				{
					boolean operation = true;
					while (operation)
					{
						System.out.println("Manager\n" + "\t1.Search By employee Id\n" + "\t2.Search employee by name\n"
								+ "\t3.Display own details\n" + "\t4.Display all subordinates\n"
								+ "\t5.Show leaves applied by employees\n" + "\t6.Accept leave\n" + "\t7.Reject leave\n"
								+ "\t8.To change Account Password\n" + "\t9. To exit\n");
						choice = scanner.next();
						ManagerService managerService = new ManagerServiceImpl();
						switch (choice) 
						{
							case "1":
								Employee searchedEmp;
								String empSearchId;
								System.out.println("Enter employee id to be searched");
								empSearchId = scanner.next();
								while (empSearchId.length() > 10) 
								{
									System.out.println("Employee Id must not be more than 10 characters\nEnter again");
									empSearchId = scanner.next();
								}
								searchedEmp = managerService.searchEmployeeById(empSearchId);
								while (searchedEmp != null && searchedEmp.getEmpId() == 0) 
								{
									System.out.println("Employee Id must be a numeric value");
									System.out.println("Enter employee id to be searched again");
									empSearchId = scanner.next();
									searchedEmp = managerService.searchEmployeeById(empSearchId);
								}
								if (searchedEmp != null)
								{
									System.out.println("The employee details are: \n");
									System.out.printf("%-25s:%-20s\n", "Employee ID", searchedEmp.getEmpId());
									System.out.printf("%-25s:%-20s\n", "Name", searchedEmp.getEmpName());
									System.out.printf("%-25s:%-20s\n", "Salary", searchedEmp.getSalary());
									System.out.printf("%-25s:%-20s\n", "Department Id", searchedEmp.getDepartmentId());
									System.out.printf("%-25s:%-20s\n", "Date of Birth", searchedEmp.getDateOfBirth());
									System.out.printf("%-25s:%-20s\n", "Date of Joining", searchedEmp.getDateOfJoining());
									System.out.printf("%-25s:%-20s\n", "Grade", searchedEmp.getGrade());
									System.out.printf("%-25s:%-20s\n", "Designation", searchedEmp.getEmpDesignation());
									System.out.printf("%-25s:%-20s\n", "Martial Status", searchedEmp.getEmpMartialStatus());
									System.out.printf("%-25s:%-20s\n", "Address", searchedEmp.getEmpAddress());
									System.out.printf("%-25s:%-20s\n", "Date of Birth", searchedEmp.getDateOfBirth());
									System.out.printf("%-25s:%-20s\n", "Contact Number", searchedEmp.getContactNumber());
									System.out.printf("%-25s:%-20s\n", "Manager Id", searchedEmp.getManagerId());
									System.out.printf("%-25s:%-20s\n", "Number of leaves left", searchedEmp.getNoOfLeaves());
									System.out.println();
								} 
								else 
								{
									System.out.println("Employee with id " + empSearchId + " not found \n");
								}
								break;
							case "2":
								System.out.println("Enter Employee name to be searched");
								String empName = scanner.next();
								List<Employee> empTotalList = managerService.searchEmployeeByName(empName);
								if (empTotalList.size() > 0)
								{
									for (Employee emp : empTotalList) 
									{
										System.out.printf("%-25s:%-20s\n", "Employee ID", emp.getEmpId());
										System.out.printf("%-25s:%-20s\n", "Name", emp.getEmpName());
										System.out.printf("%-25s:%-20s\n", "Salary", emp.getSalary());
										System.out.printf("%-25s:%-20s\n", "Department Id", emp.getDepartmentId());
										System.out.printf("%-25s:%-20s\n", "Date of Birth", emp.getDateOfBirth());
										System.out.printf("%-25s:%-20s\n", "Date of Joining", emp.getDateOfJoining());
										System.out.printf("%-25s:%-20s\n", "Grade", emp.getGrade());
										System.out.printf("%-25s:%-20s\n", "Designation", emp.getEmpDesignation());
										System.out.printf("%-25s:%-20s\n", "Martial Status", emp.getEmpMartialStatus());
										System.out.printf("%-25s:%-20s\n", "Address", emp.getEmpAddress());
										System.out.printf("%-25s:%-20s\n", "Date of Birth", emp.getDateOfBirth());
										System.out.printf("%-25s:%-20s\n", "Contact Number", emp.getContactNumber());
										System.out.printf("%-25s:%-20s\n", "Manager Id", emp.getManagerId());
										System.out.printf("%-25s:%-20s\n", "Number of leaves left", emp.getNoOfLeaves());
										System.out.println();
										//break;
									}
								} 
								else 
								{
									System.out.println("Employee with name" + empName + " not found \n");
								}
								break;

							case "3":
								Employee empOwnDetails = managerService.displayOwnDetials(userName);

								System.out.printf("%-25s:%-20s\n", "Employee ID", empOwnDetails.getEmpId());
								System.out.printf("%-25s:%-20s\n", "Name", empOwnDetails.getEmpName());
								System.out.printf("%-25s:%-20s\n", "Salary", empOwnDetails.getSalary());
								System.out.printf("%-25s:%-20s\n", "Department Id", empOwnDetails.getDepartmentId());
								System.out.printf("%-25s:%-20s\n", "Date of Birth", empOwnDetails.getDateOfBirth());
								System.out.printf("%-25s:%-20s\n", "Date of Joining", empOwnDetails.getDateOfJoining());
								System.out.printf("%-25s:%-20s\n", "Grade", empOwnDetails.getGrade());
								System.out.printf("%-25s:%-20s\n", "Designation", empOwnDetails.getEmpDesignation());
								System.out.printf("%-25s:%-20s\n", "Martial Status", empOwnDetails.getEmpMartialStatus());
								System.out.printf("%-25s:%-20s\n", "Address", empOwnDetails.getEmpAddress());
								System.out.printf("%-25s:%-20s\n", "Date of Birth", empOwnDetails.getDateOfBirth());
								System.out.printf("%-25s:%-20s\n", "Contact Number", empOwnDetails.getContactNumber());
								System.out.printf("%-25s:%-20s\n", "Manager Id", empOwnDetails.getManagerId());
								System.out.printf("%-25s:%-20s\n", "Number of leaves left", empOwnDetails.getNoOfLeaves());
								System.out.println();
								break;
							case "4":
								List<Employee> subEmpList = managerService.displaySubEmployees(userName);
								if (subEmpList.size() > 0) 
								{
									for (Employee subordinate : subEmpList)
									{
										System.out.println("\tEmployee Id : " + subordinate.getEmpId() + "\n\tName : "
												+ subordinate.getEmpName() + "\n\tSalary : " + subordinate.getSalary()
												+ "\n\tDepartment Id : " + subordinate.getDepartmentId()
												+ "\n\tDate of Birth : " + subordinate.getDateOfBirth()
												+ "\n\tContact Number : " + subordinate.getContactNumber() + "\n\tManager Id : "
												+ subordinate.getManagerId() + "\n\tNumber of leaves left : "
												+ subordinate.getNoOfLeaves());
										System.out.println("\n\n");
									}
								} 
								else 
								{
									System.out.println("There are no employees under You \n");
								}
								break;
							case "5":
								List<Leave> leaveList = managerService.showLeavesApplied(userName);
								if (leaveList.size() > 0) 
								{
									for (Leave leave : leaveList) 
									{
										System.out.printf("%-25s:%-25s\n", "Leave Id", leave.getLeaveId());
										System.out.printf("%-25s:%-25s\n", "Employee Id", leave.getEmpId());
										System.out.printf("%-25s:%-25s\n", "Manager Id", leave.getManagerId());
										System.out.printf("%-25s:%-25s\n", "From Date", leave.getFromDate());
										System.out.printf("%-25s:%-25s\n", "To Date", leave.getToDate());
										System.out.printf("%-25s:%-25s\n", "Appled Date", leave.getAppliedDate());
										System.out.printf("%-25s:%-25s\n", "Reason for leave", leave.getReason());
										if (leave.getLeaveStatus().equals("not approved"))
										{
											System.out.printf("%-25s:%-25s\n", "Leave Status", "Pending for approval\n");
										}
									}
								} 
								else 
								{
									System.out.println("There are no leaves to be approved\n");
								}
								break;

							case "6":
								System.out.println("Enter leave id to be accepted");
								int leaveId = scanner.nextInt();
								boolean leaveAcceptStatus = managerService.accept(leaveId,userName);
								if (leaveAcceptStatus)
								{
									System.out.println("Leave accepted sucessfully\n");
								}
								else
								{
									System.out.println("An error has occured while accepting leave");
								}
								break;

							case "7":

								System.out.println("Enter leave id for rejection");
								int leaveId2 = scanner.nextInt();
								System.out.println("Enter reason for rejection");
								String reason = scanner.next();
								boolean rejectStatus = managerService.reject(leaveId2, reason,userName);
								if (rejectStatus)
								{
									System.out.println("Sucessfully rejected\n");
								}
								else
								{
									System.out.println("An error has occured while rejecting an leave");
								}
								break;
							case "8":
								System.out.println("Enter old password");
								String oldPassword = scanner.next();
								System.out.println("Enter new password");
								String newPassword = null;
								flag = 0;
								while (flag != 1) {
									newPassword = scanner.next();
									if (managerService.validatePassword(newPassword))
									{
										flag = 1;
									} 
									else 
									{
										System.out.println(
												"Be between 6 and 12 characters " + "long Contain at least one digit."
														+ "Contain at least one lower case character."
														+ "Contain at least one upper case character."
														+ "Contain at least on special character from [ @ # $ % ! . ].");
										System.out.println("Enter New Password again");
									}

								}
								boolean pwdChangesStatus=managerService.changeAccountPassword(userName, oldPassword, newPassword);
								if(pwdChangesStatus)
								{
									System.out.println("Sucessfully changed");
								}
								else
								{
									System.out.println("Wrong password");
								}
								break;

							case "9":
								operation = false;
								break;
							default:
								System.out.println("Enter valid choice\n");
						}
					}

				} 
				else if (valid && loginChoice == 3)
				{
					boolean operation = true;
					while (operation)
					{
						System.out.println("Employee\n" + "\t1.Search Employee By Id\n" + "\t2.Search Employee By Name\n"
								+ "\t3.Display their own details\n" + "\t4.change account password\n"
								+ "\t5.apply for leave\n" + "\t6.Edit leave\n" + "\t7.search any leave\n"
								+ "\t8.cancel any leave\n" + "\t9.to logout");
						int leaveId = 0;
						String employeeChoice = scanner.next();
						EmployeeService employeeService = new EmployeeServiceImpl();
						switch (employeeChoice) 
						{
							case "1":
								Employee searchedEmp;
								String empSearchId = null;
								System.out.println("Enter employee id to be searched");
								empSearchId = scanner.next();
								while (empSearchId.length() > 10)
								{
									System.out.println("Employee Id must not be more than 10 characters\nEnter again");
									empSearchId = scanner.next();
								}
								searchedEmp = employeeService.searchEmployeeById(empSearchId);
								while (searchedEmp != null && searchedEmp.getEmpId() == 0)
								{
									System.out.println("Employee Id must be a numeric value");
									System.out.println("Enter employee id to be searched again");
									empSearchId = scanner.next();
									searchedEmp = employeeService.searchEmployeeById(empSearchId);
								}
								if (searchedEmp != null) 
								{
									System.out.println("The employee details are: \n");
									System.out.printf("%-25s:%-20s\n", "Employee ID", searchedEmp.getEmpId());
									System.out.printf("%-25s:%-20s\n", "Name", searchedEmp.getEmpName());
									System.out.printf("%-25s:%-20s\n", "Salary", searchedEmp.getSalary());
									System.out.printf("%-25s:%-20s\n", "Department Id", searchedEmp.getDepartmentId());
									System.out.printf("%-25s:%-20s\n", "Date of Birth", searchedEmp.getDateOfBirth());
									System.out.printf("%-25s:%-20s\n", "Date of Joining", searchedEmp.getDateOfJoining());
									System.out.printf("%-25s:%-20s\n", "Grade", searchedEmp.getGrade());
									System.out.printf("%-25s:%-20s\n", "Designation", searchedEmp.getEmpDesignation());
									System.out.printf("%-25s:%-20s\n", "Martial Status", searchedEmp.getEmpMartialStatus());
									System.out.printf("%-25s:%-20s\n", "Address", searchedEmp.getEmpAddress());
									System.out.printf("%-25s:%-20s\n", "Date of Birth", searchedEmp.getDateOfBirth());
									System.out.printf("%-25s:%-20s\n", "Contact Number", searchedEmp.getContactNumber());
									System.out.printf("%-25s:%-20s\n", "Manager Id", searchedEmp.getManagerId());
									System.out.printf("%-25s:%-20s\n", "Number of leaves left", searchedEmp.getNoOfLeaves());
									System.out.println();
								}
								else 
								{
									System.out.println("Employee with id " + empSearchId + " not found \n");
								}
								break;
							case "2":
								System.out.println("Enter Employee name to be searched");
								String empName = scanner.next();
								List<Employee> empTotalList = employeeService.searchEmployeeByName(empName);
								if(empTotalList.size()>0)
								{
									for (Employee result : empTotalList) 
									{
										System.out.println(result);
									}
								}
								else
								{
									System.out.println("Employees with name " + empName + " not found \n");
								}
								
								break;
							case "3":
								Employee empOwnDetails = employeeService.displayEmpDetails(userName);
								System.out.println(empOwnDetails);
								break;
							case "4":
								System.out.println("Enter old password");
								String oldPassword = scanner.next();
								System.out.println("Enter new password");
								String newPassword = null;
								flag = 0;
								while (flag != 1) {
									newPassword = scanner.next();
									if (employeeService.validatePassword(newPassword))
									{
										flag = 1;
									} 
									else 
									{
										System.out.println(
												"Be between 6 and 12 characters " + "long Contain at least one digit."
														+ "Contain at least one lower case character."
														+ "Contain at least one upper case character."
														+ "Contain at least on special character from [ @ # $ % ! . ].");
										System.out.println("Enter New Password again");
									}

								}
								boolean pwdChangesStatus=employeeService.changeAccountPassword(userName, oldPassword, newPassword);
								if(pwdChangesStatus)
								{
									System.out.println("Sucessfully changed");
								}
								else
								{
									System.out.println("Wrong password");
								}
								break;

							case "5":
								System.out.println("Enter from date in the format yyyy mm dd");
								Date fDate = null;
								Date tDate = null;
								Date today = null;
								LocalDate localFrom=null;
								LocalDate localTo=null;
								int fromYear = 0;
								int fromMonth = 0;
								int fromDate = 0;
								int toYear = 0;
								int toMonth = 0;
								int toDate = 0;
								flag = 0;
								flag1 = 0;
								while (flag != 1) 
								{
									System.out.println("Enter year");
									while (flag1 != 1)
									{
										fromYear = scanner.nextInt();
										if (employeeService.isValidYear(String.valueOf(fromYear))) 
										{
											flag1 = 1;
										}
										else 
										{
											System.out.println("year must be in yyyy format");
											System.out.println("Enter year in yyyy format");
										}

									}
									flag1 = 0;
									System.out.println("Enter month");

									while (flag1 != 1)
									{
										fromMonth = scanner.nextInt();
										if (employeeService.isValidMonth(fromMonth))
										{
											flag1 = 1;
										} 
										else
										{
											System.out.println("Month can't be greater than  12 or less than 1");
											System.out.println("Enter month again");
										}

									}
									flag1 = 0;

									System.out.println("Enter date");
									while (flag1 != 1)
									{
										fromDate = scanner.nextInt();
										if (employeeService.isValidDay(fromDate, fromMonth, fromYear))
										{
											flag1 = 1;
										}
										else 
										{
											System.out.println("In proper day");
											System.out.println("Enter day again");
										}

									}
									String leaveFromDate=fromYear+"-"+fromMonth+"-"+fromDate;

									fDate = Date.valueOf(leaveFromDate);
									localFrom=LocalDate.of(fromYear, fromMonth, fromDate);
									if (employeeService.validateFromDate(fDate)) 
									{
										flag = 1;
									} 
									else 
									{
										System.out
											.println("From date cannont be before present date or cannot be after 45 days");
											System.out.println("Enter From date again in the format yyyy mm dd");
									}
								}
								flag = 0;
								flag1 = 0;
								System.out.println("Enter to date in format yyyy mm dd");
								while (flag != 1)
								{
									System.out.println("Enter year");
									while (flag1 != 1) 
									{
										toYear = scanner.nextInt();
										if (employeeService.isValidYear(String.valueOf(toYear))) 
										{
											flag1 = 1;
										} 
										else 
										{
											System.out.println("year must be in yyyy format");
											System.out.println("Enter year in yyyy format");
										}

									}
									flag1 = 0;
									System.out.println("Enter month");

									while (flag1 != 1) 
									{
										toMonth = scanner.nextInt();
										if (employeeService.isValidMonth(toMonth)) 
										{
											flag1 = 1;
										} else {
											System.out.println("Month can't be greater than  12 or less than 1");
											System.out.println("Enter month again");
										}

									}
									flag1 = 0;

									System.out.println("Enter date");
									while (flag1 != 1) {
										toDate = scanner.nextInt();
										if (employeeService.isValidDay(toDate, toMonth, toYear))
										{
											flag1 = 1;
										} 
										else 
										{
											System.out.println("In proper day");
											System.out.println("Enter day again");
										}

									}
									String leaveToDate=toYear+"-"+toMonth+"-"+toDate;
									tDate = Date.valueOf(leaveToDate);
									localTo=LocalDate.of(toYear, toMonth, toDate);
									today = Date.valueOf(LocalDate.now());
									if (employeeService.validateTODate(fDate, tDate))
									{
										flag = 1;
									}
									else 
									{
										System.out.println(
												"To date can't be before From date and To date can't be after 10 from from date");
											System.out.println("Enter to date in format yyyy mm dd");
									}
								}

								System.out.println("Enter reason for leave");
								String reason = scanner.next();
								Leave leave = new Leave();
								leave.setAppliedDate(today);
								leave.setEmpId(employeeService.getEmpIdFromLoginTable(userName));
								leave.setFromDate(fDate);
								leave.setLeavesRemaining(employeeService.getLeaveBalance(userName));
								leave.setLeaveStatus("not approved");
								leave.setManagerId(employeeService.getManagerIdForEmp(userName));
								leave.setNoOfDatesApplied((int) ChronoUnit.DAYS.between(localFrom, localTo));
								leave.setReason(reason);
								leave.setToDate(tDate);
								boolean leaveStatus = employeeService.addLeave(leave);
								if (leaveStatus) 
								{
									System.out.println("Sucessfully");
								}
								else
								{
									System.out.println("Leave can't be accepted");
								}
								break;
							case "6":

								System.out.println("Enter leave id to modify leave");
								
								int leaveFlag=0;
								while(leaveFlag!=1)
								{
									leaveId = scanner.nextInt();
									if(employeeService.validLeaveId(leaveId, userName))
									{
										leaveFlag=1;
									}
									else
									{
										System.out.println("The leave id you mentioned is not yours");
										System.out.println("reenter the leave id belongs to you");
									}
								}
								System.out.println("\nEnter 1: to update leave from date\n" + "Enter 2: to update to date\n"
										+ "Enter 3: to update leave reason\n");
								int modifyChoice=scanner.nextInt();
								switch(modifyChoice)
								{
									case 1:
										int fromYear1 = 0;
										int fromMonth1 = 0;
										int fromDate1 = 0;
										Date fDate1 = null;
										flag=0;
										flag1=0;
										System.out.println("Enter from date in the format yyyy mm dd");
										while (flag != 1)
										{
											System.out.println("Enter year");
											while (flag1 != 1)
											{
												fromYear1 = scanner.nextInt();
												if (employeeService.isValidYear(String.valueOf(fromYear1))) 
												{
													flag1 = 1;
												} 
												else 
												{
													System.out.println("year must be in yyyy format");
													System.out.println("Enter year in yyyy format");
												}

											}
											flag1 = 0;
											System.out.println("Enter month");

											while (flag1 != 1) 
											{
												fromMonth1 = scanner.nextInt();
												if (employeeService.isValidMonth(fromMonth1))
												{
													flag1 = 1;
												} 
												else 
												{
													System.out.println("Month can't be greater than  12 or less than 1");
													System.out.println("Enter month again");
												}

											}
											flag1 = 0;

											System.out.println("Enter date");
											while (flag1 != 1) 
											{
												fromDate1 = scanner.nextInt();
												if (employeeService.isValidDay(fromDate1, fromMonth1, fromYear1))
												{
													flag1 = 1;
												} 
												else
												{
													System.out.println("In proper day");
													System.out.println("Enter day again");
												}

											}
											String editFromDate=fromYear1+"-"+fromMonth1+"-"+fromDate1;
											fDate1 = Date.valueOf(editFromDate);
											if (employeeService.validateFromDate(fDate1) && employeeService.validateTODate(fDate1, employeeService.getToDate(leaveId)))
											{
												flag = 1;
											} 
											else 
											{
												System.out
													.println("From date cannont be before present date or cannot be after to date");
													System.out.println("Enter From date again in the format yyyy mm dd");
													flag1=0;
													flag=0;
											}
										}
										Leave modifiedFromDateLeave=employeeService.editLeaveFromDate(leaveId, fDate1);
										System.out.println("Leave is:"+modifiedFromDateLeave);
										break;
									case 2:
										int toYear1 = 0;
										int toMonth1 = 0;
										int toDate1 = 0;
										Date tDate1=null;
										flag = 0;
										flag1 = 0;
										System.out.println("Enter to date in format yyyy mm dd");
										while (flag != 1)
										{
											System.out.println("Enter year");
											while (flag1 != 1) 
											{
												toYear1 = scanner.nextInt();
												if (employeeService.isValidYear(String.valueOf(toYear1)))
												{
													flag1 = 1;
												} 
												else 
												{
													System.out.println("year must be in yyyy format");
													System.out.println("Enter year in yyyy format");
												}

											}
											flag1 = 0;
											System.out.println("Enter month");

											while (flag1 != 1) 
											{
												toMonth1 = scanner.nextInt();
												if (employeeService.isValidMonth(toMonth1))
												{
													flag1 = 1;
												} 
												else 
												{
													System.out.println("Month can't be greater than  12 or less than 1");
													System.out.println("Enter month again");
												}

											}
											flag1 = 0;

											System.out.println("Enter date");
											while (flag1 != 1) 
											{
												toDate1 = scanner.nextInt();
												if (employeeService.isValidDay(toDate1, toMonth1, toYear1)) 
												{
													flag1 = 1;
												} 
												else 
												{
													System.out.println("In proper day");
													System.out.println("Enter day again");
												}

											}
											String leaveToDate=toYear1+"-"+toMonth1+"-"+toDate1;

											tDate1 = Date.valueOf(leaveToDate);
											System.out.println("To date:"+employeeService.validateTODate(employeeService.getFromDate(leaveId), tDate1));
											if (employeeService.validateTODate(employeeService.getFromDate(leaveId), tDate1)) 
											{
												flag = 1;
											} 
											else 
											{
												System.out.println(
														"To date can't be before From date and To date can't be after 10 from from date");
												System.out.println("Enter to date in format yyyy mm dd");
												flag1=0;
												flag=0;
											}
										}
										Leave modifiedToDateLeave=employeeService.editLeaveToDate(leaveId, tDate1);
										System.out.println("Leave is:"+modifiedToDateLeave);
										break;
									case 3:
										System.out.println("Enter new Reason");
										String newReason=scanner.next();
										Leave modifiedReasonLeave=employeeService.editLeaveReason(leaveId, newReason);
										System.out.println("Leave is:"+modifiedReasonLeave);
										break; 
								}
								break;

							case "7":
								System.out.println("Enter the leave Id to see leave details");
								int leaveFlag1=0;
								while(leaveFlag1!=1)
								{
									leaveId = scanner.nextInt();
									if(employeeService.validLeaveId(leaveId, userName))
									{
										leaveFlag1=1;
									}
									else
									{
										System.out.println("The leave id you mentioned is not yours");
										System.out.println("reenter the leave id belongs to you");
									}
								}
								Leave leavedetails = employeeService.SearchLeave(leaveId);
								System.out.println(leavedetails);
								break;

							case "8":
								System.out.println("Enter the leave Id to cancell the leave");
								int leaveFlag2=0;
								while(leaveFlag2!=1)
								{
									leaveId = scanner.nextInt();
									if(employeeService.validLeaveId(leaveId, userName))
									{
										leaveFlag2=1;
									}
									else
									{
										System.out.println("The leave id you mentioned is not yours");
										System.out.println("reenter the leave id belongs to you");
									}
								}
								boolean cancellApprovalStatus = employeeService.cancelLeave(leaveId);
								if (cancellApprovalStatus)
								{
									System.out.println("Leave is cancelled successfully");
								}
								break;
							case "9":
								operation = false;
								break;
							default:
								System.out.println("Enter Valid Choice");
						}
					}

				} 
				else
				{
					System.out.println("Invalid login credentials");
				}

		}

	}

}
