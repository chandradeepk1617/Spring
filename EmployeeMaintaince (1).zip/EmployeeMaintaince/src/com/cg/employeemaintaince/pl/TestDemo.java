package com.cg.employeemaintaince.pl;

import java.sql.Date;
import java.util.Scanner;

import com.cg.employeemaintaince.dao.AdminDaoImpl;
import com.cg.employeemaintaince.dao.EmployeeDaoImpl;
import com.cg.employeemaintaince.dao.LoginDaoImpl;
import com.cg.employeemaintaince.dao.ManagerDaoImpl;
import com.cg.employeemaintaince.dto.Employee;

public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in); 
		AdminDaoImpl ad=new AdminDaoImpl();
		  LoginDaoImpl l=new LoginDaoImpl(); 
		  EmployeeDaoImpl empDao=new EmployeeDaoImpl();
		   ManagerDaoImpl mng=new ManagerDaoImpl();
		System.out.println("Enter employee name"); 
		String name=sc.next();
		 System.out.println("Enter Salary"); 
		 float sal=sc.nextFloat();
		  System.out.println("Enter Contact number"); 
		  long number=sc.nextLong();
		  System.out.println("Enter ManagerId");
		  int mgr=sc.nextInt();
		  System.out.println("Enter department id"); 
		  int dept=sc.nextInt();
		  System.out.println("Enter DOB in format yyyy-mm-dd"); 
		  String d=sc.next();
		  Date dat=Date.valueOf(d); System.out.println("Enter DOJ"); 
		  String j=sc.next(); 
		  Date dat1=Date.valueOf(j);
		  System.out.println("Enter martials status as single(s)/married(m)");
		  String martial=sc.next(); 
		  System.out.println("Enter address"); String
		  address=sc.next(); 
		  System.out.println("Enter designation"); 
		  String des=sc.next();
		  System.out.println("Enter grade id"); 
		  String grade=sc.next();
		  Employee emp=new Employee(); 
		  emp.setEmpName(name); 
		  emp.setSalary(sal);
		  emp.setContactNumber(number);
		  emp.setDateOfBirth(dat);
		  emp.setDepartmentId(dept);
		  emp.setManagerId(mgr); 
		  emp.setNoOfLeaves(22);
		  emp.setDateOfJoining(dat1);
		  emp.setEmpMartialStatus(martial);
		  emp.setEmpAddress(address); 
		  emp.setEmpDesignation(des); 
		  emp.setGrade(grade);
		  ad.addEmployee(emp); System.out.println("Employee is inserted");
	}

}
