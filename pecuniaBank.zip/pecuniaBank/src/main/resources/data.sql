insert into Account(account_no,aadhar,amount,ifsc,status,account_type,branch_id) values (1000000001,627506807573,0,'PECB0000123','open','savings',100001);
insert into Account(account_no,aadhar,amount,ifsc,status,account_type,branch_id) values (1000000002,627506807574,0,'PECB0000123','open','savings',100001);
insert into Account(account_no,aadhar,amount,ifsc,status,account_type,branch_id) values (1000000003,627506807575,0,'PECB0000123','open','savings',100001);
insert into Account(account_no,aadhar,amount,ifsc,status,account_type,branch_id) values (1000000004,627506807576,0,'PECB0000123','open','savings',100001);
insert into Account(account_no,aadhar,amount,ifsc,status,account_type,branch_id) values (1000000005,627506807577,0,'PECB0000123','open','savings',100001);

insert into Customer(aadhar,name,contact,pan,address,state,city,country,zip_code,gender) values (627506807573,'Chandu',9963673280,'EHLPK5472G','Narapally','Telangana','Hyderabad','India',501301,'Male');

insert into Customer(aadhar,name,contact,pan,address,state,city,country,zip_code,gender) values (627506807574,'Harish',8073841028,'EHLPK5473G','Narapally','Telangana','Hyderabad','India',501301,'Male');

insert into Customer(aadhar,name,contact,pan,address,state,city,country,zip_code,gender) values (627506807575,'Ravinderreddy',7359921040,'EHLPK5475G','Narapally','Telangana','Hyderabad','India',501301,'Male');

insert into Customer(aadhar,name,contact,pan,address,state,city,country,zip_code,gender) values (627506807576,'Subhash',8110951952,'EHLPK5477G','Chakripuram','Telangana','Hyderabad','India',506301,'Male');

insert into Customer(aadhar,name,contact,pan,address,state,city,country,zip_code,gender) values (627506807577,'Surya',7286047013,'EHLPK5479G','Lbnagar','Telangana','Hyderabad','India',505301,'Male');
