package com.cg.employeemaintainencesystem.exception;

public class LeavesNotFoundException extends RuntimeException{
	public LeavesNotFoundException(String message)
	{
		super(message);
	}
	public LeavesNotFoundException(String message,Throwable t)
	{
		super(message,t);
	}
}

