package com.cg.employeemaintainencesystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemaintainencesystem.entity.Leave;
import com.cg.employeemaintainencesystem.service.LeaveService;
import com.netflix.hystrix.contrib.javanica.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api("Leave Service")
@RestController
@CrossOrigin("*")
public class LeaveController {
	@Autowired
	LeaveService leaveService;
	
	Logger logger=LoggerFactory.getLogger(LeaveController.class);

	//@HystrixCommand(fallbackMethod = "addLeaveNotWork",commandKey = "addLeave",groupKey = "Add"	)
	@ApiOperation(value = "Add a new Leave")
	@PostMapping(value = "/addLeave")
	public Leave addLeave(@ApiParam(value="Leave object in json format")@RequestBody Leave leave)
	{
		logger.info("adding New Leave to the Database");
		return leaveService.addLeave(leave);
	}
	
	
//	@HystrixCommand(fallbackMethod = "updateLeaveNotWork",commandKey = "updateLeave",groupKey = "Update")
	@ApiOperation(value = "Update the Leave")
	@PutMapping(value = "/updateLeave")
	public Leave updateLeave(@ApiParam(value="Leave object in json format")@RequestBody Leave leave)
	{
		logger.info("updating Leave");
		return leaveService.updateLeave(leave);
	}
	
	
	
//	@HystrixCommand(fallbackMethod = "findPendingLeavesAppliedByUsernameNotWork",commandKey = "findPendingLeavesAppliedByUsername",groupKey = "Search")
	@ApiOperation(value = "Get all Leaves Based on UserName that are pending")
	@GetMapping(value = "/pendingLeaves/{userName}")
	public List<Leave> findPendingLeavesAppliedByUsername(@ApiParam(value="userName")@PathVariable String userName)
	{
		logger.info("Getting all the pending leaves as per the userName");
		return leaveService.findPendingLeavesAppliedByUsername(userName);
	}
	
	

//	@HystrixCommand(fallbackMethod = "deleteLeaveByLeaveIdNotWork",commandKey = "deleteLeaveByLeaveId",groupKey = "Delete",)
	@ApiOperation(value = "Delete a leave ")
	@DeleteMapping(value = "/delete/{leaveId}")
	public Leave deleteLeaveByLeaveId(@ApiParam(value="LeaveId",example="1")@PathVariable int leaveId)
	{
		logger.info("Deleting leave with leaveId: "+leaveId);
		return leaveService.deleteLeaveByLeaveId(leaveId);
	}
	
	
	@HystrixCommand(fallbackMethod = "findAllLeavesOfSubordinatesNotWork",commandKey = "findAllLeavesOfSubordinates",groupKey = "Search")
	@ApiOperation(value = "Search all Subordinates leaves")
	@GetMapping(value = "/allSubordinatesLeaves/{managerId}")
	public List<Leave> findAllLeavesOfSubordinates(@ApiParam(value="managerId",example="1")@PathVariable int managerId)
	{
		logger.info("Finding all the leaves of the subordinates");
		return leaveService.findAllLeavesOfSubordinates(managerId);
	}
	
	public List<Leave> findAllLeavesOfSubordinatesNotWork(@PathVariable int managerId)
	{
		List<Leave> leavesList = new ArrayList<Leave>();
		return leavesList;
	}
	

	@ApiOperation(value = "Search a leave ")
	@GetMapping(value = "/getLeave/{leaveId}")
	public Leave getLeaveByLeaveId(@ApiParam(value="leaveId",example="1")@PathVariable int leaveId) 
	{
		logger.info("Getting leave with  leaveId : "+leaveId);
		return leaveService.getLeaveByLeaveId(leaveId);
	}
	
	
	
	@HystrixCommand(fallbackMethod = "acceptLeaveNotWork",commandKey = "acceptLeave",groupKey = "Update")
	@ApiOperation(value = "To accept Leave")
	@PutMapping(value = "/acceptLeave")
	public Leave acceptLeave(@ApiParam(value="Leave object in json format")@RequestBody Leave leave)
	{
		logger.info("Accepting Leave");
		return leaveService.acceptLeave(leave);
	}
	public Leave acceptLeaveNotWork(@RequestBody Leave leave)
	{
		Leave errorLeaveObj = new Leave(0);
		return errorLeaveObj;
	}

	@HystrixCommand(fallbackMethod = "rejectLeaveNotWork",commandKey = "rejectLeave",groupKey = "Update")
	@ApiOperation(value = "To Reject Leave")
	@PutMapping(value = "/rejectLeave")
	public Leave rejectLeave(@ApiParam(value="Leave object in json format")@RequestBody Leave leave) {
		logger.info("Rejecting Leave");
		return leaveService.rejectLeave(leave);
	}
	
	public Leave rejectLeaveNotWork(@RequestBody Leave leave)
	{
		Leave errorLeaveObj = new Leave(0);
		return errorLeaveObj;
	}
	
//	@HystrixCommand(fallbackMethod = "findAllLeavesNotWork",commandKey = "findAllLeaves",groupKey = "Update")
	@ApiOperation(value = "Find All Leaves")
	@GetMapping(value = "/allLeaves")
	public List<Leave> findAllLeaves()
	{
		logger.info("Finding all the Leaves");
		return leaveService.findAllLeaves();
	}
	
	//@HystrixCommand(fallbackMethod = "findLeavesByUserNameNotWork",commandKey = "findLeavesByUserName",groupKey = "Search")
	@ApiOperation(value = "Find Leaves By UserName")
	@GetMapping(value = "/leaves/name/{name}")
	public List<Leave> findAllLeaves(@ApiParam(value="userName")@PathVariable String name)
	{
		logger.info("Finding  the Leaves By UserNamr");
		return leaveService.findLeavesByUserName(name);
	}
	
	
	
}
