package com.cg.employeemaintainencesystem.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="leave")
public class Leave {
	@Id
private int leaveId;
private Date fromDate;
private Date toDate;
private String appliedDate;
private int empId;
private int managerId;
private String reason;
private String status;
@Override
public String toString() {
	return "LeaveDTO [leaveId=" + leaveId + ", fromDate=" + fromDate + ", toDate=" + toDate + ", appliedDate="
			+ appliedDate + ", empId=" + empId + ", managerId=" + managerId + ", reason=" + reason + ", status="
			+ status + "]";
}
public Leave(int leaveId, Date fromDate, Date toDate, String appliedDate, int empId, int managerId, String reason,
		String status) {
	super();
	this.leaveId = leaveId;
	this.fromDate = fromDate;
	this.toDate = toDate;
	this.appliedDate = appliedDate;
	this.empId = empId;
	this.managerId = managerId;
	this.reason = reason;
	this.status = status;
}
public Leave()
{
	
}
public Leave(int leaveId)
{
	this.leaveId=leaveId;
}
public int getLeaveId() {
	return leaveId;
}
public void setLeaveId(int leaveId) {
	this.leaveId = leaveId;
}
public Date getFromDate() {
	return fromDate;
}
public void setFromDate(Date fromDate) {
	this.fromDate = fromDate;
}
public Date getToDate() {
	return toDate;
}
public void setToDate(Date toDate) {
	this.toDate = toDate;
}
public String getAppliedDate() {
	return appliedDate;
}
public void setAppliedDate(String appliedDate) {
	this.appliedDate = appliedDate;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getManagerId() {
	return managerId;
}
public void setManagerId(int managerId) {
	this.managerId = managerId;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}


}

