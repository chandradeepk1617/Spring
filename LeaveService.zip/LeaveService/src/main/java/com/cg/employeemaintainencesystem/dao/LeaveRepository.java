package com.cg.employeemaintainencesystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employeemaintainencesystem.entity.Leave;

public interface LeaveRepository extends JpaRepository<Leave,Integer>{

	public List<Leave>findByEmpId(int empId);
	public List<Leave>findByManagerId(int managerId);
}
