package com.cg.employeemaintainencesystem.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.employeemaintainencesystem.exception.LeavesNotFoundException;

@ControllerAdvice
public class LeaveControllerAdvice {
	@ExceptionHandler(LeavesNotFoundException.class)
    public final ResponseEntity<String> exceptionHandler
                        ( LeavesNotFoundException e) 
    {
       
     System.out.println();
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }
}
