package com.cg.employeemaintainencesystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.employeemaintainencesystem.dao.LeaveRepository;
import com.cg.employeemaintainencesystem.entity.Leave;
import com.cg.employeemaintainencesystem.exception.LeavesNotFoundException;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	LeaveRepository leaveRepo;

	@Override

	public Leave addLeave(Leave leave) {
		System.out.println(leave);
		Leave addedLeave = leaveRepo.save(leave);
		return addedLeave;
	}

	@Override
	public Leave updateLeave(Leave leave) {
		Leave updatedLeave = leaveRepo.save(leave);
		return updatedLeave;
	}

	@Override
	public List<Leave> findPendingLeavesAppliedByUsername(String userName) throws LeavesNotFoundException {
		int empId = new RestTemplate().getForObject("http://localhost:8081/login/id/" + userName, Integer.class);
		List<Leave> leavesList = leaveRepo.findByEmpId(empId);
		List<Leave> pendingLeavesList = new ArrayList<Leave>();
		for (Leave leave : leavesList) {
			if (leave.getStatus().equals("pending")) {
				pendingLeavesList.add(leave);
			} else
				continue;
		}
		if (pendingLeavesList.size() > 0)
			return pendingLeavesList;
		else
			throw new LeavesNotFoundException(userName + " you have no pending leaves");
	}

	@Override
	public Leave deleteLeaveByLeaveId(int leaveId) {
		Leave leave = leaveRepo.findById(leaveId).orElse(null);
		leaveRepo.delete(leave);
		return leave;
	}

	@Override
	public List<Leave> findAllLeavesOfSubordinates(int managerId) {
		List<Leave> leavesList = leaveRepo.findByManagerId(managerId);
		return leavesList;
	}

	@Override
	public Leave getLeaveByLeaveId(int leaveId) {
		Leave leave = leaveRepo.findById(leaveId).orElse(null);
		return leave;
	}

	@Override
	public Leave acceptLeave(Leave leave) {
		Leave acceptedLeave = leaveRepo.save(leave);
		return acceptedLeave;
	}

	@Override
	public Leave rejectLeave(Leave leave) {
		Leave rejectedLeave = leaveRepo.save(leave);
		return rejectedLeave;
	}

	@Override
	public List<Leave> findAllLeaves() {
		List<Leave> leavesList = leaveRepo.findAll();
		return leavesList;
	}

	public List<Leave> findLeavesByUserName(String name) throws LeavesNotFoundException {
		int empId = new RestTemplate().getForObject("http://localhost:8081/login/id/" + name, Integer.class);
		System.out.println(empId);
		List<Leave> leaveList = leaveRepo.findByEmpId(empId);
		if (leaveList.size() > 0)
			return leaveList;
		else
			throw new LeavesNotFoundException(name + " you have no applied leaves");

	}

}
