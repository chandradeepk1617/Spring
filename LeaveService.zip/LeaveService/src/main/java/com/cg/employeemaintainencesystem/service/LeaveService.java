package com.cg.employeemaintainencesystem.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.employeemaintainencesystem.entity.Leave;
import com.cg.employeemaintainencesystem.exception.LeavesNotFoundException;

public interface LeaveService {


	public Leave addLeave(Leave leave);
	public Leave updateLeave(Leave leave);
	public List<Leave> findPendingLeavesAppliedByUsername(String userName) throws LeavesNotFoundException;
	public Leave deleteLeaveByLeaveId(int leaveId);
	public List<Leave> findAllLeavesOfSubordinates(int managerId);
	public Leave getLeaveByLeaveId(int leaveId); 
	public Leave acceptLeave(Leave leave);
	public Leave rejectLeave(Leave leave);
	public List<Leave> findAllLeaves();
	public List<Leave> findLeavesByUserName(String name) throws LeavesNotFoundException;
}
