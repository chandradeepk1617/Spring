package com.cg.employeemaintainencesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
