package com.cg.employeemaintaince.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="grademaster")
public class GradeMaster {
	
	@Id
	@Column(name="GRADECODE")
	private String gradeCode;
	@Column(name="MINSALARY")
	private double minimunSalary;
	@Column(name="MAXSALARY")
	private double maximumSalary;
	
	public String getGradeCode() {
		return gradeCode;
	}
	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
	public double getMinimunSalary() {
		return minimunSalary;
	}
	public void setMinimunSalary(double minimunSalary) {
		this.minimunSalary = minimunSalary;
	}
	public double getMaximumSalary() {
		return maximumSalary;
	}
	public void setMaximumSalary(double maximumSalary) {
		this.maximumSalary = maximumSalary;
	}
	
}
