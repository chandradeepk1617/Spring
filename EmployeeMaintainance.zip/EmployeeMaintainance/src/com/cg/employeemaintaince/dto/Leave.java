package com.cg.employeemaintaince.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="leave")
public class Leave {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LEAVE_SEQ")
    @SequenceGenerator(sequenceName = "leaveid_seq", allocationSize = 1, name = "LEAVE_SEQ")
	@Column(name="LEAVEID")
	private int leaveId;
	@Column(name="EMPID")
	private int empId;
	@Column(name="LEAVEBALANCE")
	private int leavesRemaining;
	@Column(name="NOOFDATESAPPLIED")
	private int noOfDatesApplied;
	@Column(name="FROMDATE")
	private Date fromDate;
	@Column(name="TODATE")
	private Date toDate;
	@Column(name="APPLIEDDATE")
	private Date appliedDate;
	@Column(name="STATUS")
	private String leaveStatus;
	@Column(name="MANAGERID")
	private int managerId;
	@Column(name="REASON")
	private String reason;
	
	public Leave()
	{
		
	}
	

	public Leave(int leaveId, int empId, int leavesRemaining, int noOfDatesApplied, Date fromDate, Date toDate,
			Date appliedDate, String leaveStatus, int managerId, String reason) {
		super();
		this.leaveId = leaveId;
		this.empId = empId;
		this.leavesRemaining = leavesRemaining;
		this.noOfDatesApplied = noOfDatesApplied;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.appliedDate = appliedDate;
		this.leaveStatus = leaveStatus;
		this.managerId = managerId;
		this.reason = reason;
	}


	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(Date appliedDate) {
		this.appliedDate = appliedDate;
	}
	

	public String getLeaveStatus() {
		return leaveStatus;
	}


	public void setLeaveStatus(String leaveStatus) {
		this.leaveStatus = leaveStatus;
	}


	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}


	public int getLeavesRemaining() {
		return leavesRemaining;
	}


	public void setLeavesRemaining(int leavesRemaining) {
		this.leavesRemaining = leavesRemaining;
	}


	public int getNoOfDatesApplied() {
		return noOfDatesApplied;
	}


	public void setNoOfDatesApplied(int noOfDatesApplied) {
		this.noOfDatesApplied = noOfDatesApplied;
	}


	@Override
	public String toString() {
		return "Leave [leaveId=" + leaveId + ", empId=" + empId + ", leavesRemaining=" + leavesRemaining
				+ ", noOfDatesApplied=" + noOfDatesApplied + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", appliedDate=" + appliedDate + ", leaveStatus=" + leaveStatus + ", managerId=" + managerId
				+ ", reason=" + reason + "]";
	}
	
	
	
	
	
	
}
