package com.cg.employeemaintaince.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="login")
public class Login {
	
	@Id
	@Column(name="USERNAME")
	private String userName;
	@Column(name="USERTYPE")
	private String loginType;
	@Column(name="USERPASSWORD")
	private String password;
	@Column(name="USERID")
	private int empId;
	
	public Login()
	{
		
	}
	
	public Login(String userName, String loginType, String password,int empId) {
		super();
		this.userName = userName;
		this.loginType = loginType;
		this.password = password;
		this.empId=empId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", loginType=" + loginType + ", password=" + password + ", empId="
				+ empId + "]";
	}
	
	
	
}
