package com.cg.employeemaintaince.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CUST_SEQ")
    @SequenceGenerator(sequenceName = "customer_seq", allocationSize = 1, name = "CUST_SEQ")
	@Column(name="EMPID")
	private int empId;
	@Column(name="EMPNAME")
	private String empName;
	@Column(name="EMPSALARY")
	private float salary;
	@Column(name="EMPDEPTID")
	private int departmentId;
	@Column(name="EMPDOB")
	private Date dateOfBirth;
	@Column(name="EMPCONTACTNUMBER")
	private Long contactNumber;
	@Column(name="MANAGERID")
	private int managerId;
	@Column(name="NOOFLEAVES")
	private int noOfLeaves;
	@Column(name="EMPDOJ")
	private Date dateOfJoining;
	@Column(name="EMPGRADE")
	private String grade;
	@Column(name="EMPDESIGNATION")
	private String empDesignation;
	@Column(name="EMPMARTIALSTATUS")
	private String empMartialStatus;
	@Column(name="EMPADDRESS")
	private String empAddress;
	
	
	public Employee()
    {
		// TODO Auto-generated constructor stub
	}


	public Employee(int empId, String empName, float salary, int departmentId, Date dateOfBirth, Long contactNumber,
			int managerId, int noOfLeaves, Date dateOfJoining, String grade, String empDesignation,
			String empMartialStatus, String empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.departmentId = departmentId;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.managerId = managerId;
		this.noOfLeaves = noOfLeaves;
		this.dateOfJoining = dateOfJoining;
		this.grade = grade;
		this.empDesignation = empDesignation;
		this.empMartialStatus = empMartialStatus;
		this.empAddress = empAddress;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public float getSalary() {
		return salary;
	}


	public void setSalary(float salary) {
		this.salary = salary;
	}


	public int getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public int getManagerId() {
		return managerId;
	}


	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}


	public int getNoOfLeaves() {
		return noOfLeaves;
	}


	public void setNoOfLeaves(int noOfLeaves) {
		this.noOfLeaves = noOfLeaves;
	}


	public Date getDateOfJoining() {
		return dateOfJoining;
	}


	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	public String getEmpDesignation() {
		return empDesignation;
	}


	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}


	public String getEmpMartialStatus() {
		return empMartialStatus;
	}


	public void setEmpMartialStatus(String empMartialStatus) {
		this.empMartialStatus = empMartialStatus;
	}


	public String getEmpAddress() {
		return empAddress;
	}


	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", departmentId="
				+ departmentId + ", dateOfBirth=" + dateOfBirth + ", contactNumber=" + contactNumber + ", managerId="
				+ managerId + ", noOfLeaves=" + noOfLeaves + ", dateOfJoining=" + dateOfJoining + ", grade=" + grade
				+ ", empDesignation=" + empDesignation + ", empMartialStatus=" + empMartialStatus + ", empAddress="
				+ empAddress + "]";
	}
	
	
	

}
