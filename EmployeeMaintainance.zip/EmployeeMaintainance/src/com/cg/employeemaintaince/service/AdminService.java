package com.cg.employeemaintaince.service;


import java.sql.Date;
import java.util.List;

import com.cg.employeemaintaince.dto.Employee;


public interface AdminService {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public boolean modifyEmployeeName(int empId,String empName);
	public boolean modifyEmployeeSalary(int empId,float empSal);
	public boolean modifyEmployeeDepartmentId(int empId,int deptId);
	public boolean modifyEmployeeDOB(int empId,Date dob);
	public boolean modifyEmployeeContactNumber(int empId,Long empContactNumber);
	public boolean modifyEmployeeManagerId(int empId,int empManagerId);
	public boolean modifyEmployeeMartialStatus(int empId,String martialStatus);
	public boolean modifyEmployeeAddress(int empId,String address);
	public Employee searchEmployeeById(String empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
	public boolean isValidPhone(String phone);
	public boolean isValidName(String name);
	public boolean isValidDate(Date dob);
	public boolean isValidYear(String year);
	public boolean isValidDay(int day,int month,int year);
	public boolean isValidMonth(int month);
	public boolean isValidDepartmentId(int deptId);
	public String getDesignation(int deptId);
	public String getValidGrade(float empSal);
	public boolean isValidManagerId(int managerId);
	public boolean isValidMartialStatus(String martialStatus);
	public boolean validatePassword(String newPassword);
	public boolean changeAccountPassword(String newPassword,String userName);
	public boolean checkOldPassword(String oldPassword,String userName);
}
