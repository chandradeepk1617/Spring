package com.cg.employeemaintaince.service;

public interface LoginService {
	public boolean validate(String userName,String password,int userRole);
}
