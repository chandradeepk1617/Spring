package com.cg.employeemaintaince.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemaintaince.dao.AdminDao;
import com.cg.employeemaintaince.dao.AdminDaoImpl;
import com.cg.employeemaintaince.dto.Department;
import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.GradeMaster;
import com.cg.employeemaintaince.validation.Validation;

public class AdminServiceImpl implements AdminService {

	
	AdminDao adminDao = new AdminDaoImpl();
	Validation valid = new Validation();
	
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return adminDao.addEmployee(emp);
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.deleteEmployeeById(empId);
	}

	@Override
	public boolean modifyEmployeeName(int empId, String empName) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeName(empId, empName);
	}

	@Override
	public boolean modifyEmployeeSalary(int empId, float empSal) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeSalary(empId, empSal);
	}

	@Override
	public boolean modifyEmployeeDepartmentId(int empId, int deptId) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeDepartmentId(empId, deptId);
	}

	@Override
	public boolean modifyEmployeeDOB(int empId, Date dob) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeDOB(empId, dob);
	}

	@Override
	public boolean modifyEmployeeContactNumber(int empId, Long empContactNumber) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeContactNumber(empId, empContactNumber);
	}

	@Override
	public boolean modifyEmployeeManagerId(int empId, int empManagerId) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeManagerId(empId, empManagerId);
	}

	@Override
	public Employee searchEmployeeById(String empId) {
		// TODO Auto-generated method stub
		boolean flag = valid.validateEmpId(empId);
		if(flag)
		{
			int eId=Integer.parseInt(empId);
			return adminDao.searchEmployeeById(eId);
		}
		else
		{
			return new Employee();
		}
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployessByName(name);
	}

	@Override
	public List<Employee> displayEmployees() {
		// TODO Auto-generated method stub
		return adminDao.displayEmployees();
	}

	@Override
	public boolean isValidPhone(String phone) {
		// TODO Auto-generated method stub
		String phonePattern = "[^0][0-9]{9}";
		if(Pattern.matches(phonePattern,phone))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean isValidName(String name) {
		// TODO Auto-generated method stub
		String namePattern = "[A-Z]{1,1}[a-z]{2,25}";
		if(Pattern.matches(namePattern,name))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean isValidDate(Date dob) {
		// TODO Auto-generated method stub
		if(dob.toLocalDate().compareTo(LocalDate.now())>0)
		{
			return false;
		}
		else
			return true;
	}

	@Override
	public boolean isValidYear(String year) {
		// TODO Auto-generated method stub
		String yearPattern = "[0-9]{4}";
		if(Pattern.matches(yearPattern,year))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean isValidDay(int day, int month, int year) {
		// TODO Auto-generated method stub
		if(year%4==0&&year%400==0)
		{
			if(month==2||month==4||month==6||month==9||month==11)
			{
				if(month==2)
				{
					if(day<=0||day>29)
					{
						return false;
					}
					else
						return true;
				}
				else
				{
					if(day<=0||day>30)
					{
						return false;
					}
					else
					{
						return true;
					}
				}
			
			}
			else
			{
				if(day<=0||day>31)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}
		else
		{
			if(month==2||month==4||month==6||month==9||month==11)
			{
				if(month==2)
				{
					if(day<=0||day>28)
					{
						return false;
					}
					else
						return true;
				}
				else
				{
					if(day<=0||day>30)
					{
						return false;
					}
					else
					{
						return true;
					}
				}
		
			}
			else
			{
				if(day<=0||day>31)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}
	}

	@Override
	public boolean isValidMonth(int month) {
		// TODO Auto-generated method stub
		if(month<=0||month>12)
		{
			return false;
		}
		else
			return true;
	}

	@Override
	public boolean isValidDepartmentId(int deptId) {
		// TODO Auto-generated method stub
		List<Department> deptList=adminDao.getDepartmentList();
		for(Department dept:deptList)
		{
			if(dept.getDepartmentId() == deptId)
			{
				return true;
			}
		}
		return false;
	}


	@Override
	public String getValidGrade(float empSal) {
		// TODO Auto-generated method stub
		return adminDao.getValidGrade(empSal);
	}

	@Override
	public boolean validatePassword(String newPassword) {
		// TODO Auto-generated method stub
		String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,12})";
		if(Pattern.matches(passwordPattern, newPassword))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
	}

	@Override
	public boolean changeAccountPassword(String newPassword, String userName) {
		// TODO Auto-generated method stub
		return adminDao.changeAccountPassword(newPassword, userName);
	}

	@Override
	public boolean checkOldPassword(String oldPassword, String userName) {
		// TODO Auto-generated method stub
		return adminDao.checkOldPassword(oldPassword, userName);
	}

	@Override
	public boolean isValidManagerId(int managerId) {
		// TODO Auto-generated method stub
		if(new AdminDaoImpl().searchEmployeeById(managerId)!=null)
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean isValidMartialStatus(String martialStatus) {
		// TODO Auto-generated method stub
		if(martialStatus.equals("s") || martialStatus.equals("m"))
		{
			return true;
		}
		return false;
	}

	@Override
	public String getDesignation(int deptId) {
		// TODO Auto-generated method stub
		return adminDao.getDesignation(deptId);
	}

	@Override
	public boolean modifyEmployeeMartialStatus(int empId, String martialStatus) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeMartialStatus(empId, martialStatus);
	}

	@Override
	public boolean modifyEmployeeAddress(int empId, String address) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeAddress(empId, address);
	}

}
