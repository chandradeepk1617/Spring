package com.cg.employeemaintaince.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemaintaince.dao.ManagerDao;
import com.cg.employeemaintaince.dao.ManagerDaoImpl;
import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;
import com.cg.employeemaintaince.validation.Validation;

public class ManagerServiceImpl implements ManagerService {

	
	ManagerDao managerDao=new ManagerDaoImpl();
	Validation valid = new Validation();
	
	@Override
	public Employee searchEmployeeById(String empId) {
		// TODO Auto-generated method stub
		boolean flag = valid.validateEmpId(empId);
		if(flag)
		{
			int eId=Integer.parseInt(empId);
			return managerDao.searchEmployeeById(eId);
		}
		else
		{
			return new Employee();
		}
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return managerDao.searchEmployeeByName(fName);
	}

	@Override
	public Employee displayOwnDetials(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displayOwnDetials(userName);
	}

	@Override
	public List<Employee> displaySubEmployees(String userName) {
		// TODO Auto-generated method stub
		return managerDao.displaySubEmployees(userName);
	}

	@Override
	public List<Leave> showLeavesApplied(String userName) {
		// TODO Auto-generated method stub
		return managerDao.showLeavesApplied(userName);
	}

	@Override
	public boolean accept(int leaveId, String userName) {
		// TODO Auto-generated method stub
		return managerDao.accept(leaveId, userName);
	}

	@Override
	public boolean reject(int leaveId, String reason, String userName) {
		// TODO Auto-generated method stub
		return managerDao.reject(leaveId, reason, userName);
	}

	@Override
	public boolean changeAccountPassword(String userName, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		return managerDao.changeAccountPassword(userName, oldPassword, newPassword);
	}

	@Override
	public boolean validatePassword(String newPassword) {
		// TODO Auto-generated method stub
		String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,12})";
		if(Pattern.matches(passwordPattern, newPassword))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
	}

}
