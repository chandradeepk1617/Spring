package com.cg.employeemaintaince.service;

import java.sql.Date;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.employeemaintaince.dao.EmployeeDao;
import com.cg.employeemaintaince.dao.EmployeeDaoImpl;
import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;
import com.cg.employeemaintaince.dto.Login;
import com.cg.employeemaintaince.validation.Validation;

public class EmployeeServiceImpl implements EmployeeService {

	
	EmployeeDao employeeDao = new EmployeeDaoImpl();
	Validation valid = new Validation();
	
	@Override
	public Employee searchEmployeeById(String empId) {
		// TODO Auto-generated method stub
		boolean flag = valid.validateEmpId(empId);
		if(flag)
		{
			int eId=Integer.parseInt(empId);
			return employeeDao.searchEmployeeById(eId);
		}
		else
		{
			return new Employee();
		}
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeByName(fName);
	}

	@Override
	public Employee displayEmpDetails(String userName) {
		// TODO Auto-generated method stub
		return employeeDao.displayEmpDetails(userName);
	}

	@Override
	public boolean changeAccountPassword(String userName, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		return employeeDao.changeAccountPassword(userName, oldPassword, newPassword);
	}

	@Override
	public boolean addLeave(Leave leave) {
		// TODO Auto-generated method stub
		return employeeDao.addLeave(leave);
	}

	@Override
	public Leave editLeaveFromDate(int leaveId, Date fromDate) {
		// TODO Auto-generated method stub
		return employeeDao.editLeaveFromDate(leaveId, fromDate);
	}

	@Override
	public Leave editLeaveToDate(int leaveId, Date toDate) {
		// TODO Auto-generated method stub
		return employeeDao.editLeaveToDate(leaveId, toDate);
	}

	@Override
	public Leave editLeaveReason(int leaveId, String newReason) {
		// TODO Auto-generated method stub
		return employeeDao.editLeaveReason(leaveId, newReason);
	}

	@Override
	public Leave SearchLeave(int leaveId) {
		// TODO Auto-generated method stub
		return employeeDao.SearchLeave(leaveId);
	}

	@Override
	public boolean cancelLeave(int leaveId) {
		// TODO Auto-generated method stub
		return employeeDao.cancelLeave(leaveId);
	}
	public List<Leave> getAppliedLeaves(String userName)
	{
		return employeeDao.getAppliedLeaves(userName);
	}
	public List<Leave> getPendingLeaves(String userName)
	{
		return employeeDao.getPendingLeaves(userName);
	}
	@Override
	public boolean validateTODate(Date fromDate, Date toDate, String name) {
		// TODO Auto-generated method stub
		int leaves = employeeDao.getLeaveBalance(name);
		LocalDate tDate = toDate.toLocalDate();
		LocalDate fDate = fromDate.toLocalDate();
		if(fromDate.compareTo(toDate)<0)
		{
			
			Long days = ChronoUnit.DAYS.between(fDate, tDate);
			System.out.println("difference: "+days);
			if(days>=1 && days<60 && leaves >= days)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			System.out.println(fromDate.compareTo(toDate));
			return false;
		}
	}

	@Override
	public boolean validateFromDate(Date fromDate) {
		// TODO Auto-generated method stub
		if (fromDate.toLocalDate().compareTo(LocalDate.now()) < 0) 
		{
			return false;
		} 
		else 
		{
		
			Long days = ChronoUnit.DAYS.between(LocalDate.now(),fromDate.toLocalDate());
			if(days>=1 && days<60)
			{
				return  true;
			}
			else
				return false;
		}
	}

	@Override
	public boolean isValidYear(String year) {
		// TODO Auto-generated method stub
		String yearPattern = "[0-9]{4}";
		if(Pattern.matches(yearPattern,year))
		{
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean isValidDay(int day, int month, int year) {
		// TODO Auto-generated method stub
		if(year%4==0&&year%400==0)
		{
			if(month==2||month==4||month==6||month==9||month==11)
			{
				if(month==2)
				{
					if(day<=0||day>29)
					{
						return false;
					}
					else
						return true;
				}
				else
				{
					if(day<=0||day>30)
					{
						return false;
					}
					else
					{
						return true;
					}
				}
			
			}
			else
			{
				if(day<=0||day>31)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}
		else
		{
			if(month==2||month==4||month==6||month==9||month==11)
			{
				if(month==2)
				{
					if(day<=0||day>28)
					{
						return false;
					}
					else
						return true;
				}
				else
				{
					if(day<=0||day>30)
					{
						return false;
					}
					else
					{
						return true;
					}
				}
		
			}
			else
			{
				if(day<=0||day>31)
				{
					return false;
				}
				else
				{
					return true;
				}
			}
		}
	}

	@Override
	public boolean isValidMonth(int month) {
		// TODO Auto-generated method stub
		if(month<=0||month>12)
		{
			return false;
		}
		else
			return true;
	}

	@Override
	public boolean validatePassword(String newPassword) {
		// TODO Auto-generated method stub
		String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,12})";
		if(Pattern.matches(passwordPattern, newPassword))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
	}

	@Override
	public int getEmpIdFromLoginTable(String userName) {
		// TODO Auto-generated method stub
		return employeeDao.getEmpIdFromLoginTable(userName);
	}

	@Override
	public int getManagerIdForEmp(String userName) {
		// TODO Auto-generated method stub
		return employeeDao.getManagerIdForEmp(userName);
	}

	@Override
	public int getLeaveBalance(String userName) {
		// TODO Auto-generated method stub
		return employeeDao.getLeaveBalance(userName);
	}

	@Override
	public Date getFromDate(int leaveId) {
		// TODO Auto-generated method stub
		return employeeDao.getFromDate(leaveId);
	}

	@Override
	public Date getToDate(int leaveId) {
		// TODO Auto-generated method stub
		return employeeDao.getToDate(leaveId);
	}

	@Override
	public boolean validLeaveId(int leaveId, String userName) {
		System.out.println("HI");
		return employeeDao.validLeaveId(leaveId, userName);
	}

}
