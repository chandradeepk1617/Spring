package com.cg.employeemaintaince.dao;

import java.sql.Date;
import java.util.List;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;


public interface EmployeeDao {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayEmpDetails(String userName);
	public boolean changeAccountPassword(String userName,String oldPassword,String newPassword);
	public boolean addLeave(Leave leave);
	public Leave editLeaveFromDate(int leaveId,Date fromDate);
	public Leave editLeaveToDate(int leaveId,Date toDate);
	public Leave editLeaveReason(int leaveId,String newReason);
	public Leave SearchLeave(int leaveId);
	public boolean cancelLeave(int leaveId);
	public int getEmpIdFromLoginTable(String userName);
	public int getManagerIdForEmp(String userName);
	public int getLeaveBalance(String userName);
	public Date getFromDate(int leaveId);
	public Date getToDate(int leaveId);
	public List<Leave> getAppliedLeaves(String userName);
	public List<Leave> getPendingLeaves(String userName);
	public boolean validLeaveId(int leaveId, String userName);
}
