package com.cg.employeemaintaince.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Login;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean validate(String userName, String pwd, int userRole) {
		// TODO Auto-generated method stub
		String userType;
		if(userRole==1)
		{
			userType="admin";
		}
		else if(userRole==2)
		{
			userType="manager";
		}
		else 
		{
			userType="employee";
		}
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
			List<Login> loginList = new ArrayList<Login>();	
					String str="SELECT user FROM Login user WHERE user.userName=:n";
			TypedQuery<Login> query=em.createQuery(str, Login.class);
			query.setParameter("n", userName);
			loginList = query.getResultList();
			if(loginList.size()>0)
			{
			if(loginList.get(0).getPassword().equals(pwd) && loginList.get(0).getUserName().equals(userName)  &&  loginList.get(0).getLoginType().equals(userType))
			{
				return true;
			}
			else
				return false;
			}
			else
			{
				return false;
			}
		
		
		
	}

}
