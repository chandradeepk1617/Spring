package com.cg.employeemaintaince.dao;

import java.sql.Date;
import java.util.List;

import com.cg.employeemaintaince.dto.Department;
import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.GradeMaster;

public interface AdminDao {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public boolean modifyEmployeeName(int empId,String empName);
	public boolean modifyEmployeeSalary(int empId,float empSal);
	public boolean modifyEmployeeDepartmentId(int empId,int deptId);
	public boolean modifyEmployeeDOB(int empId,Date dob);
	public boolean modifyEmployeeContactNumber(int empId,Long empContactNumber);
	public boolean modifyEmployeeManagerId(int empId,int empManagerId);
	public boolean modifyEmployeeMartialStatus(int empId,String martialStatus);
	public boolean modifyEmployeeAddress(int empId,String address);
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
	public boolean changeAccountPassword(String newPassword,String userName);
	public boolean checkOldPassword(String oldPassword,String userName);
	public List<Department> getDepartmentList();
	public List<GradeMaster> getGradeList();
	public String getDesignation(int deptId);
	public String getValidGrade(float empSal);
}
