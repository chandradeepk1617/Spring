package com.cg.employeemaintaince.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.cg.employeemaintaince.dto.Department;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.GradeMaster;
import com.cg.employeemaintaince.dto.Login;

public class AdminDaoImpl implements AdminDao{
	
	

	public static void addLogin(Employee emp)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		 EntityManager em =emf.createEntityManager();
		 Login  newLogin=new Login();
		 newLogin.setUserName(emp.getEmpName()+String.valueOf(emp.getEmpId()));
		 System.out.println("Entered and: "+emp.getManagerId()+"Emp: "+emp.getEmpId());
		 String str="SELECT e FROM Employee e WHERE e.empName=:n";
			TypedQuery query=em.createQuery(str, Employee.class);
			query.setParameter("n", emp.getEmpName());
			List<Employee> empList=query.getResultList();
		Employee newEmp=new Employee();
		for(Employee e:empList)
		{
			if(e.getContactNumber()==emp.getContactNumber())
			{
				newEmp.setEmpId(e.getEmpId());
			}
		}
		 if(newEmp.getEmpId()== emp.getManagerId())
		 {
			 newLogin.setLoginType("manager");
			 newLogin.setPassword("capgeminiManager");
		 }
		 else
		 {
			 newLogin.setLoginType("employee");
			 newLogin.setPassword("capgeminiEmployee");
		 }
		 newLogin.setEmpId(emp.getEmpId());
		 EntityTransaction entityTransaction=em.getTransaction();
		 entityTransaction.begin();
		 em.persist(newLogin);
		 System.out.println("finished");
		 System.out.println("new login: "+newLogin);
		 entityTransaction.commit();
		 em.close();
		 emf.close();
	}
	
	public static void removeLogin(String empName)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, empName);
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.remove(entity);
		et.commit();
		em.close();
		emf.close();
	}
	
	@Override
	public List<Department> getDepartmentList()
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT dept FROM Department dept";
		TypedQuery query=em.createQuery(str, Department.class);
		List<Department> deptList=query.getResultList();
		return deptList;
	}
	@Override
	public boolean addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		 EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		 EntityManager em =emf.createEntityManager(); 
		 Employee entity=new Employee();
		 System.out.println("Entered");
		 entity.setEmpName(emp.getEmpName());
		 System.out.println("Name finished");
		 entity.setSalary(emp.getSalary());
		 System.out.println("sal");
		 entity.setNoOfLeaves(emp.getNoOfLeaves());
		 entity.setManagerId(emp.getManagerId());
		 entity.setDateOfBirth(emp.getDateOfBirth());
		 entity.setContactNumber(emp.getContactNumber());
		 entity.setDateOfJoining(emp.getDateOfJoining());
		 entity.setDepartmentId(emp.getDepartmentId());
		 entity.setGrade(emp.getGrade());
		 entity.setEmpDesignation(emp.getEmpDesignation());
		 entity.setEmpMartialStatus(emp.getEmpMartialStatus());
		 entity.setEmpAddress(emp.getEmpAddress());
		 System.out.println("Entered details are: "+entity);
		 EntityTransaction et=em.getTransaction(); 
		 et.begin(); 
		 em.persist(emp); 
		 et.commit(); 
		 em.close();
		 emf.close();
		 addLogin(emp);
		return true;
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		System.out.println("deleted value is: "+entity);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			em.remove(entity);
			et.commit();
			em.close();
			emf.close();
			removeLogin(entity.getEmpName()+String.valueOf(entity.getEmpId()));
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeName(int empId, String empName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setEmpName(empName);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeSalary(int empId, float empSal) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String newGrade=new AdminDaoImpl().getValidGrade(empSal);
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setSalary(empSal);
			entity.setGrade(newGrade);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeDepartmentId(int empId, int deptId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String newDesignation=new AdminDaoImpl().getDesignation(deptId);
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setDepartmentId(deptId);
			entity.setEmpDesignation(newDesignation);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeDOB(int empId, Date dob) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setDateOfBirth(dob);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeContactNumber(int empId, Long empContactNumber) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setContactNumber(empContactNumber);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeManagerId(int empId, int empManagerId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setManagerId(empManagerId);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}
	
	@Override
	public boolean modifyEmployeeMartialStatus(int empId,String martialStatus) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setEmpMartialStatus(martialStatus);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean modifyEmployeeAddress(int empId,String address) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setEmpAddress(address);
			em.close();
			emf.close();
			et.commit();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}
	
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		em.close();
		emf.close();
		return entity;
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT e FROM Employee e WHERE e.empName=:n";
		TypedQuery query=em.createQuery(str, Employee.class);
		query.setParameter("n", name);
		List<Employee> empList=query.getResultList();
		return empList;
	}

	@Override
	public List<Employee> displayEmployees() {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT e FROM Employee e";
		TypedQuery query=em.createQuery(str, Employee.class);
		List<Employee> empList=query.getResultList();
		return empList;
	}

	@Override
	public boolean changeAccountPassword(String newPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setPassword(newPassword);
			et.commit();
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean checkOldPassword(String oldPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null && entity.getPassword().equals(oldPassword))
		{
			em.close();
			emf.close();
			return true;
		}
	     
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public List<GradeMaster> getGradeList() {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT grade FROM GradeMaster grade";
		TypedQuery query=em.createQuery(str, GradeMaster.class);
		List<GradeMaster> gradeList=query.getResultList();
		return gradeList;
	}

	@Override
	public String getDesignation(int deptId) {
		// TODO Auto-generated method stub
		List<Department> deptList=new AdminDaoImpl().getDepartmentList();
		for(Department dept:deptList)
		{
			if(dept.getDepartmentId()== deptId)
			{
				return dept.getDepartmentName();
			}
		}
		return null;
	}

	@Override
	public String getValidGrade(float empSal) {
		// TODO Auto-generated method stub
		List<GradeMaster> gradeList=new AdminDaoImpl().getGradeList();
		float annualSal=empSal*12;
		for(GradeMaster grade:gradeList)
		{
			if(grade.getMinimunSalary()<=annualSal  && annualSal<=grade.getMaximumSalary())
			{
				return grade.getGradeCode();
			}
		}
		return null;
	}

	


}
