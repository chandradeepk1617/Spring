package com.cg.employeemaintaince.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.employeemaintaince.dto.Employee;
import com.cg.employeemaintaince.dto.Leave;
import com.cg.employeemaintaince.dto.LeaveResponse;
import com.cg.employeemaintaince.dto.Login;

public class ManagerDaoImpl implements ManagerDao {

	
	public int getEmpIdFromLoginTable(String userName)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		return entity.getEmpId();
	}
	
	public int getEmpIdFromLoginTable(int leaveId)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		return entity.getEmpId();
	}
	
	
	public int getLeaveBalance(int leaveId)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave leave=em.find(Leave.class, leaveId);
		Employee entity=em.find(Employee.class, leave.getEmpId());
		System.out.println("Emp details are: "+entity);
		System.out.println("leaves are: "+entity.getNoOfLeaves());
		return entity.getNoOfLeaves();
	}
	
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Employee entity=em.find(Employee.class, empId);
		em.close();
		emf.close();
		return entity;
	}

	@Override
	public List<Employee> searchEmployeeByName(String fName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT e FROM Employee e WHERE e.empName=:n";
		TypedQuery query=em.createQuery(str, Employee.class);
		query.setParameter("n", fName);
		List<Employee> empList=query.getResultList();
		return empList;
	}

	@Override
	public Employee displayOwnDetials(String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		
			String str="SELECT user FROM Login user WHERE user.userName=:n";
			TypedQuery query=em.createQuery(str,Login.class);
			query.setParameter("n", userName);
			Login userLogin=(Login) query.getSingleResult();
			System.out.println("Login details are: "+userLogin);
			String empQueryString="SELECT e FROM Employee e WHERE e.empId=:id";
			TypedQuery empQuery=em.createQuery(empQueryString,Employee.class );
			empQuery.setParameter("id", userLogin.getEmpId());
			Employee empDetails=(Employee) empQuery.getSingleResult();
			return empDetails;
	}

	@Override
	public List<Employee> displaySubEmployees(String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT e FROM Employee e WHERE e.managerId=:n";
		TypedQuery query=em.createQuery(str, Employee.class);
		query.setParameter("n", new ManagerDaoImpl().getEmpIdFromLoginTable(userName));
		List<Employee> empList=query.getResultList();
		return empList;
	}

	@Override
	public List<Leave> showLeavesApplied(String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		String str="SELECT leave FROM Leave leave WHERE leave.managerId=:n";
		TypedQuery query=em.createQuery(str, Leave.class);
		query.setParameter("n", new ManagerDaoImpl().getEmpIdFromLoginTable(userName));
		List<Leave> leaveList=query.getResultList();
		return leaveList;
	}

	@Override
	public boolean accept(int leaveId,String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		System.out.println("EmpId of manager is: "+new ManagerDaoImpl().getEmpIdFromLoginTable(leaveId));
		if(entity!=null && (entity.getManagerId()== new ManagerDaoImpl().getEmpIdFromLoginTable(userName)))
		{
			Employee emp=em.find(Employee.class, new ManagerDaoImpl().getEmpIdFromLoginTable(leaveId));
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setLeaveStatus("approved");
			entity.setLeavesRemaining(((new ManagerDaoImpl().getLeaveBalance(leaveId))-1));
			emp.setNoOfLeaves(((new ManagerDaoImpl().getLeaveBalance(leaveId))-1));
			et.commit();
			return true;
		}
		em.close();
		emf.close();
		return false;
	}

	@Override
	public boolean reject(int leaveId, String reason,String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Leave entity=em.find(Leave.class, leaveId);
		//System.out.println("EmpId of manager is: "+new ManagerDaoImpl().getEmpIdFromLoginTable(leaveId));
		if(entity!=null && (entity.getManagerId()== new ManagerDaoImpl().getEmpIdFromLoginTable(userName)))
		{
			LeaveResponse rejectReason=new LeaveResponse();
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setLeaveStatus("rejected");
			rejectReason.setLeaveId(leaveId);
			rejectReason.setReason(reason);
			em.persist(rejectReason);
			et.commit();
			em.close();
			emf.close();
			return true;
		}
		em.close();
		emf.close();
		return false;
	}

	
	public static boolean changeAccountPassword(String newPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null)
		{
			EntityTransaction et=em.getTransaction();
			et.begin();
			entity.setPassword(newPassword);
			et.commit();
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	
	public static boolean checkOldPassword(String oldPassword, String userName) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(entity!=null && entity.getPassword().equals(oldPassword))
		{
			em.close();
			emf.close();
			return true;
		}
		else
		{
			em.close();
			emf.close();
			return false;
		}
	}

	@Override
	public boolean changeAccountPassword(String userName, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em =emf.createEntityManager();
		Login entity=em.find(Login.class, userName);
		if(checkOldPassword(oldPassword,userName))
		{
			if(changeAccountPassword(newPassword,userName))
			{
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}

}
